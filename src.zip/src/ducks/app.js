import { createAction, createReducer } from '@reduxjs/toolkit'

const FETCH_DATA = 'commando/app/FETCH_DATA'

const GET_EXPLORE_CONTENT = 'commando/app/GET_EXPLORE_CONTENT'
const GET_COLLECTION_CONTENT = 'commando/app/GET_COLLECTION_CONTENT'
const GET_VIDEO_SOURCE_LIST = 'commando/app/GET_VIDEO_SOURCE_LIST'
const GET_DATA_PROFILE = 'commando/app/GET_DATA_PROFILE'
const UPDATE_PROFILE = 'commando/app/UPDATE'
const GET_USER_ROUTINE = 'commando/app/GET_USER_ROUTINE'
const SET_USERIMAGE = 'commando/auth/USERIMAGE'
const UPDATE_WEEKDAYS = 'commando/app/UPDATE_WEEKDAYS'

export const setUserImage = createAction(SET_USERIMAGE, (formAvatar) => ({
  payload: {
    request: {
      url: `/user/profile/upload`,
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'multipart/form-data'
      },
      body: formAvatar
    }
  }
}))

export const updateWeekDays = createAction(UPDATE_WEEKDAYS, (data) => ({
  payload: {
    request: {
      url: `/user/profile/schedule`,
      method: 'Post',
      data
    }
  }
}))

export const updateProfile = createAction(UPDATE_PROFILE, (data) => ({
  payload: {
    request: {
      url: `/user/profile`,
      method: 'PATCH',
      data
    }
  }
}))

export const fetchData = createAction(
  FETCH_DATA,
  (config = { client: 'default', method: 'get' }) => ({
    payload: {
      client: config.client,
      request: {
        url: config.url,
        method: config.method,
        params: config.params,
        data: config.data
      }
    }
  })
)

export const getVideoList = createAction(
  GET_VIDEO_SOURCE_LIST,
  (contentId) => ({
    payload: {
      request: {
        url: `/vimeo/videos/${contentId}`
      }
    }
  })
)

export const getExploreContent = createAction(GET_EXPLORE_CONTENT, () => ({
  payload: {
    request: {
      url: `/vimeo/explore`
    }
  }
}))

export const getCollectionContent = createAction(
  GET_COLLECTION_CONTENT,
  (id, params = { page: 1, items: 100 }) => ({
    payload: {
      request: {
        url: `/vimeo/explore/${id}`,
        params
      }
    }
  })
)

export const getVideoSource = createAction(
  GET_VIDEO_SOURCE_LIST,
  (contentId, { quality, format, codec }) => ({
    payload: {
      request: {
        url: `/vimeo/videos/${contentId}/files`,
        params: { quality, format, codec }
      }
    }
  })
)

export const getDataProfile = createAction(GET_DATA_PROFILE, () => ({
  payload: {
    request: {
      url: `/user/profile`
    }
  }
}))

export const getUserRoutine = createAction(GET_USER_ROUTINE, () => ({
  payload: {
    request: {
      url: `/vimeo/routine`
    }
  }
}))

const initState = {
  profile: null
}

const reducer = createReducer(initState, {
  [GET_DATA_PROFILE](state, action) {
    return { ...state, profile: action.payload.profile }
  },
  [UPDATE_PROFILE](state, action) {
    return {
      ...state,
      profile: {
        ...state.profile,
        firstName: action.payload.request.data.firstName,
        lastName: action.payload.request.data.lastName
      }
    }
  },
  [SET_USERIMAGE](state, action) {
    return { ...state }
  }
})
export default reducer

export { FETCH_DATA }
