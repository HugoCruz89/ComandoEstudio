import { createAction, createReducer } from '@reduxjs/toolkit'

const LOGIN = 'commando/auth/LOGIN'

const LOGOUT = 'commando/auth/LOGOUT'

const SET_EMAIL = 'commando/auth/EMAIL'

const SET_USERNAME = 'commando/auth/USERNAME'

const SET_USERIMAGE = 'commando/auth/USERIMAGE'

const UPDATE_DATAGENERAL = 'commando/auth/UPDATE_DATAGENERA'

// const VALIDATE_EMAIL = 'commando/auth/VALIDATE_EMAIL'

const COMPLETE_RESET_PASSWORD = 'commando/auth/COMPLETE_RESET_PASSWORD'

const RESET_PASSWORD = 'commando/auth/RESET_PASSWORD'

const REGISTER_USER = 'commando/auth/REGISTER_USER'

const VERIFY_TOKEN = 'commando/auth/VERIFY_TOKEN'

const REGISTER_SCREEN_VISIT = 'commando/auth/REGISTER_SCREEN_VISIT'

const SCHEDULE_EVENT = 'commando/auth/SCHEDULE_EVENT'

const REMOVE_EVENT = 'commando/auth/REMOVE_EVENT'

const TRACK_CONTENT = 'commando/auth/TRACK_CONTENT'

const REMOVE_TRACKED_CONTENT = 'commando/auth/REMOVE_TRACKED_CONTENT'

const UPDATE_ONBOARDING_DATA = 'commando/app/UPDATE_AGE'

const UPDATE_PROFILE = 'commando/app/UPDATE_PROFILE'
export const updateOnboardingData = createAction(UPDATE_ONBOARDING_DATA)
export const updateProfileStore = createAction(UPDATE_PROFILE)

export const updateDataGeneral = createAction(UPDATE_DATAGENERAL)

export const setEmail = createAction(SET_EMAIL)

export const setUserImage = createAction(SET_USERIMAGE)

export const setUserName = createAction(SET_USERNAME)

export const logOut = createAction(LOGOUT)

export const registerScreenVisit = createAction(REGISTER_SCREEN_VISIT)

export const scheduleEvent = createAction(SCHEDULE_EVENT)

export const removeEvent = createAction(REMOVE_EVENT)

export const trackContent = createAction(
  TRACK_CONTENT,
  (id, duration, progress, secondsPlayed) => {
    const _percent = secondsPlayed / duration
    return {
      payload: {
        request: {
          url: `/stats/video/${id}/progress`,
          method: 'post',
          data: {
            id,
            duration,
            progress,
            lastAction: new Date(),
            secondsPlayed: isNaN(secondsPlayed) ? 0 : secondsPlayed,
            percent: _percent > 100 ? 100 : _percent
          }
        }
      }
    }
  }
)

export const removeTrackContent = createAction(REMOVE_TRACKED_CONTENT)

export const loginUser = createAction(LOGIN, (email, password) => ({
  payload: {
    request: {
      url: `/auth/login`,
      method: 'post',
      data: {
        email,
        password
      }
    }
  }
}))

export const resetPassword = createAction(RESET_PASSWORD, (data) => ({
  payload: {
    request: {
      url: `/auth/reset_password`,
      method: 'post',
      data
    }
  }
}))

export const completeReset = createAction(
  COMPLETE_RESET_PASSWORD,
  (userId, password, token) => ({
    payload: {
      request: {
        url: `/auth/complete_reset`,
        method: 'post',
        data: {
          userId,
          password,
          token
        }
      }
    }
  })
)

export const registerUser = createAction(
  REGISTER_USER,
  (email, firstName, lastName, password) => ({
    payload: {
      request: {
        url: `/auth/sign_up`,
        method: 'post',
        data: {
          email,
          password,
          firstName,
          lastName
        }
      }
    }
  })
)

export const verifyToken = createAction(VERIFY_TOKEN, (userId, token) => ({
  payload: {
    request: {
      url: `/auth/verify_token`,
      method: 'post',
      data: {
        userId,
        token
      }
    }
  }
}))

const initState = {
  token: null,
  userId: null,
  email: null,
  hasPassword: null,
  showWelcome: true,
  showOnBoarding: true,
  firstName: 'MARCO',
  lastName: 'DEL VALLE GARCIA',
  avatar: '',
  events: {},
  trackedContent: {},
  eventId: 1,
  onboardingData: {}
}

const reducer = createReducer(initState, {
  [UPDATE_PROFILE](state, action) {
    return {
      ...state,
      firstName: action.payload.firstName,
      lastName: action.payload.lastName
    }
  },
  [UPDATE_DATAGENERAL](state, action) {
    return { ...state, onboardingData: action.payload }
  },
  [UPDATE_ONBOARDING_DATA](state, action) {
    return { ...state, onboardingData: action.payload }
  },
  [SET_EMAIL](state, action) {
    return { ...state, email: action.payload }
  },
  [`${LOGIN}_SUCCESS`](state, action) {
    const {
      payload: { authenticationToken }
    } = action
    return { ...state, token: authenticationToken }
  },
  [LOGOUT]() {
    return initState
  },
  [REGISTER_SCREEN_VISIT](state, action) {
    let flags
    switch (action.payload.screen) {
      case 'intro':
        flags = { showWelcome: false }
        break
      case 'on-boarding':
        flags = { showOnBoarding: false }
        break
      default:
        flags = {}
        break
    }

    return { ...state, ...flags }
  },
  [SCHEDULE_EVENT](state, action) {
    const { id: payloadId } = action.payload
    const id = payloadId || state.eventId
    return {
      ...state,
      events: {
        ...state.events,
        [id]: action.payload || { id: state.eventId }
      },
      eventId: id === state.eventId ? state.eventId + 1 : state.eventId
    }
  },
  [REMOVE_EVENT](state, action) {
    return {
      ...state,
      events: { ...state.events, [action.payload]: null }
    }
  },
  [TRACK_CONTENT](state, action) {
    const {
      id,
      duration,
      progress,
      secondsPlayed,
      lastAction
    } = action.payload.request.data

    const registeredSecondsPlayed = state.trackedContent?.[id].secondsPlayed

    const _secondsPlayed = registeredSecondsPlayed
      ? registeredSecondsPlayed + secondsPlayed
      : secondsPlayed

    return {
      ...state,
      trackedContent: {
        ...state.trackedContent,
        [id]: {
          id,
          duration,
          progress,
          secondsPlayed: _secondsPlayed,
          lastAction
        }
      }
    }
  },
  [REMOVE_TRACKED_CONTENT](state, action) {
    const { [action.payload]: _del, ...trackedContent } = state.trackedContent
    return { ...state, trackedContent }
  }
})

export default reducer
