import React from 'react'
import { bool } from 'prop-types'
import { connect } from 'react-redux'
import { createStackNavigator } from '@react-navigation/stack'
import { SvgBackArrow, SvgShareIcon } from '../media/images/svg/ObjetiveIcons'

import {
  Channel,
  VideoDetail,
  VideoPlayer,
  Intro,
  ProfileForm,
  OnBoarding,
  liveClass,
  NotFound,
  CustomizeTraining,
  Notifications,
  GeneralScreen,
  ActivityLevel,
  Objectives,
  WeekExcercises,
  CollectionListScreen,
  ChangePassword,
  ChangeName
} from 'modules'
import HomeTabs from './HomeTabs'

const AppStack = createStackNavigator()

function AppScreens(props) {
  return (
    <AppStack.Navigator
      screenOptions={{
        headerBackTitleVisible: false,
        headerTitleStyle: {
          fontFamily: 'Raleway',
          fontWeight: '500',
          fontSize: 20,
          textTransform: 'uppercase',
          color: '#43485C'
        },
        headerBackImage: () => <SvgBackArrow />
      }}>
      {props.showWelcome && (
        <AppStack.Screen
          name="intro"
          component={Intro}
          options={{ headerShown: false }}
        />
      )}
      {props.showOnBoarding && (
        <AppStack.Screen
          name="on-boarding"
          component={OnBoarding}
          options={{
            headerShown: false
          }}
        />
      )}

      <AppStack.Screen
        name="home"
        component={HomeTabs}
        options={{ headerShown: false }}
      />
      <AppStack.Screen
        name="channel"
        component={Channel}
        options={{
          headerTitleStyle: {
            fontFamily: 'Raleway',
            fontWeight: '800',
            fontSize: 20,
            textTransform: 'uppercase',
            maxWidth: 250,
            color: '#43485C'
          }
        }}
      />
      <AppStack.Screen
        name="video-detail"
        component={VideoDetail}
        options={{
          headerTitleStyle: {
            fontFamily: 'Raleway',
            fontWeight: '800',
            fontSize: 20,
            textTransform: 'uppercase',
            color: '#43485C'
          }
        }}
      />
      <AppStack.Screen
        name="video-player"
        component={VideoPlayer}
        options={{ headerShown: false }}
      />
      <AppStack.Screen
        name="profile-form"
        component={ProfileForm}
        options={{
          headerShown: true,
          headerTitle: 'PERZONALIZAR ENTRENAMIENTO',
          headerTitleStyle: { fontFamily: 'Raleway', fontWeight: '800' }
        }}
      />
      <AppStack.Screen
        name="change-name"
        component={ChangeName}
        options={{
          headerShown: true,
          headerTitle: '',
          headerTitleStyle: { fontFamily: 'Raleway', fontWeight: '800' }
        }}
      />
      <AppStack.Screen
        name="customize-training"
        component={CustomizeTraining}
        options={{
          headerShown: false
        }}
      />
      <AppStack.Screen
        name="notifications"
        component={Notifications}
        options={{
          headerShown: false
        }}
      />
      <AppStack.Screen
        name="changePassword"
        component={ChangePassword}
        options={{
          headerShown: false
        }}
      />
      <AppStack.Screen
        name="activity-level"
        component={ActivityLevel}
        options={{
          headerShown: false
        }}
      />
      <AppStack.Screen
        name="objectives"
        component={Objectives}
        options={{
          headerShown: true,
          headerTitle: 'OBJETIVOS',
          headerTitleStyle: { fontFamily: 'Raleway', fontWeight: '800' }
        }}
      />
      <AppStack.Screen
        name="week-excercises"
        component={WeekExcercises}
        options={{
          headerShown: true,
          headerTitle: 'EJERCICIO SEMANAL',
          headerTitleStyle: { fontFamily: 'Raleway', fontWeight: '800' }
        }}
      />
      <AppStack.Screen
        name="general-screen"
        component={GeneralScreen}
        options={{
          headerShown: false
        }}
      />
      <AppStack.Screen
        name="live-classes"
        component={liveClass}
        options={{ headerTitle: 'CLASES EN VIVO' }}
      />
      <AppStack.Screen
        name="not-found"
        component={NotFound}
        options={{ headerShown: false }}
      />
      <AppStack.Screen
        name="collection-list"
        component={CollectionListScreen}
        options={{
          headerTitleStyle: {
            fontFamily: 'Raleway',
            fontWeight: '500',
            fontSize: 20,
            textTransform: 'uppercase',
            maxWidth: 250,
            color: '#43485C'
          }
        }}
      />
      {/* <AppStack.Screen
        name="verify"
        component={Verify}
        options={{ headerShown: false }}
      /> */}
      {/* <AppStack.Screen
        name="subscription"
        component={Subscription}
        options={{ headerShown: false }}
      /> */}
    </AppStack.Navigator>
  )
}

AppScreens.propTypes = {
  showWelcome: bool,
  showOnBoarding: bool
}

const mapStateToProps = ({ auth: { showWelcome, showOnBoarding } }) => ({
  showWelcome,
  showOnBoarding
})

export default connect(mapStateToProps)(AppScreens)
