import React from 'react'
import { createStackNavigator } from '@react-navigation/stack'
import { Welcome, Login, Recover, Verify, SetPassword } from 'modules'

const AuthStack = createStackNavigator()

function AuthScreens() {
  return (
    <AuthStack.Navigator>
      <AuthStack.Screen
        name="welcome"
        component={Welcome}
        options={{ headerShown: false }}
      />
      <AuthStack.Screen
        name="login"
        component={Login}
        options={{ headerShown: false }}
      />
      <AuthStack.Screen
        name="recover"
        component={Recover}
        options={{ headerShown: false }}
      />
      <AuthStack.Screen
        name="verify"
        component={Verify}
        options={{ headerShown: false }}
      />
      {/* <AuthStack.Screen
        name="register"
        component={Register}
        options={{ headerShown: false }}
      /> */}
      <AuthStack.Screen
        name="setPassword"
        component={SetPassword}
        options={{ headerShown: false }}
      />
      {/* <AuthStack.Screen
        name="subscription"
        component={Subscription}
        options={{ headerShown: false }}
      /> */}
    </AuthStack.Navigator>
  )
}

export default AuthScreens
