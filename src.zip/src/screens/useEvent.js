import { Alert } from 'react-native'
import PushNotification from 'react-native-push-notification'
import PushNotificationIOS from '@react-native-community/push-notification-ios'
import { scheduleEvent } from 'ducks/auth'
import { useDispatch, useSelector } from 'react-redux'
import { removeEvent } from 'ducks/auth'
import { navigationRef } from './Screens'
import { useEffect, useState } from 'react'
import { compareDesc } from 'date-fns'

class NotificationHandler {
  _dispatch = () => null

  attachDispatch(dispatch) {
    this._dispatch = dispatch
  }

  onNotification(ntf) {
    if (!ntf.id) return null
    const data = ntf.data

    if (compareDesc(new Date(), data.expireDate) === -1) {
      this._dispatch(removeEvent(ntf.id))
      ntf.finish(PushNotificationIOS.FetchResult.NoData)
      return
    }

    if (data.route) {
      navigationRef.current?.navigate(data.route, data.routeParams)
    }

    ntf.finish(PushNotificationIOS.FetchResult.NoData)
  }

  onRegistrationError(err) {
    console.log(err)
  }
}

const handler = new NotificationHandler()

PushNotification.configure({
  onNotification: handler.onNotification.bind(handler),
  onRegistrationError: handler.onRegistrationError.bind(handler),
  popInitialNotification: false,
  requestPermissions: false,
  allowWhileIdle: true
})

function useEvent() {
  const dispatch = useDispatch()

  const eventId = useSelector(({ auth: { eventId: _eventId } }) => _eventId)
  const events = useSelector(({ auth: { events: _events } }) => _events)

  const [shouldReschedule, setShouldReschedule] = useState(false)
  const [shouldPopActive, setShouldPopActive] = useState(false)

  useEffect(() => {
    if (shouldReschedule) {
      Object.keys(events).forEach((key) => {
        const evt = events[key]
        if (!evt) return null
        const hasExpired = compareDesc(new Date(), evt.userInfo.expireDate)
        if (hasExpired) return null
        const isInFuture = compareDesc(new Date(), evt.date)
        if (isInFuture) {
          PushNotification.localNotificationSchedule({
            id: parseInt(evt.id, 10),
            title: evt.title,
            message: evt.message,
            date: new Date(evt.date) || new Date(Date.now() + 5 * 1000),
            userInfo: evt.userInfo
          })
        } else if (shouldPopActive) {
          PushNotification.localNotification({
            id: parseInt(evt.id, 10),
            title: evt.title,
            message: evt.message,
            userInfo: evt.userInfo
          })
        }
      })
      setShouldReschedule(false)
      setShouldPopActive(false)
    }
  }, [events, shouldReschedule, shouldPopActive])

  function _scheduleNotf(evt) {
    if (!evt) return

    const _userInfo = {
      expireDate: evt.expireDate,
      route: evt.route,
      routeParams: evt.routeParams
    }

    const _evt = {
      id: parseInt(evt.id, 10) || eventId,
      title: evt.title,
      message: evt.message,
      date: evt.date,
      userInfo: _userInfo
    }

    PushNotification.localNotificationSchedule(_evt)

    dispatch(scheduleEvent(_evt))

    return _evt
  }

  const _safelySchedule = (evt, cb) => (check) => {
    if (
      check.alert &&
      check.badge &&
      check.lockScreen &&
      check.notificationCenter &&
      check.sound
    ) {
      _scheduleNotf(evt)
    } else {
      return cb()
    }
  }

  function scheduleNotf(evt) {
    function politelySendToHell() {
      Alert.alert(
        'Necesitamos que actives las notificaciones',
        'Para agendar eventos, necesitas habilitar las notificaciones en las configuraciones de tu celular'
      )
    }

    function gracefullyRequest() {
      PushNotification.requestPermissions().then(
        _safelySchedule(evt, politelySendToHell)
      )
    }

    PushNotification.checkPermissions(_safelySchedule(evt, gracefullyRequest))
  }

  function removeScheduledNotf(id) {
    PushNotification.cancelAllLocalNotifications()
    dispatch(removeEvent(id))
    setShouldReschedule(true)
  }

  function recoverStoredEvents() {
    setShouldReschedule(true)
  }

  return {
    scheduleNotf,
    removeScheduledNotf,
    recoverStoredEvents
  }
}

export { handler as notificationHandler }

export default useEvent
