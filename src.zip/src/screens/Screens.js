import React, { createRef, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { NavigationContainer } from '@react-navigation/native'
import SplashScreen from 'react-native-splash-screen'
import AuthScreens from './AuthScreens'
import AppScreens from './AppScreens'
import { notificationHandler } from './useEvent'

const linking = {
  prefixes: ['commandoapp://'],
  config: {
    screens: {
      channel: { initialRouteName: 'home', screens: { channel: 'channel' } },
      ['video-detail']: 'video-detail',
      ['not-found']: '*'
    }
  }
}

export const navigationRef = createRef()

const Screens = () => {
  const authToken = useSelector(({ auth: { token } }) => token)

  const dispatch = useDispatch()

  useEffect(() => {
    SplashScreen.hide()
    notificationHandler.attachDispatch(dispatch)
  }, [dispatch])

  return (
    <NavigationContainer ref={navigationRef} linking={linking}>
      {authToken ? <AppScreens /> : <AuthScreens />}
    </NavigationContainer>
  )
}

Screens.propTypes = {}

export default Screens
