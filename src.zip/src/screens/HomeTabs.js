import React from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { Explore, Grind, Profile } from 'modules'
import {
  SvgLightning,
  SvgCalendar,
  SvgPerson
} from 'media/images/svg/TabsIcons'
import { TabBarLabel } from 'components'

const TabStack = createBottomTabNavigator()

function HomeTabs() {
  function screenOptions({ route }) {
    function tabBarIconConfig({ color, size }) {
      let icon
      switch (route.name) {
        case 'explore':
          icon = <SvgLightning {...{ color, size }} />
          break
        case 'grind':
          icon = <SvgCalendar {...{ color, size }} />
          break
        case 'profile':
          icon = <SvgPerson {...{ color, size }} />
          break
        default:
          icon = null
      }

      return icon
    }
    return { tabBarIcon: tabBarIconConfig }
  }
  return (
    <TabStack.Navigator
      initialRouteName="grind"
      tabBarOptions={{
        activeTintColor: '#FF0D0D',
        inactiveTintColor: '#8C8C8C',
        style: {
          height: 70,
          paddingBottom: 15
        }
      }}
      screenOptions={screenOptions}>
      <TabStack.Screen
        name="grind"
        component={Grind}
        options={{
          tabBarLabel: ({ color, focused }) => (
            <TabBarLabel {...{ color, focused }} title="Mi rutina" />
          )
        }}
      />
      <TabStack.Screen
        name="explore"
        component={Explore}
        options={{
          tabBarLabel: ({ color, focused }) => (
            <TabBarLabel {...{ color, focused }} title="Explorar" />
          )
        }}
      />
      <TabStack.Screen
        name="profile"
        component={Profile}
        options={{
          tabBarLabel: ({ color, focused }) => (
            <TabBarLabel {...{ color, focused }} title="Perfil" />
          )
        }}
      />
    </TabStack.Navigator>
  )
}

export default HomeTabs
