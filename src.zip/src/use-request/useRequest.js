import useSWR from 'swr'
import { useDispatch } from 'react-redux'
import { FETCH_DATA, fetchData } from 'ducks/app'

function useRequest(axiosConfig, reduxAction, swrOptions) {
  const dispatch = useDispatch()

  const args = axiosConfig
    ? [
        `${FETCH_DATA}/${axiosConfig.url}`,
        async () => {
          const res = await dispatch(fetchData(axiosConfig))
          return res.payload
        }
      ]
    : reduxAction
    ? [
        `${reduxAction.type}@${reduxAction.payload.request.url}`,
        async () => {
          const res = await dispatch(reduxAction)
          return res.payload
        }
      ]
    : [null, null]

  return useSWR(...args, swrOptions)
}

export default useRequest
