import React from 'react'
import { View, Image, TouchableOpacity, StyleSheet } from 'react-native'
import { useNavigation } from '@react-navigation/native'
import Text from 'components/Text'

const back = require('media/images/back.png')

const Header = ({ title }) => {
  const navigation = useNavigation()
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.back} onPress={navigation.goBack}>
        <Image source={back} />
      </TouchableOpacity>
      <Text style={styles.title}>{title}</Text>
    </View>
  )
}

export default Header

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginTop: 58,
    marginBottom: 25
  },
  title: {
    textTransform: 'uppercase',
    marginTop: 10,
    fontSize: 20,
    color: '#000000',
    fontWeight: '800'
  },
  back: {
    position: 'absolute',
    left: 15
  }
})
