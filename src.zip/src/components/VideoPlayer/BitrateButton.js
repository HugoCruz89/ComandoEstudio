import React, { useState } from 'react'
import { object, shape, string, any, func, array } from 'prop-types'
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native'
import Modal from 'react-native-modal'
import Icon from 'react-native-vector-icons/Ionicons'

function BitrateButton(props) {
  const [brListIndex, setBrListIndex] = useState(() =>
    props.bitrateList.findIndex((item) => item.value === props.bitrate.value)
  )
  const [bitrate, setBitrate] = useState(props.bitrate)
  const [showModal, setShowModal] = useState(false)
  const [closeTimeoutId, setCloseTimeoutId] = useState(null)

  function handleButtonPress() {
    setShowModal(true)
    props.onBitrateModalOpen && props.onBitrateModalOpen()
  }

  function handleBitrateSelect(bitElement, elementIndex) {
    return !closeTimeoutId
      ? () => {
          setBitrate(bitElement)
          setBrListIndex(elementIndex)
          setCloseTimeoutId(
            setTimeout(() => {
              props.onBitrateSelect && props.onBitrateSelect(bitElement)
              setShowModal(false)
            }, 350)
          )
        }
      : null
  }

  function handleModalClose() {
    if (!closeTimeoutId) {
      setShowModal(false)
      props.onBitrateModalClose && props.onBitrateModalClose()
    }
  }

  function renderBitrateElement(bitElement, elementIndex) {
    const isSelected = elementIndex === brListIndex
    const isBeforeSelected = elementIndex === brListIndex - 1
    const isAfterSelected = elementIndex === brListIndex + 1
    const isLast = elementIndex === props.bitrateList?.length - 1
    return (
      <TouchableOpacity
        key={bitElement.name}
        onPress={handleBitrateSelect(bitElement, elementIndex)}>
        <View
          style={[
            styles[`bitrate-option`],
            isSelected
              ? styles[`bitrate-option--selected`]
              : isBeforeSelected
              ? styles['bitrate-option--selected::before']
              : isAfterSelected
              ? styles['bitrate-option--selected::after']
              : null,
            isLast ? styles['bitrate-option::last'] : null
          ]}>
          <View style={styles['bitrate-container']}>
            <Text style={styles['bitrate-label']}>{bitElement.value}</Text>
          </View>
          <View style={styles['bitrate-description-container']}>
            <Text style={styles['bitrate-description']}>{bitElement.name}</Text>
          </View>
          {isSelected && (
            <Icon
              size={22}
              color="white"
              name="checkmark-sharp"
              onPress={handleModalClose}
            />
          )}
        </View>
      </TouchableOpacity>
    )
  }

  return (
    <>
      <TouchableOpacity
        style={[props.style, styles['bitrate-container']]}
        onPress={handleButtonPress}>
        <Text style={styles['bitrate-label']}>{bitrate.value}</Text>
      </TouchableOpacity>
      <Modal
        isVisible={showModal}
        backdropOpacity={1}
        style={styles['modal-container']}>
        <TouchableOpacity
          style={styles['close-modal']}
          onPress={handleModalClose}>
          <Icon color="white" name="close" size={30} />
        </TouchableOpacity>
        <View style={styles['bitrate-list']}>
          {props.bitrateList.map(renderBitrateElement)}
        </View>
      </Modal>
    </>
  )
}

const Q_adaptive = {
  name: 'Calidad Automática',
  value: 'AUTO'
}
const Q_1080p = {
  name: '1080p',
  value: 'FHD'
}
const Q_720p = {
  name: '720p',
  value: 'HD'
}
const Q_540p = {
  name: '540p',
  value: 'SD'
}
const Q_360p = {
  name: '360p',
  value: 'LD'
}
const Q_240p = {
  name: '240p',
  value: 'ULD'
}

const BITRATES = {
  Q_adaptive,
  Q_540p,
  Q_360p,
  Q_240p,
  Q_720p,
  Q_1080p
}

BitrateButton.propTypes = {
  bitrateList: array,
  style: object,
  bitrate: shape({ name: string, value: any }),
  onBitrateSelect: func,
  onBitrateModalOpen: func,
  onBitrateModalClose: func
}

BitrateButton.defaultProps = {
  bitrateList: [],
  bitrate: Q_adaptive
}

const styles = StyleSheet.create({
  'bitrate-container': {
    borderWidth: 1,
    borderColor: 'white',
    borderStyle: 'solid',
    height: 19,
    width: 56
  },
  'bitrate-list': {
    maxWidth: 556,
    width: '100%'
  },
  'bitrate-label': {
    color: 'white',
    fontSize: 14,
    textTransform: 'uppercase',
    textAlign: 'center',
    fontWeight: 'bold',
    opacity: 1
  },
  'bitrate-label--selected': {
    opacity: 1
  },
  'bitrate-description-container': {
    flex: 1
  },
  'bitrate-description': {
    fontWeight: '600',
    marginLeft: 26,
    fontSize: 16,
    color: 'white'
  },
  'bitrate-option': {
    // flex: 1,
    borderStyle: 'solid',
    borderWidth: 2,
    borderBottomWidth: 0,
    borderColor: '#8C8C8C',
    flexDirection: 'row',
    alignItems: 'center',
    height: 70,
    paddingTop: 20,
    paddingBottom: 20,
    paddingLeft: 25,
    paddingRight: 25
  },
  'bitrate-option::last': {
    borderBottomWidth: 2
  },
  'bitrate-option--selected::before': {
    borderBottomWidth: 0
  },
  'bitrate-option--selected': {
    borderBottomWidth: 2,
    backgroundColor: '#303030',
    borderColor: '#FFFFFF'
  },
  'bitrate-option--selected::after': {
    borderTopWidth: 0
  },
  'modal-container': {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 0,
    width: '100%',
    height: '100%'
  },
  'close-modal': {
    position: 'absolute',
    right: 50,
    top: 10
  }
})

export { BITRATES, Q_adaptive, Q_360p, Q_240p, Q_540p }

export default BitrateButton
