import React from 'react'
import { string, func } from 'prop-types'
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native'
import Icon from 'react-native-vector-icons/Ionicons'

function ControlButton(props) {
  return (
    <TouchableOpacity style={styles['control-button']} onPress={props.onPress}>
      <View style={styles['control-button-icon']}>
        <Icon name={props.iconName} color="white" size={30} />
      </View>
      <Text style={styles['control-button-label']}>{props.label}</Text>
    </TouchableOpacity>
  )
}

ControlButton.propTypes = {
  iconName: string,
  onPress: func,
  label: string
}

const styles = StyleSheet.create({
  'control-button': {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1
  },
  'control-button-icon': {
    borderStyle: 'solid',
    borderRadius: 50,
    borderColor: 'white',
    borderWidth: 3,
    height: 100,
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 19
  },
  'control-button-label': {
    color: 'white',
    textAlign: 'center',
    fontSize: 13
  }
})

export default ControlButton
