import React, { useState, useEffect, useRef } from 'react'
import { object, func } from 'prop-types'
import { StyleSheet } from 'react-native'
import {
  AirPlay,
  AirPlayButton,
  AirPlayListener
} from 'react-native-airplay-btn'
import debounce from 'lodash.debounce'

function StreamButton(props) {
  const [available, setAvailable] = useState(true)

  const airPlayAvailable = useRef(
    AirPlayListener.addListener(
      'airplayAvailable',
      debounce((devices) => {
        setAvailable(devices.available)
      }, 100)
    )
  )
  const airPlayConnected = useRef(
    AirPlayListener.addListener(
      'airplayConnected',
      debounce((devices) => {
        console.log({ devices })
      }, 100)
    )
  )

  useEffect(() => {
    AirPlay.startScan()
    return () => {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      airPlayAvailable.current && airPlayAvailable.current.remove()
      // eslint-disable-next-line react-hooks/exhaustive-deps
      airPlayConnected.current && airPlayConnected.current.remove()
    }
  }, [])

  return (
    available && (
      <AirPlayButton style={[props.style, styles['airplay-button']]} />
    )
  )
}

StreamButton.propTypes = {
  style: object,
  onSelectStream: func,
  onCancelStream: func
}

const styles = StyleSheet.create({
  'airplay-button': {
    height: 30,
    width: 30,
    justifyContent: 'center',
    alignItems: 'center',
    color: 'red'
  }
})

StreamButton.defaultProps = {}

export default StreamButton
