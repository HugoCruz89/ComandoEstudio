import React, { PureComponent } from 'react'
import { func, array, bool } from 'prop-types'
import { TouchableOpacity, View, StyleSheet } from 'react-native'
import Video from 'react-native-video'
import Orientation from 'react-native-orientation'
import { AirPlay } from 'react-native-airplay-btn'
import { Bubbles } from 'react-native-loader'

import BitrateButton from './BitrateButton'
import StreamButton from './StreamButton'
import ControlButton from './ControlButton'
import TimeSeekButton, { FORWARD_10, REPLAY_10 } from './TimeSeekButton'
import TimeLine from './TimeLine'

class VideoPlayer extends PureComponent {
  state = {
    duration: 0.0,
    currentTime: 0.0,
    paused: !this.props.autoplay,
    isBuffering: false,
    isLoading: false,
    showControls: false,
    controlsCounterId: null,
    bitrate:
      Array.isArray(this.props.bitrateList) && this.props.bitrateList.length
        ? this.props.bitrateList[0]
        : null
  }

  playerRef = React.createRef()

  componentDidMount() {
    Orientation.lockToLandscape()
  }

  componentWillUnmount() {
    AirPlay.disconnect()
    Orientation.lockToPortrait()
  }

  initializeBitrate = () => {
    this.setState({ bitrate: this.props.bitrateList[0] })
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.bitrateList !== this.props.bitrateList &&
      this.state.bitrate === null &&
      Array.isArray(this.props.bitrateList) &&
      this.props.bitrateList.length
    ) {
      this.initializeBitrate()
    }
  }

  onProgress = (data) => {
    this.setState(
      {
        currentTime: data.currentTime,
        isLoading: data.playableDuration === 0 && !this.state.paused
      },
      () => {
        this.props.onProgress?.(
          data.playableDuration === 0 && !this.state.paused ? null : data
        )
      }
    )
  }

  onBuffer = ({ isBuffering }) => {
    this.setState({ isBuffering })
  }

  clearControlsTimeout = (extId) => {
    const { controlsCounterId } = this.state
    const cb = () => clearTimeout(extId || controlsCounterId)

    extId ? cb() : this.setState({ controlsCounterId: null }, cb)
  }

  setControlsTimeout = () => {
    return setTimeout(
      () => this.setState({ showControls: false, controlsCounterId: null }),
      5000
    )
  }

  resetControlsTimeout = () => {
    const counterId = this.setControlsTimeout()
    this.setState({ controlsCounterId: counterId })
  }

  handleScreenTouch = () => {
    const counterId = this.setControlsTimeout()

    this.state.showControls
      ? this.setState(
          { showControls: false, controlsCounterId: null },
          this.clearControlsTimeout(counterId)
        )
      : this.setState({ showControls: true, controlsCounterId: counterId })
  }

  handleBitrateChange = (bitrate) => {
    this.setState({ showControls: false, bitrate })
  }

  handleVideoSeek = (time) => {
    this.playerRef.current?.seek(time)
  }

  handleVideoPlay = () => {
    this.setState((prevState) => ({ paused: !prevState.paused }))
  }

  onLoadStart = () => {
    this.setState({ isLoading: true }, () => {
      this.state.currentTime &&
        this.playerRef.current?.seek(this.state.currentTime)
    })
  }

  onLoad = (data) => {
    this.setState({
      isLoading: false,
      duration: data.duration
    })
  }

  onEnd = () => {
    this.setState({ isLoading: false, showControls: true }, this.props.onEnd)
  }
  render() {
    const { paused } = this.state
    return (
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.fullScreen}
          onPress={this.handleScreenTouch}>
          <Video
            ref={this.playerRef}
            style={styles.fullScreen}
            ignoreSilentSwitch="ignore"
            onLoadStart={this.onLoadStart}
            fullscreenOrientation="landscape"
            resizeMode="contain"
            allowsExternalPlayback
            playInBackground
            source={this.state.bitrate}
            paused={paused}
            onLoad={this.onLoad}
            onBuffer={this.onBuffer}
            onProgress={this.onProgress}
            onEnd={this.onEnd}
          />
        </TouchableOpacity>
        {this.state.showControls && (
          <View
            style={[styles.fullScreen, styles.controls]}
            // onPress={this.handleScreenTouch}
          >
            <View style={styles['video-options']}>
              {this.props.bitrateList && this.props.bitrateList.length ? (
                <BitrateButton
                  bitrate={this.state.bitrate}
                  bitrateList={this.props.bitrateList}
                  onBitrateSelect={this.handleBitrateChange}
                  onBitrateModalOpen={this.clearControlsTimeout}
                  onBitrateModalClose={this.resetControlsTimeout}
                />
              ) : null}
              <StreamButton style={styles['stream-button']} />
            </View>
            <View style={styles['video-actions']}>
              <View style={styles['action-group']}>
                <TimeSeekButton
                  type={REPLAY_10}
                  duration={this.state.duration}
                  currentTime={this.state.currentTime}
                  handleVideoSeek={this.handleVideoSeek}
                />
                <ControlButton
                  iconName={paused ? 'play' : 'pause'}
                  onPress={this.handleVideoPlay}
                  label={paused ? 'Continuar' : 'Pausar'}
                />
              </View>
              <View style={styles['action-group']}>
                <ControlButton
                  iconName="close"
                  label="Quitar clase"
                  onPress={this.props.onVideoAbort}
                />
                <TimeSeekButton
                  type={FORWARD_10}
                  duration={this.state.duration}
                  currentTime={this.state.currentTime}
                  handleVideoSeek={this.handleVideoSeek}
                />
              </View>
            </View>
          </View>
        )}
        {this.state.isLoading && <Bubbles color="white" />}
        <TimeLine
          style={styles['time-line']}
          duration={this.state.duration}
          currentTime={this.state.currentTime}
          onSlidingComplete={(ct) => {
            this.handleVideoSeek(ct)
            this.setState({ isLoading: true })
          }}
        />
      </View>
    )
  }
}

VideoPlayer.propTypes = {
  autoplay: bool,
  bitrateList: array,
  onVideoEnds: func,
  onVideoAbort: func,
  onVideoPlay: func,
  onVideoMove: func
}

VideoPlayer.defaultProps = {
  autoplay: true
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'black'
  },
  fullScreen: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0
  },
  controls: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center'
  },
  'video-options': {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingRight: 20,
    paddingTop: 20
  },
  'stream-button': { marginLeft: 34 },
  'video-actions': {
    alignSelf: 'center',
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center'
  },
  'action-group': {
    width: 180,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  'time-line': {
    position: 'absolute',
    bottom: 25,
    left: 4,
    right: 4
  }
})

export default VideoPlayer
