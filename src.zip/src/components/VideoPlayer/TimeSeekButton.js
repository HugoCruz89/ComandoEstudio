import React from 'react'
import { oneOf, func, number } from 'prop-types'
import { TouchableOpacity, StyleSheet } from 'react-native'
import Icon from 'react-native-vector-icons/MaterialIcons'

const FORWARD_10 = 'FORWARD_10'

const REPLAY_10 = 'REPLAY_10'

const iconName = {
  [FORWARD_10]: 'forward-10',
  [REPLAY_10]: 'replay-10'
}

const timeResult = {
  [FORWARD_10]: (currentTime, duration) => {
    const newTime = currentTime + 10
    return newTime > duration ? duration : newTime
  },
  [REPLAY_10]: (currentTime) => {
    const newTime = currentTime - 10
    return newTime < 0 ? 0 : newTime
  }
}

function TimeSeekButton(props) {
  function handleTimeSeek() {
    const time = timeResult[props.type](props.currentTime, props.duration)

    props.handleVideoSeek && props.handleVideoSeek(time)
  }

  return (
    <TouchableOpacity style={styles.button}>
      <Icon
        name={iconName[props.type]}
        onPress={handleTimeSeek}
        color="white"
        size={50}
      />
    </TouchableOpacity>
  )
}

TimeSeekButton.propTypes = {
  currentTime: number,
  duration: number,
  type: oneOf([FORWARD_10, REPLAY_10]),
  handleVideoSeek: func
}

TimeSeekButton.defaultProps = {
  type: FORWARD_10
}

const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    bottom: 18
  }
})

export { FORWARD_10, REPLAY_10 }

export default TimeSeekButton
