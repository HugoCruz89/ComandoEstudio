import React, { useEffect, useState } from 'react'
import { number, object } from 'prop-types'
import { View, StyleSheet } from 'react-native'
import Slider from 'react-native-reanimated-slider'
import { useValue } from 'react-native-reanimated'
import Text from 'components/Text'

function TimeLine(props) {
  function getFormatedClock(duration) {
    let durationFloor = Math.floor(duration)

    let hours = Math.floor(durationFloor / 3600)

    durationFloor -= hours * 3600

    let minutes = Math.floor(durationFloor / 60)

    durationFloor -= minutes * 60

    let seconds = durationFloor

    hours = hours ? (hours > 0 && hours < 10 ? `0${hours}:` : `${hours}:`) : ''

    minutes = minutes
      ? minutes > 0 && minutes < 10
        ? `0${minutes}:`
        : `${minutes}:`
      : '00:'

    seconds = seconds
      ? seconds > 0 && seconds < 10
        ? `0${seconds}`
        : `${seconds}`
      : '00'

    return `${hours}${minutes}${seconds}`
  }

  const totalDuration = getFormatedClock(props.duration - props.currentTime)

  const { currentTime, duration } = props
  const animatedMin = useValue(0)
  const animatedCT = useValue(currentTime)
  const animatedDR = useValue(duration)
  const [isDragged, setIsDragged] = useState(false)

  useEffect(() => {
    animatedCT.setValue(currentTime)
  }, [currentTime, animatedCT])

  useEffect(() => {
    animatedDR.setValue(duration)
  }, [duration, animatedDR])

  function slidingStart() {
    setIsDragged(true)
    props.onSlidingStart?.()
  }

  function slidingComplete(ct) {
    setIsDragged(false)
    animatedCT.setValue(ct)
    props.onSlidingComplete?.(ct)
  }

  return (
    <View style={[props.style, styles.container]}>
      <Slider
        style={styles['time-line']}
        minimumTrackTintColor="#FFFFFF"
        maximumTrackTintColor="#000000"
        thumbTintColor={isDragged ? '#FFFFFF' : 'transparent'}
        borderColor="transparent"
        ballon={(value) => getFormatedClock(value)}
        progress={animatedCT}
        min={animatedMin}
        max={animatedDR}
        onSlidingStart={slidingStart}
        onSlidingComplete={slidingComplete}
      />
      <Text color="white" style={styles.duration}>
        {totalDuration}
      </Text>
    </View>
  )
}

TimeLine.propTypes = {
  currentTime: number,
  duration: number,
  style: object
}

TimeLine.defaultProps = {
  currentTime: 0,
  duration: 0
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 20,
    paddingRight: 20
  },
  'time-line': {
    flex: 1,
    flexDirection: 'row',
    marginRight: 20
  },
  'progress-completed': {
    height: 6,
    backgroundColor: '#FFFFFF'
  },
  'progress-remaining': {
    height: 6,
    backgroundColor: '#000000'
  },
  duration: {
    fontWeight: 'bold'
  }
})

export default TimeLine
