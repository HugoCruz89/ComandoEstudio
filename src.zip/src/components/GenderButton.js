import React from 'react'
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native'
import { bool, string, func } from 'prop-types'
const GenderButton = (props) => {
  return (
    <TouchableOpacity onPress={props.onChecked.bind(this, props.checked)}>
      {props.checked ? (
        <View style={styles.container}>
          <View style={styles.SquareButtonChecked}>
            <View style={styles.imageContainer}>
              {props.Text === 'Soy hombre' ? (
                <Image
                  style={styles.logo}
                  source={require('./../media/images/whiteMan.png')}
                />
              ) : (
                <Image
                  style={styles.logo}
                  source={require('./../media/images/femaleWhite.png')}
                />
              )}
            </View>
          </View>
        </View>
      ) : (
        <View style={styles.container}>
          <View style={styles.SquareButton}>
            <View style={styles.imageContainer}>
              {props.Text === 'Soy hombre' ? (
                <Image
                  style={styles.logo}
                  source={require('./../media/images/MenCheck.png')}
                />
              ) : (
                <Image
                  style={styles.logo}
                  source={require('./../media/images/WomanCheck.png')}
                />
              )}
            </View>
          </View>
        </View>
      )}
    </TouchableOpacity>
  )
}

GenderButton.prototypes = {
  checked: bool,
  Text: string,
  onChecked: func
}

const styles = StyleSheet.create({
  container: {
    width: '100%'
  },
  SquareButtonChecked: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: 117,
    height: 117,
    borderRadius: 60,
    backgroundColor: '#000000',
    borderColor: '#ACACAC',
    borderWidth: 1,
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4
  },
  SquareButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: 117,
    height: 117,
    borderRadius: 60,
    backgroundColor: 'white',
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.18,
    shadowRadius: 1.0,
    elevation: 1
  },
  logo: {
    width: 30,
    height: 60,
    position: 'relative'
  },
  imageContainer: {
    alignSelf: 'center'
  }
})

export default GenderButton
