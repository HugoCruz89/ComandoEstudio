import React from 'react'
import { oneOf, func, string } from 'prop-types'
import { StyleSheet, View, TouchableOpacity } from 'react-native'
import { Text } from 'components'

const LiveClassDayButton = (props) => {
  let isToday =
    props.check === true ? { borderBottomWidth: 3, borderColor: '#FC3838' } : {}

  return (
    <TouchableOpacity
      onPress={props.DayHandler.bind(this, props.id, props.DateWord)}>
      <View style={[styles.container, isToday]}>
        <View style={[styles.bullet, styles[`bullet--${props.time}`]]}>
          <Text style={[styles.bulletDay, styles[`bulletDay--${props.time}`]]}>
            {props.numberDay}
          </Text>
        </View>
        <Text style={styles.word} textAlign="center">
          {props.word}
        </Text>
      </View>
    </TouchableOpacity>
  )
}

LiveClassDayButton.propTypes = {
  time: oneOf(['false', 'true']),
  status: oneOf(['DAY_OFF', 'COMPLETE', 'INCOMPLETE', 'PENDING']),
  DayHandler: func,
  word: string,
  DateWord: string
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingBottom: 5,
    marginLeft: 27
  },
  bullet: {
    width: 25,
    height: 25,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center'
  },
  bulletDay: {
    fontWeight: 'bold',
    color: 'black'
  },
  [`bullet--${'true'}`]: {
    backgroundColor: '#FC3838',
    borderColor: '#FC3838',
    color: 'white'
  },
  [`bullet--${'FUTURE'}`]: {
    backgroundColor: '#FFFFFF',
    borderColor: '#FC3838'
  },
  [`bulletDay--${'PRESENT'}`]: {
    color: 'white'
  },
  word: {
    width: '100%'
  }
})

export default LiveClassDayButton
