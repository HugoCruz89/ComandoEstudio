import React from 'react'
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native'
import { bool, string, func } from 'prop-types'

const PreferencesButton = (props) => {
  return (
    <View style={styles.ContainerRadioButton}>
      <TouchableOpacity onPress={props.onChecked.bind(this, props.checked)}>
        {props.checked ? (
          <View style={{ ...styles.checkedSquare, ...props.style }}>
            <Text
              key={props.Key}
              style={{ ...styles.TextFontChecked, ...props.style }}
              type="body">
              {props.Text}
            </Text>
          </View>
        ) : (
          <View style={{ ...styles.square, ...props.style }}>
            <Text
              key={props.Key}
              style={{ ...styles.TextFontUnChecked, ...props.style }}
              type="body">
              {props.Text}
            </Text>
          </View>
        )}
      </TouchableOpacity>
    </View>
  )
}

PreferencesButton.prototypes = {
  checked: bool,
  Text: string,
  onChecked: func
}

const styles = StyleSheet.create({
  square: {
    paddingTop: 3,
    paddingLeft: 20,
    paddingRight: 20,
    margin: 4,
    height: 27,
    borderRadius: 4,
    backgroundColor: '#eeee'
  },
  checkedSquare: {
    paddingTop: 3,
    paddingLeft: 20,
    paddingRight: 20,
    margin: 4,
    height: 27,
    backgroundColor: 'black',
    borderRadius: 4
  },
  TextFontUnChecked: {
    fontSize: 15
  },
  TextFontChecked: {
    fontSize: 15,
    color: 'white'
  }
})
export default PreferencesButton
