import React from 'react'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import { bool, string, oneOf, func, number } from 'prop-types'
import TextForm from './../components/Text'
import {
  SvgArm,
  SvgArmWhite,
  SvgFlame,
  SvgFlameWhite,
  SvgLightning,
  SvgLightningWhite,
  SvgRun,
  SvgRunWhite,
  SvgWeight,
  SvgWeightWhite
} from '../media/images/svg/ObjetiveIcons'

const ObectivesButton = (props) => {
  let textEdit = null
  switch (props.enable) {
    case true:
      textEdit = (
        <TextForm style={{ ...styles.Text, ...props.style }} type="body">
          {props.description}
        </TextForm>
      )
      break
    case false:
      textEdit = (
        <TextForm style={{ ...styles.TextDisable, ...props.style }} type="body">
          {props.description}
        </TextForm>
      )
  }
  let icon = null
  let iconWhite = null
  switch (props.image) {
    case 'flame':
      icon = <SvgFlame />
      iconWhite = <SvgFlameWhite />
      break
    case 'arm':
      icon = <SvgArm />
      iconWhite = <SvgArmWhite />
      break
    case 'run':
      icon = <SvgRun />
      iconWhite = <SvgRunWhite />
      break
    case 'weight':
      icon = <SvgWeight />
      iconWhite = <SvgWeightWhite />
      break
    case 'lightning':
      icon = <SvgLightning />
      iconWhite = <SvgLightningWhite />
      break
    default:
      break
  }
  return (
    <TouchableOpacity
      style={styles.ContainerButton}
      onPress={props.onCheckListObjective.bind(this, props.id)}>
      {props.checked ? (
        <View style={styles.SquareButtonChecked}>
          <View style={styles.ContainerText}>
            <TextForm
              style={{ ...styles.TextChecked, ...props.style }}
              type="body">
              {props.description}
            </TextForm>
          </View>
          <View style={styles.ContainerIcon}>
            <View>{iconWhite}</View>
          </View>
        </View>
      ) : (
        <View style={styles.SquareButton}>
          <View style={styles.ContainerText}>{textEdit}</View>

          <View style={styles.ContainerIcon}>
            <View>{icon}</View>
          </View>
        </View>
      )}
    </TouchableOpacity>
  )
}

ObectivesButton.prototypes = {
  image: string,
  checked: bool,
  Text: string,
  onChecked: func,
  id: number,
  enable: bool
}

const styles = StyleSheet.create({
  SquareButtonChecked: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '95%',
    height: 60,
    backgroundColor: 'black',
    paddingLeft: 18,
    paddingRight: 20.09,
    borderColor: '#ACACAC',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.07,
    shadowRadius: 3.0,
    elevation: 2
  },
  SquareButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '95%',
    height: 60,
    backgroundColor: 'white',
    paddingLeft: 18,
    paddingRight: 20.09,
    borderColor: '#eeeeee',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.07,
    shadowRadius: 3.0,
    elevation: 2
  },
  square: {
    height: 25,
    width: 25,
    borderRadius: 0,
    borderWidth: 1,
    borderColor: '#eeeeee',
    alignItems: 'center', //To center the checked circle...
    justifyContent: 'center',
    marginHorizontal: 10,
    backgroundColor: '#eeee'
  },
  checkedSquare: {
    width: 25,
    height: 25,
    backgroundColor: 'transparent' //you can set it default or with yours
  },
  TextChecked: {
    fontSize: 14,
    color: 'white',
    fontWeight: '700'
  },
  Text: {
    fontSize: 14,
    color: '#000000',
    fontWeight: '700'
  },
  TextDisable: {
    fontSize: 14,
    color: '#DADADA',
    fontWeight: '700'
  },
  ContainerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
    width: '100%',
    height: 55
  },
  ContainerIcon: {},
  ContainerText: {}
})

export default ObectivesButton
