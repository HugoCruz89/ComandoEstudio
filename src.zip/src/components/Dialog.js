import React from 'react'
import { Button, Text } from 'components'
import {
  View,
  Modal,
  Image,
  StyleSheet,
  TouchableHighlight
} from 'react-native'
import { string, func, bool, any, oneOf } from 'prop-types'

const Dialog = ({
  children,
  visible,
  visibleLoad,
  type,
  title,
  image,
  hideHandle,
  aceptHandler
}) => {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible || visibleLoad}
      onRequestClose={hideHandle}>
      {visibleLoad ? (
        <View style={styles.containerLoad}>
          <View style={styles.dialogLoad}>{children}</View>
        </View>
      ) : (
        <View style={styles.container}>
          <View style={styles.dialog}>
            <Text style={styles.title}>{title}</Text>
            {image && (
              <Image
                style={styles.logoStyle}
                resizeMode="contain"
                source={image}
              />
            )}
            {children}
            <View style={styles.footer}>
              {type === 'alarm' && (
                <Button theme="primary" title="Ok" onPress={aceptHandler} />
              )}
              {type === 'prompt' && (
                <>
                  <TouchableHighlight style={styles.buttonContainer}>
                    <Text style={styles.buttonText}>Cancelar</Text>
                  </TouchableHighlight>
                  <TouchableHighlight style={styles.buttonContainer}>
                    <Text style={styles.buttonText}>Aceptar</Text>
                  </TouchableHighlight>
                </>
              )}
            </View>
          </View>
        </View>
      )}
    </Modal>
  )
}

export default Dialog

Dialog.propTypes = {
  children: any,
  visible: bool,
  type: oneOf(['alarm', 'prompt']),
  title: string,
  image: any,
  hideHandle: func,
  aceptHandler: func,
  visibleLoad: bool,
  titleLoad: string
}

Dialog.defaultProps = {
  type: 'alarm',
  title: '',
  titleLoad: '',
  visible: false,
  visibleLoad: false
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(52, 52, 52, 0.4)'
  },
  containerLoad: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(52, 52, 52, 0.4)'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textTransform: 'uppercase'
  },
  titleLoad: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: 'bold',
    textTransform: 'uppercase'
  },
  dialog: {
    backgroundColor: 'white',
    width: '80%',
    alignItems: 'center',
    paddingTop: 30,
    paddingBottom: 15,
    paddingHorizontal: 15
  },
  dialogLoad: {
    backgroundColor: 'white',
    width: '80%',
    height: '40%',
    alignItems: 'center',
    paddingTop: '39%',
    paddingBottom: 15,
    paddingHorizontal: 15
  },
  logoStyle: {
    width: 50,
    margin: 10
  },
  footer: {
    flexDirection: 'row',
    marginTop: 30,
    width: '90%',
    justifyContent: 'space-between',
    alignContent: 'space-around'
  },
  buttonContainer: {
    borderWidth: 2,
    paddingVertical: 10,
    paddingHorizontal: 20
  },
  buttonText: {
    textTransform: 'uppercase',
    fontWeight: 'bold',
    fontSize: 14
  }
})
