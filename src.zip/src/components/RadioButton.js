import React from 'react'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import { bool, string, oneOf, func } from 'prop-types'
import TextForm from './../components/Text'
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'
const checkIcon = <Icon name="check" size={24} color="white" />

const RadioButton = (props) => {
  return (
    <View style={styles.ContainerRadioButton}>
      {props.CheckButtonType === 'RadioButton' ? (
        <TouchableOpacity
          style={styles.circle}
          onPress={props.onChecked.bind(this, props.checked)}>
          {props.checked ? <View style={styles.checkedCircle} /> : <View />}
        </TouchableOpacity>
      ) : (
        <TouchableOpacity
          style={styles.square}
          onPress={props.onChecked.bind(this, props.checked)}>
          {props.checked ? (
            <View style={styles.checkedSquare}>{checkIcon}</View>
          ) : (
            <View />
          )}
        </TouchableOpacity>
      )}
      <TextForm
        style={{ ...styles.TextFontGender, ...props.style }}
        type="body">
        {props.Text}
      </TextForm>
    </View>
  )
}

RadioButton.prototypes = {
  checked: bool,
  Text: string,
  CheckButtonType: oneOf(['RadioButton', 'CheckButton']),
  onChecked: func
}

const styles = StyleSheet.create({
  circle: {
    height: 25,
    width: 25,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#ACACAC',
    alignItems: 'center', //To center the checked circle...
    justifyContent: 'center',
    marginHorizontal: 10,
    backgroundColor: 'transparent'
  },
  checkedCircle: {
    borderWidth: 7,
    width: 25,
    height: 25,
    borderRadius: 12,
    backgroundColor: 'white' //you can set it default or with yours
  },
  square: {
    height: 25,
    width: 25,
    borderRadius: 0,
    borderWidth: 1,
    borderColor: '#ACACAC',
    alignItems: 'center', //To center the checked circle...
    justifyContent: 'center',
    marginHorizontal: 10,
    backgroundColor: '#eeee'
  },
  checkedSquare: {
    width: 25,
    height: 25,

    backgroundColor: 'black' //you can set it default or with yours
  },
  TextFontGender: {
    fontSize: 17
  },
  ContainerRadioButton: {
    flexDirection: 'row'
  }
})

export default RadioButton
