import React from 'react'
import { View, Text, StyleSheet } from 'react-native'
import { string, bool } from 'prop-types'

const TabBarLabel = ({ color, focused, title }) => {
  const titleVarible = {
    color,
    marginBottom: focused ? 5 : 10
  }
  return (
    <View style={styles.container}>
      <Text style={[styles.title, titleVarible]}>{title}</Text>
      {focused && (
        <View
          style={[
            styles.ball,
            {
              backgroundColor: color
            }
          ]}
        />
      )}
    </View>
  )
}

TabBarLabel.propTypes = {
  color: string,
  title: string,
  focused: bool
}

export default TabBarLabel

const styles = StyleSheet.create({
  container: {
    alignItems: 'center'
  },
  title: {
    fontFamily: 'Lato',
    fontSize: 9,
    textTransform: 'uppercase'
  },
  ball: {
    height: 5,
    width: 5,
    borderRadius: 2.5
  }
})
