import * as React from 'react'
import { StyleSheet, View } from 'react-native'
import Animated from 'react-native-reanimated'
import Cursor from './Cursor'
import Labels from './Labels'

const { useValue, max, sub } = Animated

export default ({
  totalHeight,
  steps,
  levelActivity,
  activeCallback,
  endCallback
}) => {
  const firstBall = 40
  const size = (totalHeight - firstBall) / (steps - 1)
  const initialIndex = (steps - levelActivity - 1) * size
  const width = 110
  const y = useValue(initialIndex)

  return (
    <View
      style={[
        {
          width,
          height: totalHeight
        },
        styles.container
      ]}>
      <Animated.View
        style={[
          {
            height: sub(totalHeight - firstBall, y),
            left: width / 2 - 1
          },
          styles.backLine
        ]}
      />
      <Animated.View
        style={[
          {
            height: max(y, 0),
            left: width / 2 - 1
          },
          styles.fillLine
        ]}
      />
      <Labels steps={steps - 1} {...{ y, size }} />
      <Cursor
        {...{
          y,
          size,
          steps,
          initialIndex,
          width,
          activeCallback,
          endCallback
        }}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center'
  },
  fillLine: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#8C8C8C',
    width: 1
  },
  backLine: {
    width: 2,
    position: 'absolute',
    bottom: 40,
    right: 0,
    backgroundColor: '#000000'
  }
})
