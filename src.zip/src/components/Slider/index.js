export { default } from './Slider'
