import * as React from 'react'
import { StyleSheet, View } from 'react-native'
import { mixColor } from 'react-native-redash/lib/module/v1'
import Animated from 'react-native-reanimated'

const { cond, lessOrEq, add, round, divide } = Animated

export default ({ steps, y, size }) => {
  const index = add(round(divide(add(y, size / 2), size)), 1)
  return (
    <View style={styles.container}>
      {new Array(steps).fill(0).map((e, i) => {
        const color = mixColor(
          cond(lessOrEq(index, i + 1), 0, 1),
          '#000000',
          '#8C8C8C'
        )
        return (
          <View key={i} style={styles.ballContainer}>
            <Animated.View style={[{ backgroundColor: color }, styles.ball]} />
          </View>
        )
      })}
      <View style={styles.firstBallContainer}>
        <View style={[styles.firstBall, styles.ball]} />
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center'
  },
  ballContainer: {
    flex: 1
  },
  ball: {
    height: 14,
    width: 14,
    borderRadius: 7
  },
  firstBallContainer: {
    height: 40
  },
  firstBall: {
    backgroundColor: 'black'
  }
})
