import * as React from 'react'
import { StyleSheet } from 'react-native'
import {
  clamp,
  onGestureEvent,
  snapPoint,
  timing
} from 'react-native-redash/lib/module/v1'
import Animated from 'react-native-reanimated'
import { PanGestureHandler, State } from 'react-native-gesture-handler'
import LinearGradient from 'react-native-linear-gradient'

const {
  useValue,
  add,
  round,
  divide,
  sub,
  cond,
  eq,
  set,
  call,
  useCode
} = Animated
const cursorBall = 30

export default ({
  size,
  steps,
  y,
  initialIndex,
  width,
  activeCallback,
  endCallback
}) => {
  const snapPoints = new Array(steps).fill(0).map((e, i) => i * size)
  const arrowSize = useValue(0)
  const translationY = useValue(0)
  const velocityY = useValue(0)
  const state = useValue(State.UNDETERMINED)
  const gestureHandler = onGestureEvent({ state, translationY, velocityY })
  const offset = useValue(initialIndex)
  const value = add(offset, translationY)
  const translateY = clamp(
    cond(
      eq(state, State.END),
      set(
        offset,
        timing({
          from: value,
          to: snapPoint(value, velocityY, snapPoints)
        })
      ),
      value
    ),
    0,
    (steps - 1) * size
  )

  useCode(() => set(y, translateY), [y, translateY])

  const index = round(divide(y, size))

  useCode(
    () =>
      cond(
        eq(state, State.END),
        call([index], ([v]) => {
          arrowSize.setValue(0)
          endCallback(steps - v - 1)
        })
      ),
    [state, index]
  )

  useCode(
    () =>
      cond(
        eq(state, State.ACTIVE),
        call([index], ([v]) => {
          arrowSize.setValue(10)
          activeCallback(steps - v - 1)
        })
      ),
    [state, index]
  )

  return (
    <PanGestureHandler {...gestureHandler}>
      <Animated.View
        style={[
          {
            marginLeft: width / 2 - cursorBall / 2,
            transform: [{ translateY: y }]
          },
          styles.cursor
        ]}>
        <Animated.View
          style={[
            {
              width: add(cursorBall, arrowSize),
              height: add(cursorBall, arrowSize),
              borderRadius: divide(add(cursorBall, arrowSize), 2),
              marginTop: sub(-6, divide(arrowSize, 2)),
              marginLeft: sub(0, divide(arrowSize, 2)),
              borderWidth: divide(add(10, arrowSize), 2)
            },
            styles.halo
          ]}>
          <LinearGradient
            colors={['rgb(88, 88, 88)', 'rgb(0,0,0)']}
            start={{ x: 0, y: 0.03 }}
            end={{ x: 0, y: 1 }}
            style={styles.ball}
          />
        </Animated.View>
      </Animated.View>
    </PanGestureHandler>
  )
}

const styles = StyleSheet.create({
  cursor: {
    ...StyleSheet.absoluteFillObject,
    width: cursorBall,
    height: cursorBall,
    borderRadius: cursorBall / 2
  },
  ball: {
    width: cursorBall - 10,
    height: cursorBall - 10,
    borderRadius: (cursorBall - 10) / 2
  },
  halo: {
    borderColor: 'rgba(224, 224, 224, 0.8)',
    justifyContent: 'center',
    alignItems: 'center'
  }
})
