import React, { useState } from 'react'
import { TouchableOpacity, StyleSheet, Animated } from 'react-native'

const duration = 350
const useNativeDriver = true

const Switch = ({ value, onValueChange }) => {
  const animatedSwitchValue = useState(new Animated.Value(value ? 1 : 0))[0]

  function handleSwitchToggle() {
    Animated.timing(animatedSwitchValue, {
      toValue: value ? 0 : 1,
      duration,
      useNativeDriver
    }).start()
  }

  return (
    <TouchableOpacity
      onPress={() => {
        onValueChange()
        handleSwitchToggle()
      }}
      style={styles.container}>
      <Animated.View
        style={[styles.toggle, styles['animated-container']](
          value ? '#000000' : '#DADADA',
          animatedSwitchValue.interpolate({
            inputRange: [0, 1],
            outputRange: [0, 38]
          })
        )}
      />
    </TouchableOpacity>
  )
}

export default Switch

const styles = StyleSheet.create({
  container: {
    height: 36,
    width: 80,
    justifyContent: 'center',
    paddingHorizontal: 6,
    borderRadius: 18,
    backgroundColor: '#F5F5F5'
  },
  toggle: {
    height: 30,
    width: 30,
    borderRadius: 15
  },
  'animated-container'(backgroundColor, translateX) {
    return {
      backgroundColor,
      transform: [
        {
          translateX
        }
      ]
    }
  }
})
