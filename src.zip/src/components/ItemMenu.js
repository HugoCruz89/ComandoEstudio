import React from 'react'
import { View, StyleSheet } from 'react-native'
import Text from './Text'
const ItemMenu = (props) => {
  return (
    <View>
      <Text
        style={{ ...styles.text, ...props.style }}
        fontSize={14}
        type="title">
        {props.Title}
      </Text>
    </View>
  )
}
const styles = StyleSheet.create({
  text: {
    textAlign: 'left',
    fontSize: 16,
    fontWeight: '800'
  }
})
export default ItemMenu
