import React, { PureComponent } from 'react'
import { Animated } from 'react-native'
import { string, number } from 'prop-types'

class Collapsible extends PureComponent {
  state = {
    height: new Animated.Value(this.props.value || this.props.initialValue)
  }

  componentDidUpdate(prevProps) {
    const { value } = this.props
    if (prevProps.value !== value) {
      this.move(value)
    }
  }

  move = (toValue) => {
    const { type, duration } = this.props
    Animated[type](this.state.height, {
      toValue,
      duration,
      useNativeDriver: false
    }).start()
  }

  render() {
    return (
      <Animated.View
        style={[
          this.props.style,
          {
            height: this.state.height
          }
        ]}>
        {this.props.children}
      </Animated.View>
    )
  }
}

Collapsible.propTypes = {
  type: string,
  value: number,
  duration: number,
  initialValue: number
}

Collapsible.defaultProps = {
  type: 'timing',
  duration: 200,
  initialValue: 0
}

export default Collapsible
