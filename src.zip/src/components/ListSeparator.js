import React from 'react'
import { View, StyleSheet } from 'react-native'
import { string } from 'prop-types'

const ListSeparator = ({ color }) => {
  const newColor = color ? color : '#EAEAEA'
  return <View style={[styles.separator, { borderTopColor: newColor }]} />
}

export default ListSeparator

ListSeparator.propTypes = {
  color: string
}

const styles = StyleSheet.create({
  separator: {
    borderTopWidth: 2,
    borderTopColor: '#EAEAEA'
  }
})
