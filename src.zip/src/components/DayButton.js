import React from 'react'
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native'
import { bool, string, func, number } from 'prop-types'
const DayButton = (props) => {
  return (
    <View style={styles.ContainerPrincipal}>
      <TouchableOpacity onPress={props.onChecked.bind(this, props.checked)}>
        {props.checked ? (
          <View style={{ ...styles.checkedSquare, ...props.style }}>
            <Text
              style={{ ...styles.TextFontChecked, ...props.style }}
              type="body">
              {props.Text}
            </Text>
          </View>
        ) : (
          <View style={{ ...styles.square, ...props.style }}>
            <Text
              style={{ ...styles.TextFontUnChecked, ...props.style }}
              type="body">
              {props.Text}
            </Text>
          </View>
        )}
      </TouchableOpacity>
    </View>
  )
}

DayButton.prototypes = {
  checked: bool,
  Text: string,
  onChecked: func,
  key: number
}
const styles = StyleSheet.create({
  ContainerPrincipal: {
    flex: 1
  },
  square: {
    alignItems: 'center',
    justifyContent: 'center',
    margin: 5,
    height: 38,
    width: 34,
    backgroundColor: 'white',
    borderColor: '#eeeeee',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.07,
    shadowRadius: 3.0,
    elevation: 2
  },
  checkedSquare: {
    alignItems: 'center',
    justifyContent: 'center',
    margin: 5,
    height: 38,
    width: 34,
    backgroundColor: '#585858',
    borderColor: '#eeeeee',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.07,
    shadowRadius: 3.0,
    elevation: 2
  },
  TextFontUnChecked: {
    fontSize: 14,
    fontWeight: '700',
    fontFamily: 'Raleway'
  },
  TextFontChecked: {
    fontSize: 14,
    color: 'white',
    fontWeight: '700',
    fontFamily: 'Raleway'
  }
})
export default DayButton
