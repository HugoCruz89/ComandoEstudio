import React, { PureComponent } from 'react'
import { Animated, InteractionManager } from 'react-native'
import PropTypes from 'prop-types'

const propTypes = {
  type: PropTypes.string,
  value: PropTypes.number,
  duration: PropTypes.number,
  initialValue: PropTypes.number,
  animateOnMount: PropTypes.bool,
  useNativeDriver: PropTypes.bool
}

const defaultProps = {
  type: 'timing',
  value: 0,
  duration: 200,
  initialValue: 0,
  animateOnMount: false,
  useNativeDriver: true
}

class TranslateX extends PureComponent {
  constructor(props) {
    super(props)

    const { value, initialValue } = props

    this.state = {
      translateXValue: new Animated.Value(initialValue || value)
    }
  }
  componentDidMount() {
    const { animateOnMount, value } = this.props
    if (animateOnMount) {
      InteractionManager.runAfterInteractions().then(() => {
        this.move(value)
      })
    }
  }
  componentDidUpdate(prevProps) {
    const { value } = this.props

    if (prevProps.value !== value) {
      this.move(value)
    }
  }
  move = (toValue) => {
    const { onMoveDidFinish, type, duration, useNativeDriver } = this.props
    const { translateXValue } = this.state

    Animated[type](translateXValue, {
      toValue,
      duration,
      useNativeDriver
    }).start(onMoveDidFinish)
  }
  render() {
    const { style, children } = this.props
    const { translateXValue } = this.state

    const animatedStyle = {
      transform: [{ translateX: translateXValue }]
    }

    return (
      <Animated.View style={[style, animatedStyle]}>{children}</Animated.View>
    )
  }
}

TranslateX.propTypes = propTypes
TranslateX.defaultProps = defaultProps

export default TranslateX
