import * as React from 'react'
import Svg, { Path } from 'react-native-svg'

const SvgLightning = (props) => {
  return (
    <Svg width={16} height={19} viewBox="0 0 16 19" fill="none" {...props}>
      <Path
        d="M15.515 6.016h-5.033L15.008.297A.184.184 0 0014.864 0H6.102a.181.181 0 00-.157.091L.025 10.315a.182.182 0 00.158.274h3.984l-2.042 8.17c-.044.179.171.304.304.176L15.64 6.33a.182.182 0 00-.126-.313z"
        fill={props.color}
      />
    </Svg>
  )
}

const SvgCalendar = (props) => {
  return (
    <Svg width={19} height={19} viewBox="0 0 17 17" fill="none" {...props}>
      <Path
        d="M2.5 17h11.9c.938 0 1.7-.762 1.7-1.7V3.4c0-.938-.762-1.7-1.7-1.7h-1.7V0H11v1.7H5.9V0H4.2v1.7H2.5c-.938 0-1.7.762-1.7 1.7v11.9c0 .938.762 1.7 1.7 1.7zm5.1-3.048L4.45 10.8 5.65 9.599l1.95 1.95 3.648-3.65 1.202 1.202L7.6 13.95zM2.5 4.25h11.9v1.7H2.5v-1.7z"
        fill={props.color}
      />
    </Svg>
  )
}

const SvgPerson = (props) => {
  return (
    <Svg width={19} height={19} viewBox="0 0 17 17" fill="none" {...props}>
      <Path
        d="M8.5 8.5a4.25 4.25 0 110-8.5 4.25 4.25 0 010 8.5zm0 3.188c3.385 0 6.423.606 8.5 3.254V17H0v-2.058c2.077-2.649 5.115-3.255 8.5-3.255z"
        fill={props.color}
      />
    </Svg>
  )
}

export { SvgLightning, SvgCalendar, SvgPerson }
