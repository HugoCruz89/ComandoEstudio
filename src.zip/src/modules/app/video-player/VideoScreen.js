import React, { Component } from 'react'
import { func, object } from 'prop-types'
import { connect } from 'react-redux'
import VideoPlayer, { BITRATES } from 'components/VideoPlayer'
import { getVideoList, getVideoSource } from 'ducks/app'
import { trackContent } from 'ducks/auth'
import { Platform } from 'react-native'
import Orientation from 'react-native-orientation'

class VideoPlayerScreen extends Component {
  state = {
    loading: true,
    counter: -1,
    bitrates: []
  }

  componentDidMount() {
    this.props.getVideoList(this.props.route.params.id).then((res) => {
      const {
        payload: { files, id }
      } = res

      const getSources = files
        .filter(({ format }) => {
          return Platform.OS === 'ios'
            ? format !== 'mpd'
            : Platform.OS === 'android'
            ? format !== 'm3u8'
            : true
        })
        .map(({ quality, format, codec }) => {
          return () =>
            this.props.getVideoSource(id, {
              quality,
              format,
              codec
            })
        })

      Promise.all(getSources.map((fn) => fn())).then((sourceRes) => {
        const bitrates = sourceRes.map(({ payload: { src: uri }, meta }) => {
          const {
            previousAction: {
              payload: {
                request: {
                  params: { format: type, ...params }
                }
              }
            }
          } = meta
          return { ...params, ...BITRATES[`Q_${params.quality}`], uri, type }
        })
        this.setState({ bitrates, loading: false })
      })
    })
  }

  onVideoAbort = () => {
    Orientation.lockToPortrait()
    setTimeout(() => {
      this.props.navigation.goBack()
    }, 200)
  }

  onProgress = (evt) => {
    if (!evt) return null
    if (this.props.route.params.track) {
      let lastCounter = this.state.counter
      this.setState(
        () => {
          const counter = lastCounter + 1
          return { counter: counter === 5 ? 0 : counter }
        },
        () => {
          if (this.state.counter === 0) {
            const content = this.props.trackedContent?.[
              this.props.route.params.id
            ]
            this.props
              .trackContent?.(
                this.props.route.params.id,
                evt.seekableDuration,
                evt.currentTime,
                lastCounter === -1 ? 0 : content?.secondsPlayed + 5
              )
              .then((res) => console.log({ res }))
          }
        }
      )
    }
  }

  render() {
    return (
      !this.state.loading && (
        <VideoPlayer
          onVideoAbort={this.onVideoAbort}
          bitrateList={this.state.bitrates}
          onProgress={this.onProgress}
        />
      )
    )
  }
}

VideoPlayerScreen.propTypes = {
  getVideoList: func,
  getVideoSource: func,
  trackContent: func,
  trackedContent: object
}

const mapDispatchToProps = {
  getVideoList,
  getVideoSource,
  trackContent
}

const mapStateToProps = ({ auth: { trackedContent: track } }) => ({
  trackedContent: track
})

export default connect(mapStateToProps, mapDispatchToProps)(VideoPlayerScreen)
