export { default } from './ChangePasswordScreen'
