import React, { useState } from 'react'
import { View, StyleSheet, KeyboardAvoidingView } from 'react-native'
import { Header, Button, TextInput } from 'components'
import { useNavigation } from '@react-navigation/native'

const ChangePasswordScreen = ({}) => {
  const navigation = useNavigation()
  const [password, setPassword] = useState('')
  const [passwordError, setPasswordError] = useState('')
  const [passwordConfirm, setPasswordConfirm] = useState('')
  const [passwordConfirmError, setPasswordConfirmError] = useState('')

  const handlePasswordInput = (value) => {
    setPasswordConfirm(value)
  }

  const handlePasswordConfirmInput = (value) => {
    setPassword(value)
  }

  const requestLogin = async () => {
    if (!password || !password.length) {
      setPasswordError('Contraseña invalida')
    } else if (password !== passwordConfirm) {
      setPasswordConfirmError('La contraseña es diferente')
    } else {
      navigation.goBack()
    }
  }

  return (
    <View style={styles.container}>
      <Header title="" />
      <KeyboardAvoidingView behavior="padding" style={styles.formContainer}>
        <View>
          <TextInput
            label="Nueva contraseña"
            name="password"
            key="password"
            clearTextOnFocus
            returnKeyType="next"
            error={passwordError}
            onChangeText={handlePasswordInput}
            secureTextEntry
          />
          <TextInput
            label="Confirmar nueva contraseña"
            name="password"
            key="confirmPassword"
            clearTextOnFocus
            returnKeyType="send"
            error={passwordConfirmError}
            onChangeText={handlePasswordConfirmInput}
            onSubmitEditing={requestLogin}
            secureTextEntry
          />
        </View>

        <Button
          style={{
            text: styles.buttonText,
            container: styles.buttonContainer
          }}
          title="Cambiar contraseña"
          onPress={requestLogin}
        />
      </KeyboardAvoidingView>
    </View>
  )
}

export default ChangePasswordScreen

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingBottom: 30
  },
  formContainer: {
    flex: 1,
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 30,
    marginTop: 43
  },
  buttonContainer: {
    height: 50,
    marginBottom: 30
  },
  buttonText: {
    fontSize: 18,
    fontWeight: '700'
  }
})
