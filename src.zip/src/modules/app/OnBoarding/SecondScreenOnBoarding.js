import React from 'react'
import { View, StyleSheet, Dimensions } from 'react-native'
import TextForm from './../../../components/Text'
import GenderButton from './../../../components/GenderButton'
import { func, number, bool } from 'prop-types'
const windowHeight = Dimensions.get('window').height
const SecondScreenOnBoarding = (props) => {
  return (
    <View style={styles.PrincipalContainer}>
      <TextForm style={styles.Title} type="title">
        ¿CUÁL ES TU GÉNERO?
      </TextForm>

      <View style={{ marginTop: windowHeight * 0.08 }}>
        <View style={styles.ContainerButton}>
          <GenderButton
            onChecked={() => props.onChangeGender('M')}
            checked={props.maleCheck}
            CheckButtonType="RadioButton"
            Text={'Soy hombre'}
            style={styles.TextStyle}
          />
        </View>
        <TextForm style={styles.BodyText} type="body">
          Soy hombre
        </TextForm>
        <View style={styles.ContainerButton}>
          <GenderButton
            Text={'Soy mujer'}
            onChecked={() => props.onChangeGender('F')}
            checked={props.femaleCheck}
            CheckButtonType="RadioButton"
            style={styles.TextStyle}
          />
          <TextForm style={styles.BodyText} type="body">
            Soy mujer
          </TextForm>
        </View>
      </View>
    </View>
  )
}

SecondScreenOnBoarding.propTypes = {
  onChangeGender: func,
  maleCheck: bool,
  femaleCheck: bool,
  blurImageWoman: number,
  blurImageMen: number
}
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1
  },
  ContainerButton: {
    marginTop: 14
  },
  Title: {
    marginTop: 64,
    fontSize: 20,
    color: 'black',
    fontWeight: '800'
  },
  BodyText: {
    fontSize: 14,
    color: 'black',
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 26
  },
  ContainerImages: {
    flexDirection: 'row',
    alignSelf: 'center',
    marginTop: 21
  }
})
export default SecondScreenOnBoarding
