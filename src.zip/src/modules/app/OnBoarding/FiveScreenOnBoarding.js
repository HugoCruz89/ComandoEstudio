import React from 'react'
import { View, StyleSheet, Image, Dimensions } from 'react-native'
import TextForm from './../../../components/Text'
import DayButton from './../../../components/DayButton'
import { array, func } from 'prop-types'
import { windowHeight } from 'src/utils'
const Width = Dimensions.get('window').width
const totalHeight = windowHeight / 2.5
const FiveScreenOnBoarding = (props) => {
  const listDays = props.listDay.map((day, index) => (
    <DayButton
      onChecked={() => props.onCheckListDay(day.id)}
      checked={day.checked}
      Text={day.descripcion}
      key={index}
    />
  ))

  return (
    <View style={styles.PrincipalContainer}>
      <TextForm style={styles.Title} type="title">
        META DE EJERCICIO SEMANAL
      </TextForm>
      <View style={styles.imageContainer}>
        <Image
          style={styles.logo}
          source={require('../../../media/images/WomanWeek.png')}
        />
      </View>
      <View style={styles.BodyTextContainer}>
        <TextForm style={styles.BodyText} type="body">
          Selecciona los días que desees hacer ejercicio.
        </TextForm>
      </View>
      <View style={styles.containerWeek}>{listDays}</View>
      <View style={styles.containerFooder}>
        <TextForm style={styles.BodyText} type="body">
          Recomendamos hacer ejercicio diario, según tu nivel tu intensidad.
        </TextForm>
      </View>
    </View>
  )
}
FiveScreenOnBoarding.propTypes = {
  onCheckListDay: func,
  listDay: array
}
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1
  },
  Title: {
    marginTop: 64,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 20
  },
  BodyTextContainer: {
    alignItems: 'center',
    marginTop: '10%'
  },
  BodyText: {
    textAlign: 'center',
    fontWeight: '400',
    fontSize: 14,
    color: '#8c8c8c'
  },
  containerWeek: {
    flexDirection: 'row',
    marginTop: '10%'
  },
  containerFooder: {
    flexDirection: 'row',
    marginTop: '5%',
    marginHorizontal: 30
  },
  imageContainer: {
    height: totalHeight,
    alignSelf: 'center'
  },
  logo: {
    height: totalHeight + 40,
    width: Width * 0.8,
    resizeMode: 'contain',
    position: 'relative',
    left: 10,
    top: 0
  }
})
export default FiveScreenOnBoarding
