import React from 'react'
import { View, StyleSheet, Text } from 'react-native'
import TextForm from './../../../components/Text'
import { TextInput } from 'components'
import { func, string } from 'prop-types'
const FirstScreenOnBoarding = (props) => {
  return (
    <View style={styles.PrincipalContainer}>
      <TextForm style={styles.Title} type="title">
        CUÉNTANOS SOBRE TÍ
      </TextForm>
      <View style={styles.ContainerInputForm}>
        <Text style={styles.measurement}>kg</Text>
        <TextInput
          autoCapitalize="none"
          value={props.weight}
          label="Peso"
          keyboardType="number-pad"
          onChangeText={(text) => props.onChangeWeight(text)}
          error={props.weightError}
          returnKeyType="next"
        />
      </View>
      <View style={styles.ContainerInputForm}>
        <Text style={styles.measurement}>cm</Text>
        <TextInput
          value={props.height}
          label="Altura"
          keyboardType="number-pad"
          onChangeText={(text) => props.onChangeHeight(text)}
          error={props.heightError}
          returnKeyType="next"
        />
      </View>
      <View style={styles.ContainerInputForm}>
        <Text style={styles.measurement}>años</Text>
        <TextInput
          value={props.age}
          label="Edad"
          keyboardType="number-pad"
          onChangeText={(text) => props.onChangeAge(text)}
          error={props.ageError}
          returnKeyType="next"
        />
      </View>
    </View>
  )
}

FirstScreenOnBoarding.propTypes = {
  onChangeWeight: func,
  onChangeHeight: func,
  onChangeAge: func,
  age: string,
  weight: string,
  height: string,
  weightError: string
}
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1
  },
  Title: {
    marginTop: 64,
    fontSize: 20,
    marginBottom: 61,
    color: 'black',
    fontWeight: '800'
  },
  ContainerDataPersonal: {
    marginHorizontal: 28,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  measurement: {
    position: 'absolute',
    right: 0,
    bottom: 25,
    color: '#8C8C8C'
  }
})
export default FirstScreenOnBoarding
