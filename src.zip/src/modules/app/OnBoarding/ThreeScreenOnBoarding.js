import React from 'react'
import { View, StyleSheet } from 'react-native'
import TextForm from './../../../components/Text'
import Slider from './../../../components/Slider/Slider'
import { windowHeight } from 'src/utils'
import { useValue, concat } from 'react-native-reanimated'
import { ReText } from 'react-native-redash/lib/module/v1'

const totalHeight = windowHeight * 0.45

const ThreeScreenOnBoarding = (props) => {
  const steps = 4
  let levelActivity = 0
  const status = useValue('Principiante')
  const label = useValue('Necesito recuperar el alienteo despues de subir')
  const complement = useValue('escaleras')

  function activeCallback(value) {
    if (levelActivity !== value) {
      levelActivity = value
      setValuCallback(value)
    }
  }
  function endCallback(value) {
    props.saveValue(value)
    if (levelActivity !== value) {
      levelActivity = value
      setValuCallback(value)
    }
  }

  function setValuCallback(value) {
    switch (value) {
      case 0:
        label.setValue('Necesito recuperar el alienteo despues de subir')
        complement.setValue('escaleras')
        status.setValue('Principiante')
        break
      case 1:
        label.setValue('Hago ejercicio todos los días porque estar en forma')
        complement.setValue('es esencial para mi')
        status.setValue('Intermedio')
        break
      case 2:
        label.setValue('Estoy en buena forma')
        complement.setValue('')
        status.setValue('Avanzado')
        break
      case 3:
        label.setValue('Estoy en buena forma')
        complement.setValue('')
        status.setValue('Profesional')
        break
      default:
        label.setValue('')
        complement.setValue('')
        status.setValue('')
        break
    }
  }
  return (
    <View style={styles.PrincipalContainer}>
      <TextForm style={styles.Title} type="title">
        NIVEL DE ACTIVIDAD
      </TextForm>
      <View style={styles.BodyContainer}>
        <View style={styles.levelContainer}>
          <ReText text={concat(status)} style={styles.BodyText} />
          <ReText text={concat(label)} style={styles.levelText} />
          <ReText text={concat(complement)} style={styles.levelText} />
        </View>
        <View style={styles.TextDescription}>
          <TextForm style={styles.BodyText} type="body">
            Profesional
          </TextForm>
        </View>
        <Slider
          {...{
            totalHeight,
            steps,
            levelActivity,
            activeCallback,
            endCallback
          }}
        />
        <View>
          <TextForm style={styles.BodyText} type="body">
            Principiante
          </TextForm>
        </View>
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1
  },
  BodyContainer: {
    alignItems: 'center',
    marginTop: '5%'
  },
  Title: {
    marginTop: 64,
    fontSize: 20,
    marginBottom: 20,
    color: 'black',
    fontWeight: '800'
  },
  BodyText: {
    fontWeight: 'bold'
  },
  TextDescription: {
    paddingTop: '5%',
    paddingBottom: '3%'
  },
  levelContainer: {
    alignItems: 'center'
  },
  levelText: {
    fontSize: 14,
    color: '#43485C',
    fontFamily: 'Lato',
    fontStyle: 'normal'
  }
})
export default ThreeScreenOnBoarding
