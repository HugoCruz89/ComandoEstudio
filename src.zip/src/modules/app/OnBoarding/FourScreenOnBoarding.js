import React from 'react'
import { View, StyleSheet, FlatList } from 'react-native'
import TextForm from './../../../components/Text'
import ObjectiveButton from './../../../components/ObjectivesButton'
import { string, array, func } from 'prop-types'

const FourScreenOnBoarding = (props) => {
  return (
    <View style={styles.PrincipalContainer}>
      <TextForm style={styles.Title} type="title">
        OBJETIVOS QUE DESEO LOGRAR
      </TextForm>
      <View style={styles.BodyTextContainer}>
        <TextForm style={styles.BodyText} type="body">
          Elige máximo 2 objetivos para lograr un enfoque en tu entrenamiento
        </TextForm>
      </View>
      <View style={styles.ContainerListObective}>
        <FlatList
          keyExtractor={(item, index) => item.id.toString()}
          data={props.OBJECTIVES}
          style={styles.StyleList}
          renderItem={(itemData) => (
            <ObjectiveButton
              id={itemData.item.id}
              checked={itemData.item.checked}
              onCheckListObjective={(id) => props.onCheckListObjective(id)}
              description={itemData.item.description}
              Icon={itemData.item.icon}
              image={itemData.item.image}
              enable={itemData.item.enable}
            />
          )}
        />
      </View>
    </View>
  )
}

FourScreenOnBoarding.propTypes = {
  onCheckListObjective: func,
  CountChecked: string,
  OBJECTIVES: array
}

const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1
  },
  Title: {
    marginTop: 64,
    fontSize: 20,
    marginBottom: 20,
    color: 'black',
    fontWeight: '800'
  },
  BodyTextContainer: {
    alignItems: 'center',
    marginTop: '10%'
  },
  BodyText: {
    textAlign: 'center'
  },
  ContainerListObective: {
    marginHorizontal: 10
  },
  StyleList: {
    marginTop: 30
  }
})
export default FourScreenOnBoarding
