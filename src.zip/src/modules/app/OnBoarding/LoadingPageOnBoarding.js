import React, { useEffect, useState } from 'react'
import { View, StyleSheet } from 'react-native'
import TextForm from './../../../components/Text'
import { useNavigation } from '@react-navigation/native'
import { connect } from 'react-redux'
import { updateProfile, updateWeekDays } from 'ducks/app'
import { updateOnboardingData } from 'ducks/auth'
import { func } from 'prop-types'
import { Bubbles } from 'react-native-loader'
import AsyncStorage from '@react-native-community/async-storage'

const LoadingPageOnBoarding = (props) => {
  const [listObjectives] = useState(props.goals)
  const [listDays] = useState(props.listDay)
  const navigation = useNavigation()
  const goToHome = () => {
    navigation.reset({
      index: 0,
      routes: [{ name: 'home' }]
    })
  }
  const builArrayObjectives = () => {
    let newArryay = []
    listObjectives.forEach((element) => {
      newArryay.push(String(element.descriptionToDataBase))
    })
    return newArryay
  }

  const builArrayWeekdays = () => {
    let newArryay = []
    listDays.forEach((element) => {
      newArryay.push(element.checked)
    })
    return newArryay
  }

  const saveToStore = async () => {
    const arrayObjectives = builArrayObjectives()
    const arrayWeekDays = builArrayWeekdays()

    let data = {
      weight: parseInt(props.weight, 10),
      height: parseInt(props.height, 10),
      age: parseInt(props.age, 10),
      gender: props.gender,
      experience: props.experience,
      activity: props.activities,
      goal: arrayObjectives,
      schedule: arrayWeekDays
    }
    await props.updateOnboardingData(data)
  }

  useEffect(() => {
    async function fetch() {
      try {
        await AsyncStorage.setItem('@ListWeek', JSON.stringify(listDays))
        const arrayObjectives = builArrayObjectives()
        listDays
        let data = {
          weight: parseInt(props.weight, 10),
          height: parseInt(props.height, 10),
          age: parseInt(props.age, 10),
          gender: props.gender,
          experience: props.experience,
          activity: props.activities,
          goal: arrayObjectives
        }
        let resp = await props.updateProfile(data)
        const {
          payload: { saved }
        } = resp
        if (saved) {
          const arrayWeekDays = builArrayWeekdays()
          let schedule = {
            schedule: arrayWeekDays
          }
          let respWeek = await props.updateWeekDays(schedule)

          const {
            payload: { saved }
          } = respWeek
          if (saved) {
            saveToStore()
            goToHome()
          }
        } else {
        }
      } catch (error) {}
    }
    fetch()
  })

  return (
    <View style={styles.PrincipalContainer}>
      <View style={styles.imageContainer}>
        <Bubbles size={10} color="#000000" />
      </View>
      <TextForm style={styles.Title} type="title">
        PERSONALIZANDO...
      </TextForm>
    </View>
  )
}

LoadingPageOnBoarding.propTypes = {
  updateProfile: func,
  updateWeekDays: func
}
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  Title: {
    fontSize: 20,
    fontWeight: '800',
    marginTop: 19
  },
  logo: {
    alignContent: 'center',
    position: 'relative'
  },
  imageContainer: {
    alignItems: 'center',
    marginTop: -19
  }
})
const mapDispatchToProps = {
  updateProfile,
  updateWeekDays,
  updateOnboardingData
}
export default connect(null, mapDispatchToProps)(LoadingPageOnBoarding)
