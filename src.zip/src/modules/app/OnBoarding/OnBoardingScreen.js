import React, { useRef, useState, useEffect } from 'react'
import {
  SafeAreaView,
  View,
  StyleSheet,
  Keyboard,
  TouchableWithoutFeedback,
  TouchableOpacity,
  Dimensions,
  Alert
} from 'react-native'
import Wizard from 'react-native-wizard'
import { connect } from 'react-redux'
import StepLine from './../../../components/StepLine'
import FirstScreen from './FirstScreenOnBoarding'
import SecondScreen from './SecondScreenOnBoarding'
import ThreeScreen from './ThreeScreenOnBoarding'
import FourScreen from './FourScreenOnBoarding'
import FiveScreen from './FiveScreenOnBoarding'
import LoadingScreen from './LoadingPageOnBoarding'
import ButtonForm from './../../../components/Button'
import { SvgBackArrow } from '../../../media/images/svg/ObjetiveIcons'
import { registerScreenVisit as rsv } from 'ducks/auth'
import { OBJECTIVES, LIST_DAY } from './../mockedData'
import Toast from 'react-native-simple-toast'

const windowHeight = Dimensions.get('window').height

const OnBoardingScreen = (props) => {
  const { registerScreenVisit } = props
  let activities = 0
  let wordActivity = 'Necesito recuperar el aliento despues de subir escaleras'

  const [disbledButton, setDisabledButton] = useState(true)
  const [weight, setWeight] = useState('')
  const [weightError, setWeightError] = useState('')
  const [height, setHeight] = useState('')
  const [heightError, setHeightError] = useState('')
  const [age, setAge] = useState('')
  const [ageError, setAgeError] = useState('')
  const [maleCheck, setMaleCheck] = useState(false)
  const [femaleCheck, setFemaleCheck] = useState(false)
  const [blurImageWoman, setBlurWoman] = useState(3.5)
  const [blurImageMen, setBlurMen] = useState(3.5)
  const [listObjectives, setListObjectives] = useState(OBJECTIVES)
  const [listDay, setListDay] = useState(LIST_DAY)
  const [activitiesSend, setActivitiesSend] = useState(0)
  useEffect(() => {
    if (parseInt(age, 10) === 0) {
      setAgeError('no se permite edad 0')
      setAge('')
    }
    if (weight.length > 0 && height.length > 0 && age.length > 0) {
      setDisabledButton(false)
    } else {
      setDisabledButton(true)
    }
  }, [weight.length, height.length, age.length, age])

  const handleWeight = (value) => {
    setWeightError('')
    setWeight(value)
  }
  const handleHeight = (value) => {
    setHeightError('')
    setHeight(value)
  }
  const handleAge = (value) => {
    setAgeError('')
    setAge(value)
  }
  const onChangeGender = (gender) => {
    setDisabledButton(false)
    if (gender === 'M') {
      setMaleCheck(true)
      setFemaleCheck(false)
      setBlurWoman(3.5)
      setBlurMen(0)
      return
    } else {
      setBlurWoman(0)
      setBlurMen(3.5)
      setMaleCheck(false)
      setFemaleCheck(true)
      return
    }
  }
  const countCheckedNumber = 1
  const CountChecked = (idCheck) => {
    const countChecked = listObjectives.filter((item) => item.checked === true)
      .length

    if (countChecked <= countCheckedNumber) {
      return true
    }
    const objIndex = listObjectives.findIndex((obj) => obj.id === idCheck)
    const checkedValueCurrent = listObjectives[objIndex].checked

    if (checkedValueCurrent) {
      return true
    } else {
      return false
    }
  }

  const EnableButtonGoals = () => {
    const countChecked = listObjectives.find((item) => item.checked === true)
    if (countChecked !== undefined) setDisabledButton(false)
    else setDisabledButton(true)
  }

  const onCheckListObjective = (idCheck) => {
    let flag = CountChecked(idCheck)

    if (flag) {
      EnableTex()
      const objIndex = listObjectives.findIndex((obj) => obj.id === idCheck)
      const checkedValue = listObjectives[objIndex].checked ? false : true
      listObjectives[objIndex].checked = checkedValue
      setListObjectives(
        listObjectives.map((item) =>
          item.id === idCheck ? { ...item, checked: checkedValue } : item
        )
      )
      const count = listObjectives.filter((item) => item.checked === true)

      if (count.length === 2) {
        DisableTex()
      }
      EnableButtonGoals()
    } else {
      Toast.showWithGravity(
        'No puedes seleccionar mas de 2 objetivos',
        Toast.SHORT,
        Toast.TOP
      )
    }
  }
  const DisableTex = () => {
    setListObjectives(
      listObjectives.map((item) =>
        item.checked === false ? { ...item, enable: false } : item
      )
    )
  }
  const EnableTex = () => {
    const NewArray = listObjectives
    NewArray.forEach((item) => (item.enable = true))

    setListObjectives(NewArray)
  }
  const onCheckListDay = (idChecked) => {
    const objIndex = listDay.findIndex((obj) => obj.id === idChecked)
    const checkedValue = listDay[objIndex].checked ? false : true
    listDay[objIndex].checked = checkedValue

    setListDay(
      listDay.map((item) =>
        item.id === idChecked ? { ...item, checked: checkedValue } : item
      )
    )
  }
  const saveValue = (value) => {
    activities = value
  }
  const ValidateFirstPage = () => {
    let MistakesCount = 0
    if (weight.length === 0) {
      MistakesCount++
      setWeightError('Es obligaotrio este campo')
    }
    if (height.length === 0) {
      MistakesCount++
      setHeightError('Es obligaotrio este campo')
    }
    if (age.length === 0) {
      MistakesCount++
      setAgeError('Es obligaotrio este campo')
    }

    return MistakesCount > 0 ? false : true
  }
  const ValidateSecondPage = () => {
    if (!maleCheck && !femaleCheck) {
      Alert.alert('Favor de escoger un genero')
      return false
    } else return true
  }

  const BackStep = () => {
    if (weight.length > 0 && height.length > 0 && age.length > 0) {
      setDisabledButton(false)
    } else {
      setDisabledButton(true)
    }
    wizard.current.prev()
  }
  const NextStep = () => {
    switch (currentStep) {
      case 0:
        if (ValidateFirstPage()) {
          if (maleCheck || femaleCheck) setDisabledButton(false)
          else setDisabledButton(true)
          wizard.current.next()
        }
        break
      case 1:
        if (ValidateSecondPage()) {
          wizard.current.next()
        }
        break
      case 2:
        setActivitiesSend(activities)
        setDisabledButton(true)
        wizard.current.next()
        break
      case 3:
        //setDisabledButton(true)

        wizard.current.next()
        break
    }
  }
  useEffect(() => {
    return () => {
      registerScreenVisit({ screen: 'on-boarding' })
    }
  }, [registerScreenVisit])

  const wizard = useRef({ next: () => null })

  const [currentStep, setCurrentStep] = useState(0)

  const stepList = [
    {
      content: (
        <View style={styles.viewStyle}>
          <FirstScreen
            onChangeWeight={handleWeight}
            weightError={weightError}
            onChangeHeight={handleHeight}
            heightError={heightError}
            onChangeAge={handleAge}
            ageError={ageError}
            age={age}
            weight={weight}
            height={height}
          />
          <ButtonForm
            style={{
              text: styles.buttonText,
              container: styles.buttonContainer
            }}
            theme={'primary'}
            disabled={disbledButton}
            title="Siguiente"
            onPress={NextStep}
          />
        </View>
      )
    },
    {
      content: (
        <View style={styles.viewStyle}>
          <SecondScreen
            onChangeGender={onChangeGender}
            maleCheck={maleCheck}
            femaleCheck={femaleCheck}
            blurImageWoman={blurImageWoman}
            blurImageMen={blurImageMen}
          />
          <ButtonForm
            style={styles.ButtonText}
            theme={'primary'}
            disabled={disbledButton}
            title="Siguiente"
            onPress={NextStep}
          />
        </View>
      )
    },
    {
      content: (
        <View style={styles.viewStyle}>
          <ThreeScreen
            saveValue={saveValue}
            activities={activities}
            wordActivity={wordActivity}
          />
          <ButtonForm
            style={styles.ButtonText}
            theme={'primary'}
            disabled={disbledButton}
            title="Siguiente"
            onPress={NextStep}
          />
        </View>
      )
    },
    {
      content: (
        <View style={styles.viewStyle}>
          <FourScreen
            CountChecked="2"
            OBJECTIVES={listObjectives}
            onCheckListObjective={onCheckListObjective}
          />
          <ButtonForm
            style={{
              text: styles.buttonText,
              container: styles.buttonContainer
            }}
            theme={'primary'}
            disabled={disbledButton}
            title="Siguiente"
            onPress={NextStep}
          />
        </View>
      )
    },
    {
      content: (
        <View style={styles.viewStyle}>
          <FiveScreen listDay={listDay} onCheckListDay={onCheckListDay} />
          <ButtonForm
            title="Crear mi rutina"
            style={{
              text: styles.buttonText,
              container: styles.buttonContainer
            }}
            onPress={() => wizard.current.next()}
          />
        </View>
      )
    },
    {
      content: (
        <View style={styles.ScreenContainer}>
          <LoadingScreen
            weight={weight}
            height={height}
            age={age}
            gender={maleCheck === true ? 'male' : 'female'}
            experience={'beginner'}
            goals={listObjectives.filter((item) => item.checked === true)}
            activities={activitiesSend}
            listDay={listDay}
          />
        </View>
      )
    }
  ]
  return (
    <SafeAreaView style={styles.container}>
      {currentStep < 5 && (
        <View style={styles.headerContainer}>
          {currentStep ? (
            <View style={styles.backButtonContainer}>
              <TouchableOpacity onPress={BackStep}>
                <SvgBackArrow />
              </TouchableOpacity>
            </View>
          ) : null}
          <View>
            <StepLine step={String(currentStep + 1)} />
          </View>
        </View>
      )}
      <TouchableWithoutFeedback
        onPress={() => {
          Keyboard.dismiss()
        }}>
        <View style={styles.ContainerStep}>
          <Wizard
            ref={wizard}
            steps={stepList}
            onNext={() => {}}
            onPrev={() => {}}
            currentStep={({ currentStep: cs }) => {
              setCurrentStep(cs)
            }}
          />
        </View>
      </TouchableWithoutFeedback>
    </SafeAreaView>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white'
  },
  ScreenContainer: {
    marginHorizontal: 30,
    marginTop: windowHeight * 0.1
  },
  Screen: {
    flex: 2
  },
  Button: {
    flex: 1,
    marginTop: '20%'
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: 30,
    marginTop: 10
  },
  backButtonContainer: { position: 'absolute', left: 15 },
  viewStyle: {
    marginHorizontal: 30,
    marginBottom: 46
  },
  ContainerStep: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white'
  },
  buttonContainer: {
    height: 50
  },
  buttonText: {
    fontSize: 18,
    fontWeight: '700'
  }
})

const mapDispatchToProps = {
  registerScreenVisit: rsv
}

export default connect(null, mapDispatchToProps)(OnBoardingScreen)
