import React, { useState } from 'react'
import { View, StyleSheet } from 'react-native'
import { Text, Switch, Header } from 'components'
import { Separator } from 'modules/auth/static-components'

const NotificaciontsScreen = (props) => {
  const [device, setDevice] = useState(false)
  const [email, setEmail] = useState(true)
  const [deviceOnline, setDeviceOnline] = useState(false)
  const [emailOnline, setEmailOnline] = useState(true)

  function handleDeviceToggle() {
    setDevice(!device)
  }

  function handleEmailToggle() {
    setEmail(!email)
  }

  function handleDeviceOnlineToggle() {
    setDeviceOnline(!deviceOnline)
  }

  function handleEmailOnlineToggle() {
    setEmailOnline(!emailOnline)
  }

  return (
    <View style={styles.container}>
      <Header title="Notificaciones" />
      <View style={styles.textContainer}>
        <Text style={styles.text} type="body">
          Te recomendamos tener tus notificaciones activas para avisarte cuando
          inician tus clases agendadas.
        </Text>
      </View>
      <View style={styles.menuContainer}>
        <Text style={styles.group}>MIS CLASES</Text>
        <Separator />
        <View style={styles.optionContainer}>
          <Text style={styles.option}>DISPOSITIVO</Text>
          <Switch value={device} onValueChange={handleDeviceToggle} />
        </View>
        <View style={styles.optionContainer}>
          <Text style={styles.option}>CORREO ELECTRÓNICO</Text>
          <Switch value={email} onValueChange={handleEmailToggle} />
        </View>
        <Text style={styles.group}>AGENDA EN VIVO</Text>
        <Separator />
        <View style={styles.optionContainer}>
          <Text style={styles.option}>DISPOSITIVO</Text>
          <Switch
            value={deviceOnline}
            onValueChange={handleDeviceOnlineToggle}
          />
        </View>
        <View style={styles.optionContainer}>
          <Text style={styles.option}>CORREO ELECTRÓNICO</Text>
          <Switch value={emailOnline} onValueChange={handleEmailOnlineToggle} />
        </View>
      </View>
    </View>
  )
}

export default NotificaciontsScreen

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  textContainer: {
    alignItems: 'center',
    marginTop: 13,
    marginRight: 37,
    marginLeft: 29
  },
  text: {
    textAlign: 'justify',
    fontWeight: '400',
    fontSize: 16,
    color: '#8C8C8C'
  },
  menuContainer: {
    flex: 1,
    width: '100%',
    paddingHorizontal: 30,
    marginTop: 43
  },
  group: {
    color: '#8C8C8C',
    marginTop: 20,
    fontWeight: 'bold'
  },
  optionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 30
  },
  option: {
    color: '#000000',
    fontWeight: 'bold'
  }
})
