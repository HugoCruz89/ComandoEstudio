import React, { useRef } from 'react'
import { string, func, oneOf, object } from 'prop-types'
import { TouchableHighlight, StyleSheet, View, Text } from 'react-native'
import Icon from 'react-native-vector-icons/Feather'

function SubscriptionButton(props) {
  const { promo, discount, type } = props

  const themeBuilder = () => {
    switch (type) {
      case 'black':
        return {
          text: { color: '#FFFFFF' },
          plan: { fontWeight: '300' },
          container: { backgroundColor: '#000000' },
          icon: '#FFFFFF'
        }
      case 'white':
        return {
          text: { color: '#000000' },
          plan: { fontWeight: 'bold' },
          container: { backgroundColor: '#FFFFFF' },
          icon: '#000000'
        }
      default:
        return {
          text: { color: '#000000' },
          container: { backgroundColor: '#FFFFFF' },
          icon: '#000000'
        }
    }
  }

  const { current: themeStyle } = useRef(themeBuilder())

  return (
    <TouchableHighlight style={props.style} onPress={props.onPress}>
      <View style={[styles.container, themeStyle.container]}>
        <View style={styles['info-container']}>
          <Text style={[styles['info-plan'], themeStyle.text, themeStyle.plan]}>
            {props.plan} <Text style={styles['info-trial']}>{props.trial}</Text>
          </Text>
          <Text style={[styles['info-price'], themeStyle.text]}>
            {props.price} MXN / {props.planPeriod}*
          </Text>
          {(promo || discount) && (
            <View style={styles['extra-container']}>
              <Text style={[styles['info-promo'], themeStyle.text]}>
                {promo}
              </Text>
              <Text style={[styles['info-discount'], themeStyle.text]}>
                {discount}
              </Text>
            </View>
          )}
        </View>
        <Icon name="chevron-right" color={themeStyle.icon} size={25} />
      </View>
    </TouchableHighlight>
  )
}

SubscriptionButton.propTypes = {
  plan: string,
  planPeriod: string,
  trial: string,
  type: oneOf(['black', 'white']),
  onPress: func,
  style: object
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#000000',
    borderRadius: 3,
    paddingBottom: 7,
    minHeight: 80
  },
  'info-container': {
    flex: 1,
    paddingLeft: 16,
    paddingRight: 12
  },
  'info-plan': {
    fontWeight: '300',
    fontSize: 18
  },
  'info-trial': {
    fontWeight: '800',
    fontSize: 14
  },
  'info-price': {
    fontWeight: '500',
    fontSize: 14,
    marginBottom: 5
  },
  'extra-container': {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  'info-promo': {
    //fontFamily: 'Noto Sans',
    fontSize: 11
  },
  'info-discount': {
    //fontFamily: 'Noto Sans',
    fontSize: 12,
    fontWeight: 'bold'
  }
})

export default SubscriptionButton
