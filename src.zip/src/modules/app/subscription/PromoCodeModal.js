import React, { useState } from 'react'
import { bool, func, string } from 'prop-types'
import { StyleSheet, View, Text } from 'react-native'
import { connect } from 'react-redux'
import Modal from 'react-native-modal'
import { TextInput, Button } from 'components'

function PromoCodeModal(props) {
  const { isVisible, toggleModal } = props
  const [loading, setLoading] = useState(false)
  const [validCode, setValidCode] = useState(false)

  const isFormatValid = (value) => {
    const isValid = true

    if (isValid) {
      setValidCode(value)
    } else {
      setValidCode('')
    }

    return isValid
  }

  const onTextChange = (value) => {
    if (isFormatValid(value)) {
      setLoading(true)
      setLoading(false)
      props.toggleModal()
      props.onValidPromo(validCode)
    }
  }

  return (
    <Modal
      avoidKeyboard
      style={styles.modal}
      isVisible={isVisible}
      onBackdropPress={!loading && toggleModal}>
      <View style={styles['modal-container']}>
        <Text style={styles['modal-title']}>Ingresa tu código</Text>
        <TextInput
          inputStyle={styles['text-input']}
          defaultValue={props.promoCode}
          name="promo_code"
          label="Código de promoción"
          onTextChange={onTextChange}
        />
        <View style={styles['modal-footer']}>
          <Button
            style={{
              container: [styles['modal-buttons'], { marginRight: 10 }]
            }}
            theme="outlined"
            title="Cancelar"
            onPress={toggleModal}
            disabled={loading}
          />
          <Button
            style={{
              container: [styles['modal-buttons'], { marginLeft: 10 }]
            }}
            theme="primary"
            title="Agregar"
            disabled={loading || !validCode}
          />
        </View>
      </View>
    </Modal>
  )
}

PromoCodeModal.propTypes = {
  isVisible: bool,
  promoCode: string,
  toggleModal: func,
  onValidPromo: func
}

const styles = StyleSheet.create({
  modal: {
    justifyContent: 'flex-end',
    margin: 0
  },
  'modal-container': {
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    backgroundColor: 'white',
    paddingLeft: 25,
    paddingRight: 25,
    paddingTop: 20,
    paddingBottom: 20
  },
  'text-input': {
    color: '#000000'
  },
  'modal-title': {
    fontWeight: '500',
    textAlign: 'center',
    fontSize: 20,
    marginBottom: 20,
    color: '#43485C',
    textTransform: 'uppercase'
  },
  'modal-footer': {
    marginTop: 20,
    flexDirection: 'row',
    width: '100%'
  },
  'modal-buttons': {
    flex: 1
  }
})

export default connect()(PromoCodeModal)
