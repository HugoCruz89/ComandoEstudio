/* eslint-disable react-native/no-inline-styles */
import React, { Component } from 'react'
import { SafeAreaView, StyleSheet, View, Text as RNText } from 'react-native'
import { Text, Button } from '../../../components'
import PromoCodeModal from './PromoCodeModal'
import SubscriptionButton from './SubscriptionButton'
import { TermsAndConditions } from '../../auth/static-components'

class SubscriptionScreen extends Component {
  state = {
    modalVisible: false
  }

  toggleModal = () =>
    this.setState((prevState) => ({ modalVisible: !prevState.modalVisible }))

  render() {
    return (
      <SafeAreaView style={styles.container}>
        <Text type="title" textAlign="center">
          Subscripción
        </Text>
        <View style={styles['image-container']} />
        <View style={styles['body-container']}>
          <Text textAlign="center" color="#43485C" style={{ marginBottom: 25 }}>
            Commando OD es tu entrenador personal, que te ayudará a llegar a tus
            objetivos diarios, con distintos tipos de ejercicos y más.
          </Text>
          <SubscriptionButton
            type="black"
            plan="Anualmente"
            trial="7 días prueba GRATIS"
            price="2,999"
            planPeriod="año"
            promo="Incluye plan nutricional"
            discount="50% descuento"
            style={buttonSeparator}
          />
          <SubscriptionButton
            type="white"
            plan="Mensual"
            trial="7 días prueba GRATIS"
            price="499"
            planPeriod="mes"
            style={buttonSeparator}
          />
          <RNText style={styles['body-advice']}>
            * Cobro mensual tras prueba{' '}
            <RNText style={styles['body-advice--bold']}>GRATIS 7 DIAS</RNText>
          </RNText>
          <Button
            theme="tertiary"
            title="Tengo un código de descuento"
            onPress={this.toggleModal}
          />
          <PromoCodeModal
            isVisible={this.state.modalVisible}
            toggleModal={this.toggleModal}
          />
        </View>
        <TermsAndConditions />
      </SafeAreaView>
    )
  }
}

SubscriptionScreen.propTypes = {}

const buttonSeparator = {
  marginBottom: 20
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', paddingTop: 20 },
  'image-container': {
    height: 245,
    width: '100%',
    backgroundColor: 'gray',
    marginTop: 20,
    marginBottom: 15
  },
  'body-container': {
    flex: 1,
    paddingLeft: 35,
    paddingRight: 35
  },
  'body-advice': {
    textAlign: 'center',
    fontSize: 11,
    marginBottom: 5
  },
  'body-advice--bold': {
    fontWeight: 'bold'
  }
})
export default SubscriptionScreen
