import React from 'react'
import { object } from 'prop-types'
import { SafeAreaView, StyleSheet, Image, View } from 'react-native'
import { Text, Button } from 'components'

function NotFoundScreen(props) {
  function goToHome() {
    props.navigation.reset({
      index: 0,
      routes: [{ name: 'home' }]
    })
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Image source={require('media/images/404.jpg')} />
        <Image source={require('media/images/towel.png')} />
        <Text type="header" fontWeight="800" style={styles.title} fontSize={20}>
          Página no encontrada
        </Text>
        <Text type="title" fontWeight="500" fontSize={18}>
          no eres tu, somos nosotros
        </Text>
      </View>
      <Button onPress={goToHome} title="volver al inicio" />
    </SafeAreaView>
  )
}

NotFoundScreen.propTypes = {
  navigation: object
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    margin: 10
  },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  title: { marginTop: 20 }
})

export default NotFoundScreen
