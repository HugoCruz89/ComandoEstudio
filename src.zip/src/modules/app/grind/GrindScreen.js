import React from 'react'
import { StyleSheet, View, SafeAreaView, ScrollView } from 'react-native'
import { getDay } from 'date-fns'
import { Text } from 'components'
import useRequest from 'use-request'
import ContentSection from 'modules/app/explore/ContentSection'
import {
  AvatarElement,
  LandscapeElement
} from 'modules/app/explore/ChannelElements'
import { EXTRA_CLASS, SCHEDULE_NEW, TODAY_CLASS } from 'modules/app/mockedData'
import WeekScheduler from './WeekScheduler'
import DayStatus from './DayStatus'
import { getUserRoutine } from 'ducks/app'

const SECTIONS = {
  TODAY: 'Entrenamiento del día',
  EXTRA_CLASS: 'Extra class',
  TRAINER: 'entrenador'
}

const day = getDay(new Date())
const currentDay = SCHEDULE_NEW.find((x) => x.numberDay === day)

function GrindScreen(props) {
  const { data } = useRequest(null, getUserRoutine())

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header} type="header" textAlign="center">
        Mi rutina
      </Text>
      <WeekScheduler style={styles['week-scheduler']} />
      {currentDay && currentDay.status && (
        <DayStatus status={currentDay.status} />
      )}
      <ScrollView style={styles.container}>
        <ContentSection
          loading={!data}
          title={SECTIONS.TODAY}
          style={styles.content}>
          <View style={styles['horizontal-separator']}>
            <LandscapeElement
              onPress={() => {
                props.navigation.push('video-detail', {
                  ...data.lesson,
                  image: data.lesson.image || TODAY_CLASS.image,
                  headerTitle: data.lesson.name,
                  track: true
                })
              }}
              loading={!data}
              style={styles['content-element']}
              title={data ? data.lesson.name : ''}
              background={TODAY_CLASS.image}
              progress={TODAY_CLASS.progress}
              duration={TODAY_CLASS.duration}
            />
          </View>
        </ContentSection>
        <ContentSection
          loading={!data}
          title={SECTIONS.EXTRA_CLASS}
          style={styles.content}>
          <View style={styles['horizontal-separator']}>
            <LandscapeElement
              onPress={() => {
                props.navigation.push('video-detail', {
                  ...data.extra,
                  image: data.extra.image || EXTRA_CLASS.image,
                  headerTitle: data.extra.name,
                  track: true
                })
              }}
              loading={!data}
              style={styles['content-element']}
              title={data ? data.extra.name : ''}
              background={EXTRA_CLASS.image}
              progress={EXTRA_CLASS.progress}
              duration={EXTRA_CLASS.duration}
            />
          </View>
        </ContentSection>
        {data === undefined || data.instructors.length ? (
          <ContentSection
            loading={!data}
            title={SECTIONS.TRAINER}
            style={styles.content}>
            <View style={styles['trainers-container']}>
              {data ? (
                data.instructors.map((item) => (
                  <AvatarElement
                    style={styles['trainer-separator']}
                    key={item.name}
                    name={item.name}
                    avatar={item.avatar}
                  />
                ))
              ) : (
                <AvatarElement loading style={styles['trainer-separator']} />
              )}
            </View>
          </ContentSection>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  )
}

GrindScreen.propTypes = {}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white'
  },
  header: {
    marginTop: 0,
    fontWeight: 'bold'
  },
  'week-scheduler': {
    marginTop: 20
  },
  content: {
    marginVertical: 10
  },
  'content-element': {
    width: '100%'
  },
  'horizontal-separator': {
    paddingHorizontal: 30
  },
  'trainers-container': {
    flexDirection: 'row',
    paddingHorizontal: 30
  },
  'trainer-separator': {
    marginRight: 20
  }
})

export default GrindScreen
