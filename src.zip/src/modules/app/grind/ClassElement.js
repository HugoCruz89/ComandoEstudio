import React, { useRef } from 'react'
import { string, number, oneOf, oneOfType, any } from 'prop-types'
import {
  View,
  ImageBackground,
  StyleSheet,
  TouchableOpacity
} from 'react-native'
import LinearGradient from 'react-native-linear-gradient'

import { Text } from 'components'

const LEVEL = {
  medium: 'Intermedio'
}

function stringifyTags(tags) {
  let str = tags.reduce((prev, crr) => `${prev} ${crr},`, '').slice(0, -1) || ''
  return str
}

function ClassElement(props) {
  const imageSource = useRef(
    typeof props.image === 'number' ? props.image : { uri: props.image }
  )

  const tags = useRef(stringifyTags(props.tags))

  return (
    <View style={[styles.container, props.style]}>
      <ImageBackground
        imageStyle={styles['cover-image']}
        style={styles.cover}
        source={imageSource.current}>
        <TouchableOpacity
          style={styles['touchable-cover']}
          onPress={props.onPress}>
          <LinearGradient
            colors={['rgba(0,0,0,0)', '#000000']}
            style={styles['gradient-container']}
            start={{ x: 0, y: 0.03 }}
            end={{ x: 0, y: 1 }}>
            <Text type="title" textAlign="left" fontSize={14} color="white">
              {props.title}
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </ImageBackground>
      <Text style={styles.progress}>{props.progress}%</Text>
      <View style={styles.footer}>
        <View style={styles['footer-element']}>
          <Text type="subtitle">{props.program}</Text>
          <Text fontSize={11} fontWeight="bold" style={styles.opacity}>
            {tags.current}
          </Text>
        </View>
        <View style={styles['footer-element-right']}>
          <Text fontSize={9} type="subtitle">
            {props.duration} MIN • {props.level}
          </Text>
          <Text fontSize={11} fontWeight="400" style={styles.opacity}>
            Con: {props.trainer}
          </Text>
        </View>
      </View>
    </View>
  )
}

ClassElement.propTypes = {
  image: oneOfType([number, string]),
  title: string,
  duration: number,
  level: oneOf([LEVEL.medium]),
  trainer: string,
  style: any
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  cover: {
    height: 145
  },
  'gradient-container': {
    height: 48,
    justifyContent: 'flex-end',
    paddingHorizontal: 10,
    paddingBottom: 5,
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5
  },
  'cover-image': {
    borderRadius: 10
  },
  'touchable-cover': { flex: 1, flexDirection: 'column-reverse' },
  title: {
    fontSize: 17,
    lineHeight: 16,
    textTransform: 'uppercase',
    color: '#FFFFFF'
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    textTransform: 'uppercase',
    paddingVertical: 10
  },
  'footer-element': {
    flex: 1,
    justifyContent: 'space-between'
  },
  'footer-element-right': {
    flex: 1,
    alignItems: 'flex-end',
    justifyContent: 'space-between'
  },
  opacity: {
    opacity: 0.6
  },
  progress: {
    position: 'absolute',
    right: 10,
    top: 5,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18
  }
})

export default ClassElement

export { LEVEL }
