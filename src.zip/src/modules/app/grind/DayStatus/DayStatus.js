import React from 'react'
import { View, StyleSheet } from 'react-native'
import DayStatusItem from './DayStatusItem'
import { Button } from 'components'

const FINISHED = require('../../../../media/images/finished.png')
const REST = require('../../../../media/images/dia-descanso.png')

const DayStatus = ({ status }) => {
  return (
    <View style={styles.container}>
      {status === 'COMPLETE' && (
        <DayStatusItem
          image={FINISHED}
          title="¡FELICIDADES!"
          description="Completaste tu entrenamiento del día"
        />
      )}
      {status === 'DAY_OFF' && (
        <View style={styles.restContainer}>
          <DayStatusItem
            image={REST}
            title="DÍA DE DESCANSO"
            description="Ten un buen merecido día de descanso"
          />
          <Button
            style={styles.button}
            theme="primary"
            title="Explorar entrenamientos"
          />
        </View>
      )}
    </View>
  )
}

export default DayStatus

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 30
  },
  restContainer: {
    height: 160,
    justifyContent: 'space-between'
  }
})
