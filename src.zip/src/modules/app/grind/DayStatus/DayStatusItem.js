import React from 'react'
import { View, Text, Image, StyleSheet } from 'react-native'

const DayStatusItem = ({ image, title, description }) => (
  <View style={styles.container}>
    <Image style={styles.image} source={image} />
    <View style={styles.textContainer}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.description}>{description}</Text>
    </View>
  </View>
)

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    width: '100%',
    paddingLeft: 15,
    justifyContent: 'space-between'
  },
  image: {
    height: 100,
    resizeMode: 'contain'
  },
  textContainer: {
    width: '70%',
    justifyContent: 'center'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000'
  },
  description: {
    fontSize: 14,
    color: '#8C8C8C'
  }
})

export default DayStatusItem
