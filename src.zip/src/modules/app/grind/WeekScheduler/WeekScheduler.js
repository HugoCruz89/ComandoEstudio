import React from 'react'
import { StyleSheet, View, FlatList } from 'react-native'
import DayElement from './DayElement'

import { SCHEDULE_NEW } from '../../mockedData'

function WeekScheduler(props) {
  return (
    <View style={[styles.container, props.style]}>
      <FlatList
        showsHorizontalScrollIndicator={false}
        style={styles.ListContainer}
        keyExtractor={(item, index) => index}
        data={SCHEDULE_NEW}
        horizontal={true}
        renderItem={(itemData) => (
          <View style={styles.slide}>
            <DayElement
              status={itemData.item.status}
              time={itemData.item.time}
              word={itemData.item.day}
            />
          </View>
        )}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    width: '100%'
  },
  'direction-button': {
    minWidth: 30,
    flexDirection: 'column',
    alignItems: 'flex-start'
  },
  slide: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  ListContainer: {
    marginHorizontal: 20
  }
})

export default WeekScheduler
