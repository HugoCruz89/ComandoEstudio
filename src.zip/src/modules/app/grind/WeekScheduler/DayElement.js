import React from 'react'
import { oneOf, string } from 'prop-types'
import { StyleSheet, View, TouchableOpacity } from 'react-native'
import IconFontAwesome from 'react-native-vector-icons/FontAwesome'
import { Text } from 'components'

function getStatusIcon(status, time) {
  const color = time === 'FUTURE' ? '#FC3838' : '#FFFFFF'
  switch (status) {
    case 'DAY_OFF':
      return (
        <View
          style={[
            {
              backgroundColor: color
            },
            styles.ball
          ]}
        />
      )
    case 'COMPLETE':
      return <IconFontAwesome name="check" color={color} />
    case 'INCOMPLETE':
      return <IconFontAwesome name="close" color={color} />
    default:
      return null
  }
}

function DayElement(props) {
  let Icon = getStatusIcon(props.status, props.time)

  let isToday =
    props.time === 'PRESENT'
      ? { borderBottomWidth: 3, borderColor: '#FC3838' }
      : {}

  return (
    <TouchableOpacity>
      <View style={[styles.container, isToday]}>
        <View style={[styles.bullet, styles[`bullet--${props.time}`]]}>
          {Icon}
        </View>
        <Text style={styles.word} textAlign="center">
          {props.word}
        </Text>
      </View>
    </TouchableOpacity>
  )
}

DayElement.propTypes = {
  time: oneOf(['PAST', 'PRESENT', 'FUTURE']),
  status: oneOf(['DAY_OFF', 'COMPLETE', 'INCOMPLETE', 'PENDING']),
  word: string
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingBottom: 5,
    marginLeft: 30
  },
  bullet: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  [`bullet--${'PAST'}`]: {
    backgroundColor: '#000000'
  },
  [`bullet--${'PRESENT'}`]: {
    backgroundColor: '#FC3838',
    borderColor: '#FC3838'
  },
  [`bullet--${'FUTURE'}`]: {
    backgroundColor: '#FFFFFF',
    borderColor: '#FC3838'
  },
  word: {
    width: '100%'
  },
  ball: {
    height: 7,
    width: 7,
    borderRadius: 3.5
  }
})

export default DayElement
