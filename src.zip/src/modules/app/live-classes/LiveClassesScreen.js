import React, { useState } from 'react'
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  Alert
} from 'react-native'
import ClassList from './ClassList'
import { LIVE_CLASS, GetArrayOfWeek } from 'modules/app/mockedData'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'
import DayElement from '../../../components/LiveClassDayButton'
import { ListSeparator } from 'components'

const dayName = format(new Date(), 'EEEE', { locale: es }).toUpperCase()
const day = format(new Date(), 'd')
const monthName = format(new Date(), 'MMM', { locale: es }).toUpperCase()

const LiveClassesScreen = (props) => {
  const [week, SetWeek] = useState(GetArrayOfWeek())

  const DayHandler = (id, CompleteDay) => {
    let objIndex = week.findIndex((obj) => obj.id === id)

    let checkedValue = week[objIndex].check ? false : true
    week[objIndex].check = checkedValue

    SetWeek(
      week.map((item) =>
        item.id === id
          ? { ...item, check: checkedValue }
          : { ...item, check: false }
      )
    )
    Alert.alert('Day: ' + CompleteDay)
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.PrincipalContainer}>
        <View style={styles.ContainerBody}>
          <FlatList
            showsHorizontalScrollIndicator={false}
            style={styles.ListDayContainer}
            keyExtractor={(item, index) => item.id}
            data={week}
            horizontal={true}
            renderItem={(itemData) => (
              <View style={styles.slide}>
                <DayElement
                  DateWord={itemData.item.DateWord}
                  id={itemData.item.id}
                  check={itemData.item.check}
                  status={itemData.item.status}
                  time={String(itemData.item.check)}
                  word={itemData.item.Day}
                  numberDay={itemData.item.NumberDay}
                  DayHandler={DayHandler}
                />
              </View>
            )}
          />
        </View>

        <View style={styles.listContainer}>
          <View style={styles.dateContainer}>
            <Text style={styles.date}>{dayName}</Text>
            <Text style={[styles.date, styles.day]}> {day} </Text>
            <Text style={styles.date}>{monthName}</Text>
          </View>
          <ListSeparator />
          <ClassList list={LIVE_CLASS} goClassHandler={this.goClassHandler} />
          <ListSeparator />
        </View>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  ContainerBody: {
    height: 50,
    marginTop: 15
  },
  PrincipalContainer: {
    flex: 1
  },
  container: {
    flex: 1,
    backgroundColor: 'white'
  },
  dateContainer: {
    flexDirection: 'row',
    paddingVertical: 10
  },
  date: {
    fontSize: 20,
    color: '#808080',
    fontWeight: 'bold'
  },
  listContainer: {
    paddingHorizontal: 35,
    flex: 4,
    marginTop: 28
  },
  day: {
    marginTop: 3
  },
  ListDayContainer: {
    marginHorizontal: 16,
    flex: 1
  }
})
export default LiveClassesScreen
