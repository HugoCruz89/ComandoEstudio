import React from 'react'
import { FlatList } from 'react-native'
import { array } from 'prop-types'
import ListEmpty from '../../../components/ListEmpty'
import Separator from '../../../components/ListSeparator'
import ClassItem from './ClassItem'

const ClassList = ({ list, goClassHandler }) => {
  const keyExtractor = (item, index) => index.toString()
  const renderEmpty = () => <ListEmpty text="No hay clases." />
  const itemSeparator = () => <Separator />
  const renderItem = ({ item }) => (
    <ClassItem {...item} goClassHandler={() => goClassHandler(item)} />
  )

  return (
    <FlatList
      keyExtractor={keyExtractor}
      data={list}
      ItemSeparatorComponent={itemSeparator}
      ListEmptyComponent={renderEmpty}
      renderItem={renderItem}
    />
  )
}

ClassList.propTypes = {
  list: array
}

export default ClassList
