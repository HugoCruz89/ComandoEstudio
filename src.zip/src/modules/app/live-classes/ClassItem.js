import React from 'react'
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import { string, func, any, number } from 'prop-types'
import { format } from 'date-fns'

const ClassItem = ({
  date,
  duration,
  trainer,
  title,
  level,
  goClassHandler
}) => {
  const hour = format(date, 'hh:mm a')
  const newTitle = title.toUpperCase()
  const newLevel = level.toUpperCase()
  return (
    <TouchableOpacity onPress={goClassHandler}>
      <View style={styles.container}>
        <View style={styles.left}>
          <Text style={styles.hour}>{hour}</Text>
        </View>
        <View style={styles.right}>
          <Text style={styles.title}>{newTitle}</Text>
          <View style={styles.textHorizontal}>
            <Text style={styles.textPoint}>{duration} MIN</Text>
            <View style={styles.blackPoint} />
            <Text style={styles.textPoint}>{newLevel}</Text>
          </View>
          <View style={styles.textHorizontal}>
            <Text style={styles.trainer}>Con: </Text>
            <Text style={styles.trainerName}>{trainer}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  )
}

ClassItem.propTypes = {
  date: any,
  duration: number,
  trainer: string,
  title: string,
  level: string,
  goClassHandler: func
}

export default ClassItem

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingVertical: 15
  },
  left: {
    width: '30%',
    paddingRight: 10,
    alignItems: 'center',
    justifyContent: 'center'
  },
  hour: {
    fontSize: 18
  },
  title: {
    fontWeight: 'bold',
    fontSize: 20
  },
  textHorizontal: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  blackPoint: {
    height: 4,
    width: 4,
    borderRadius: 2,
    backgroundColor: 'black',
    marginHorizontal: 5
  },
  textPoint: {
    fontSize: 16
  },
  trainer: {
    fontSize: 16,
    color: '#b3b3b3'
  },
  trainerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b3b3b3'
  }
})
