import React from 'react'
import { View, StyleSheet } from 'react-native'
import InputForm from './../../../components/TextInput'

const FirstSectionData = () => {
  return (
    <View style={styles.ContainerDataPersonal}>
      <View style={styles.ContainerInputForm}>
        <InputForm label="Edad" placeholder="años" keyboardType="number-pad" />
      </View>
      <View style={styles.ContainerInputForm}>
        <InputForm label="Altura" placeholder="cm" keyboardType="decimal-pad" />
      </View>
      <View style={styles.ContainerInputForm}>
        <InputForm
          style={styles.InputForm}
          label="Peso"
          placeholder="kg"
          keyboardType="decimal-pad"
        />
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  ContainerDataPersonal: {
    marginHorizontal: 28,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  ContainerInputForm: {
    width: '30%'
  },
  InputForm: {
    paddingBottom: 5,
    paddingTop: 10
  }
})
export default FirstSectionData
