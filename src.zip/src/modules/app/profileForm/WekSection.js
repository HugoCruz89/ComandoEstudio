import React, { useState } from 'react'
import { View, StyleSheet } from 'react-native'
import DayButton from './../../../components/DayButton'
import TextForm from './../../../components/Text'

const WeekSection = (props) => {
  const [listDay, setListDay] = useState([
    { id: 1, descripcion: 'D', checked: false },
    { id: 2, descripcion: 'L', checked: false },
    { id: 3, descripcion: 'M', checked: false },
    { id: 4, descripcion: 'M', checked: false },
    { id: 5, descripcion: 'J', checked: false },
    { id: 6, descripcion: 'V', checked: false },
    { id: 7, descripcion: 'S', checked: false }
  ])

  const onCheckListDay = (idChecked) => {
    let objIndex = listDay.findIndex((obj) => obj.id === idChecked)
    let checkedValue = listDay[objIndex].checked ? false : true

    listDay[objIndex].checked = checkedValue

    setListDay(
      listDay.map((item) =>
        item.id === idChecked ? { ...item, checked: checkedValue } : item
      )
    )
  }

  const listDays = listDay.map((day) => (
    <DayButton
      onChecked={onCheckListDay.bind(this, day.id)}
      checked={day.checked}
      Text={day.descripcion}
      Key={day.id}
      style={styles.ContainerStyleListDay}
    />
  ))

  return (
    <View style={{ ...styles.ContainerPrincipal, ...props.style }}>
      <View style={styles.TextContainer}>
        <TextForm style={styles.TextBody} type="body">
          <TextForm style={styles.TextBodyTitle} type="body">
            Meta de ejercicio semanal:{'\n'}
          </TextForm>
          Segun su perfil, recomendamos 3-4 dias por semana
        </TextForm>
      </View>
      <View style={styles.containerBody}>
        <View style={styles.containerWeek}>{listDays}</View>
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  TextContainer: {
    marginBottom: 15,
    marginVertical: 15,
    marginHorizontal: 30
  },
  TextBody: {
    fontSize: 16
  },
  TextBodyTitle: {
    fontSize: 22
  },
  containerWeek: {
    flexDirection: 'row'
  },
  ContainerStyleListDay: {
    margin: 3,
    paddingLeft: 6,
    paddingRight: 6,
    paddingTop: 0
  },
  containerBody: {
    marginHorizontal: 25
  }
})
export default WeekSection
