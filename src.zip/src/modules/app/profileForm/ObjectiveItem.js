import React from 'react'
import { View, StyleSheet } from 'react-native'
import RadioButton from './../../../components/RadioButton'
const ObjectiveItem = (props) => {
  return (
    <View style={styles.listItem}>
      <RadioButton
        onChecked={props.onCheckListObjective.bind(this, props.id)}
        checked={props.checked}
        Text={props.description}
        style={styles.TextList}
        CheckButtonType="CheckButton"
      />
    </View>
  )
}
const styles = StyleSheet.create({
  listItem: {
    marginHorizontal: 0,
    marginVertical: 4
  },
  TextList: {
    marginLeft: 15
  }
})
export default ObjectiveItem
