import React from 'react'
import {
  View,
  StyleSheet,
  TouchableWithoutFeedback,
  Keyboard,
  ScrollView
} from 'react-native'
import TextForm from './../../../components/Text'
import FirstSectionData from './FirstSectionData'
import GenderSection from './GenderSection'
import ObjectiveSection from './ObjectiveSection'
import PreferencesSection from './PreferencesSection'
import WeekSection from './WekSection'
import Button from './../../../components/Button'
const ProfileFormScreen = (props) => {
  return (
    <ScrollView>
      <TouchableWithoutFeedback
        onPress={() => {
          Keyboard.dismiss()
        }}>
        <View style={styles.Container}>
          <View style={styles.ContainerBodyTitle}>
            <TextForm style={styles.TextTitle} type="body">
              Esta informacíon nos ayudará a determinar una rutina acorde a tus
              necesidades y gustos
            </TextForm>
          </View>
          <FirstSectionData />
          <GenderSection />
          <ObjectiveSection CountChecked="2" />
          <PreferencesSection CountChecked="2" />
          <WeekSection />
          <View style={styles.containerButton}>
            <Button title="Continuar" />
          </View>
        </View>
      </TouchableWithoutFeedback>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  Container: {
    flex: 1,
    backgroundColor: 'white'
  },
  ContainerBodyTitle: {
    marginHorizontal: 30,
    marginVertical: 10
  },
  TextTitle: {
    fontSize: 18
  },
  TextContainer: {
    marginBottom: 15,
    marginVertical: 15,
    marginHorizontal: 30
  },
  TextBody: {
    fontSize: 16
  },
  TextBodyTitle: {
    fontSize: 22
  },
  containerButton: {
    marginHorizontal: 30,
    marginVertical: 30
  }
})
export default ProfileFormScreen
