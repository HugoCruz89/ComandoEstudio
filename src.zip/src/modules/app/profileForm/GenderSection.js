import React, { useState } from 'react'
import { View, StyleSheet } from 'react-native'
import RadioButton from './../../../components/RadioButton'
import TextForm from './../../../components/Text'

const GenderSection = () => {
  const [maleCheck, setMaleCheck] = useState(true)
  const [femaleCheck, setFemaleCheck] = useState(false)

  const femaleRadioHandler = (checked) => {
    setFemaleCheck(true)
    setMaleCheck(false)
  }

  const maleRadioHandler = (checked) => {
    setMaleCheck(true)
    setFemaleCheck(false)
  }

  return (
    <View style={styles.ContainerGender}>
      <View style={styles.TextContainer}>
        <TextForm style={styles.TextBody} type="body">
          <TextForm style={styles.TextBodyTitle} type="body">
            Género:
          </TextForm>
          Nos dará un calculo aproximado de tu BMI
        </TextForm>
      </View>
      <View style={styles.ContainerSectionGender}>
        <RadioButton
          onChecked={femaleRadioHandler}
          checked={femaleCheck}
          Text={'Femenino'}
          CheckButtonType="RadioButton"
        />
        <RadioButton
          onChecked={maleRadioHandler}
          checked={maleCheck}
          Text={'Masculino'}
          CheckButtonType="RadioButton"
        />
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  ContainerGender: {
    marginHorizontal: 28
  },
  ContainerSectionGender: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 20
  },
  TextContainer: {
    marginBottom: 15
  },
  TextBody: {
    fontSize: 16
  },
  TextBodyTitle: {
    fontSize: 22
  }
})
export default GenderSection
