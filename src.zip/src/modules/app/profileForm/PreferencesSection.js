import React, { useState } from 'react'
import { View, StyleSheet } from 'react-native'
import PreferencesButton from './../../../components/PreferencesButton'
import TextForm from './../../../components/Text'
const PreferencesSection = (props) => {
  const countCheckedNumber = parseInt(props.CountChecked, 10) - 1
  const [ListPreferences, setListPreferences] = useState([
    { id: 1, descripcion: 'Fight', checked: false },
    { id: 2, descripcion: 'Flow', checked: false },
    { id: 3, descripcion: 'HIlT', checked: false },
    { id: 4, descripcion: 'Endurance', checked: false },
    { id: 5, descripcion: 'Cardio', checked: false },
    { id: 6, descripcion: 'Sweat', checked: false },
    { id: 7, descripcion: 'Programa 20 Días Bodyweight', checked: false },
    { id: 8, descripcion: 'Figth', checked: false },
    { id: 9, descripcion: 'Yoga', checked: false },
    { id: 10, descripcion: 'Endurance', checked: false }
  ])
  const CountChecked = (idCheck) => {
    const countChecked = ListPreferences.filter((item) => item.checked === true)
      .length

    if (countChecked <= countCheckedNumber) {
      return true
    }
    const objIndex = ListPreferences.findIndex((obj) => obj.id === idCheck)
    const checkedValueCurrent = ListPreferences[objIndex].checked

    if (checkedValueCurrent) {
      return true
    } else {
      return false
    }
  }

  const onCheckListPreferences = (idChecked) => {
    let flag = CountChecked(idChecked)

    if (flag) {
      const objIndex = ListPreferences.findIndex((obj) => obj.id === idChecked)
      const checkedValue = ListPreferences[objIndex].checked ? false : true

      ListPreferences[objIndex].checked = checkedValue

      setListPreferences(
        ListPreferences.map((item) =>
          item.id === idChecked ? { ...item, checked: checkedValue } : item
        )
      )
    }
  }

  const listElementPrefreneces = ListPreferences.map((preferencies) => (
    <PreferencesButton
      onChecked={onCheckListPreferences.bind(this, preferencies.id)}
      checked={preferencies.checked}
      Text={preferencies.descripcion}
      Key={preferencies.id}
    />
  ))

  return (
    <View>
      <View style={styles.TextContainer}>
        <TextForm style={styles.TextBody} type="body">
          <TextForm style={styles.TextBodyTitle} type="body">
            Preferencias:
          </TextForm>
          Selecciona el tipo de clase que sea mas a fina de ejerecicio que
          buscas
        </TextForm>
      </View>
      <View style={styles.containerListElementPrefrences}>
        {listElementPrefreneces}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  containerListElementPrefrences: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: 30
  },
  TextContainer: {
    marginBottom: 15,
    marginVertical: 15,
    marginHorizontal: 30
  },
  TextBody: {
    fontSize: 16
  },
  TextBodyTitle: {
    fontSize: 22
  }
})
export default PreferencesSection
