import React, { useState } from 'react'
import { View, FlatList, StyleSheet } from 'react-native'
import TextForm from './../../../components/Text'
import ObjectiveItem from './ObjectiveItem'

const ObjectiveSection = (props) => {
  const countCheckedNumber = parseInt(props.CountChecked, 10) - 1
  const [listObjectives, setListObjectives] = useState([
    { id: 0, checked: false, description: 'Quema de grasa' },
    {
      id: 1,
      checked: false,
      description: 'Tonificar / desarrollo masa muscular'
    },
    {
      id: 2,
      checked: false,
      description: 'Acondicionamiento Fisico'
    },
    {
      id: 3,
      checked: false,
      description: 'Comenzar a hacer ejercicio'
    },
    {
      id: 4,
      checked: false,
      description: 'Movilidad y Flexibilidad'
    }
  ])

  const CountChecked = (idCheck) => {
    let countChecked = listObjectives.filter((item) => item.checked === true)
      .length

    if (countChecked <= countCheckedNumber) {
      return true
    }
    let objIndex = listObjectives.findIndex((obj) => obj.id === idCheck)
    let checkedValueCurrent = listObjectives[objIndex].checked

    if (checkedValueCurrent) {
      return true
    } else {
      return false
    }
  }

  const onCheckListObjective = (idCheck) => {
    let flag = CountChecked(idCheck)

    if (flag) {
      let objIndex = listObjectives.findIndex((obj) => obj.id === idCheck)
      let checkedValue = listObjectives[objIndex].checked ? false : true
      listObjectives[objIndex].checked = checkedValue
      setListObjectives(
        listObjectives.map((item) =>
          item.id === idCheck ? { ...item, checked: checkedValue } : item
        )
      )
    }
  }
  return (
    <View>
      <View style={styles.TextContainer}>
        <TextForm style={styles.TextBody} type="body">
          <TextForm style={styles.TextBodyTitle} type="body">
            Objetivos:
          </TextForm>
          Máximo 2 objetivos para lograr un enfoque en su entrenamiento
        </TextForm>
      </View>
      <View style={styles.ContainerListObective}>
        <FlatList
          keyExtractor={(item, index) => item.id}
          data={listObjectives}
          renderItem={(itemData) => (
            <ObjectiveItem
              id={itemData.item.id}
              checked={itemData.item.checked}
              onCheckListObjective={onCheckListObjective}
              description={itemData.item.description}
            />
          )}
        />
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  ContainerListObective: {
    marginHorizontal: 20
  },
  TextBody: {
    fontSize: 16
  },
  TextBodyTitle: {
    fontSize: 22
  },
  TextContainer: {
    marginBottom: 15,
    marginVertical: 15,
    marginHorizontal: 30
  }
})
export default ObjectiveSection
