import React, { Component } from 'react'
import { func, object } from 'prop-types'
import { View, StyleSheet } from 'react-native'
import { connect } from 'react-redux'
import Carousel from 'react-native-snap-carousel'
import Slide from './Slide'
import { windowWidth } from 'src/utils'
import { registerScreenVisit } from 'ducks/auth'

const slides = [
  {
    title: 'Entrenamiento',
    subtitle: 'personalizado',
    description:
      'Nuestro motor de recomendaciones analiza tus objetivos y preferencias para crear la rutina más efectiva para ti.',
    image: require('media/images/intro/intro-1.jpg')
  },
  {
    title: 'Clases en vivo',
    subtitle: 'y on demand',
    description:
      'De cardio a Yoga, de HIIT a Fuerza. Más de 8 conceptos de entrenamiento, nuevas clases todos los días.',
    image: require('media/images/intro/intro-2.jpg')
  },
  {
    title: 'Dónde quieras, cuando',
    subtitle: 'quieras',
    description:
      'Cientos de clases disponibles en tu teléfono, tablet, computadora o TV.',
    image: require('media/images/intro/intro-3.jpg')
  },
  {
    title: 'Entrenadores',
    subtitle: 'líderes',
    description: 'Las mejores clases con los mejores entrenadores de LATAM.',
    image: require('media/images/intro/intro-4.jpg')
  }
]

class IntroScreen extends Component {
  state = {
    activeSlide: 0
  }

  _carouselRef = React.createRef(null)

  componentWillUnmount() {
    this.props.registerScreenVisit({ screen: 'intro' })
  }

  handleButtonPress = () => {
    if (!this._carouselRef.current) return
    this._carouselRef.current.snapToNext()
  }

  renderSlide = ({ item }) => {
    return (
      <Slide
        title={item.title}
        subtitle={item.subtitle}
        description={item.description}
        image={item.image}
        length={slides.length}
        activeSlide={this.state.activeSlide}
        carouselRef={this._carouselRef}
        handleButtonPress={this.handleButtonPress}
      />
    )
  }

  render() {
    return (
      <View style={styles.container}>
        <Carousel
          containerCustomStyle={styles['carousel-container']}
          data={slides}
          ref={this._carouselRef}
          activeSlideAlignment="start"
          inactiveSlideScale={1}
          renderItem={this.renderSlide}
          sliderWidth={windowWidth}
          itemWidth={windowWidth}
          onSnapToItem={(index) => this.setState({ activeSlide: index })}
        />
      </View>
    )
  }
}

IntroScreen.propTypes = {
  navigation: object,
  registerScreenVisit: func
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  'carousel-container': {
    flex: 1
  }
})

const mapDispatchToProps = {
  registerScreenVisit
}

export default connect(null, mapDispatchToProps)(IntroScreen)
