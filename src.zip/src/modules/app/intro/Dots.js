import React from 'react'
import { View, StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  dot: {
    borderRadius: 1.5,
    height: 3,
    width: 3,
    marginHorizontal: 5,
    backgroundColor: '#2A2B37'
  },
  container: {
    height: 11,
    width: 11,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 1,
    borderRadius: 5.5,
    borderWidth: 2,
    borderColor: '#DADADA'
  }
})

const InactiveDotElement = <View style={styles.dot} />

const DotElement = (
  <View style={styles.container}>
    <View style={styles.dot} />
  </View>
)

export { DotElement, InactiveDotElement }
