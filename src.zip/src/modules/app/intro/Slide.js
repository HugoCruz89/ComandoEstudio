import React from 'react'
import { string, func, number, any } from 'prop-types'
import { ImageBackground, StyleSheet } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import Feature from './Feature'

function Slide({
  image,
  title,
  subtitle,
  description,
  length,
  activeSlide,
  carouselRef,
  handleButtonPress
}) {
  return (
    <ImageBackground style={styles.container} source={image}>
      <LinearGradient
        style={styles.gradient}
        colors={['rgba(255,255,255,0)', '#FFFFFF']}
        start={{ x: 0, y: 0.03 }}
        end={{ x: 0, y: 1 }}
      />
      <Feature
        {...{
          title,
          subtitle,
          description,
          length,
          activeSlide,
          carouselRef,
          handleButtonPress
        }}
      />
    </ImageBackground>
  )
}

Feature.prototypes = {
  image: any,
  title: string,
  subtitle: string,
  description: string,
  length: number,
  activeSlide: number,
  carouselRef: any,
  handleButtonPress: func
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end'
  },
  gradient: {
    height: 90
  }
})

export default Slide
