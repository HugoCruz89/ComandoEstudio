import React from 'react'
import { View, StyleSheet, Image } from 'react-native'
import { Pagination } from 'react-native-snap-carousel'
import { Text, Button } from 'components'
import { DotElement, InactiveDotElement } from './Dots'
import { useNavigation } from '@react-navigation/native'
import { string, func, number, any } from 'prop-types'

const next = require('../../../media/images/next.png')

const Feature = ({
  title,
  subtitle,
  description,
  length,
  activeSlide,
  carouselRef,
  handleButtonPress
}) => {
  const navigation = useNavigation()
  return (
    <View style={styles['details-container']}>
      <View style={styles.footerContainer}>
        <View>
          <Text type="header" textAlign="center" style={styles.title}>
            {title}
          </Text>
          <Text type="header" textAlign="center" style={styles.title}>
            {subtitle}
          </Text>
        </View>
        <Pagination
          tappableDots
          carouselRef={carouselRef}
          activeDotIndex={activeSlide}
          containerStyle={styles.paginator}
          dotsLength={length}
          dotElement={DotElement}
          inactiveDotElement={InactiveDotElement}
        />
        <Text textAlign="center" style={styles['horizontal-separator']}>
          {description}
        </Text>
      </View>
      {activeSlide !== 3 ? (
        <View style={styles.nextContainer}>
          <Button
            theme="tertiary"
            style={{ container: styles['move-button'] }}
            onPress={handleButtonPress}>
            <>
              <Text style={styles.buttonText} type="body">
                Siguiente
              </Text>
              <Image source={next} />
            </>
          </Button>
        </View>
      ) : (
        <View style={styles.finishContainer}>
          <Button
            style={{ container: { marginHorizontal: 40 } }}
            theme="primary"
            title="Personalizar experiencia"
            onPress={() =>
              navigation.reset({
                index: 0,
                routes: [{ name: 'on-boarding' }]
              })
            }
          />
        </View>
      )}
    </View>
  )
}

Feature.prototypes = {
  title: string,
  subtitle: string,
  description: string,
  length: number,
  activeSlide: number,
  carouselRef: any,
  handleButtonPress: func
}

export default Feature

const styles = StyleSheet.create({
  'details-container': {
    backgroundColor: '#FFFFFF',
    justifyContent: 'space-between',
    height: 235,
    paddingBottom: 5
  },
  'horizontal-separator': {
    height: 60,
    fontSize: 14,
    fontFamily: 'Lato',
    fontWeight: 'normal',
    color: '#8C8C8C'
  },
  paginator: {
    paddingVertical: 0
  },
  title: {
    fontWeight: '800',
    fontSize: 20,
    color: '#000000',
    fontFamily: 'Raleway'
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 30,
    flex: 1,
    justifyContent: 'space-between'
  },
  nextContainer: {
    paddingHorizontal: 10
  },
  'move-button': {
    justifyContent: 'flex-end',
    marginBottom: 5
  },
  buttonText: {
    color: '#FC3838',
    fontWeight: 'bold',
    fontSize: 16,
    fontFamily: 'Raleway',
    textTransform: 'uppercase'
  },
  finishContainer: {
    paddingHorizontal: 10
  },
  buttonContainer: {
    marginBottom: 5
  }
})
