import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  Keyboard,
  TouchableWithoutFeedback,
  Text,
  Alert
} from 'react-native'
import TextForm from './../../../components/Text'
import InputForm from './../../../components/TextInput'
import GenderButton from './../../../components/GenderButton'
import ButtonForm from './../../../components/Button'
import { useDispatch, useSelector } from 'react-redux'
import { updateProfile } from 'ducks/app'
import { updateDataGeneral } from 'ducks/auth'
import { Header } from '../../../components'
import { useNavigation } from '@react-navigation/native'
const GeneralScreen = ({ route }) => {
  const navigation = useNavigation()
  const appOnboardingData = useSelector(
    ({ auth: { onboardingData } }) => onboardingData
  )
  const dispach = useDispatch()

  const [weight, setWeight] = useState(String(route.params.weight))
  const [weightError, setWeightError] = useState('')
  const [height, setHeight] = useState(String(route.params.height))
  const [heightError, setHeightError] = useState('')
  const [age, setAge] = useState(String(route.params.age))
  const [ageError, setAgeError] = useState('')
  const [maleCheck, setMaleCheck] = useState(route.params.checkMale)
  const [femaleCheck, setFemaleCheck] = useState(route.params.checkFemale)
  const gotoBack = () => {
    navigation.goBack(null)
  }
  const handleWeight = (value) => {
    setWeightError('')
    setWeight(value)
  }
  const handleHeight = (value) => {
    setHeightError('')
    setHeight(value)
  }
  const handleAge = (value) => {
    setAgeError('')
    setAge(value)
  }
  const ValidateInputs = () => {
    let MistakesCount = 0
    if (weight.length === 0) {
      MistakesCount++
      setWeightError('Es obligaotrio este campo')
    }
    if (height.length === 0) {
      MistakesCount++
      setHeightError('Es obligaotrio este campo')
    }
    if (age.length === 0) {
      MistakesCount++
      setAgeError('Es obligaotrio este campo')
    }

    return MistakesCount > 0 ? false : true
  }

  const Updating = async () => {
    try {
      let data = {
        weight: parseInt(weight, 10),
        height: parseInt(height, 10),
        age: parseInt(age, 10),
        gender: maleCheck === true ? 'male' : 'female'
      }
      let resp = await dispach(updateProfile(data))
      const {
        payload: { saved }
      } = resp
      if (saved) {
        let data = {
          weight: parseInt(weight, 10),
          height: parseInt(height, 10),
          age: parseInt(age, 10),
          gender: maleCheck === true ? 'male' : 'female',
          activity: appOnboardingData.activity,
          goal: appOnboardingData.goal,
          schedule: appOnboardingData.schedule
        }
        await dispach(updateDataGeneral(data))
        Alert.alert(
          'Actualización Correcta',
          'Se han actuzalizado correctamente los datos',
          [{ text: 'Ok', onPress: gotoBack }]
        )
      } else {
        Alert.alert('Ocurrio un error, intentalo nuevamente')
      }
    } catch (error) {
      console.log('false', error)
    }
  }
  const Update = () => {
    if (ValidateInputs()) {
      Updating()
    }
  }

  const femaleRadioHandler = (checked) => {
    setFemaleCheck(true)
    setMaleCheck(false)
  }

  const maleRadioHandler = (checked) => {
    setMaleCheck(true)
    setFemaleCheck(false)
  }
  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss()
      }}>
      <View style={styles.BodyContainer}>
        <Header title="Generales" />
        <View style={styles.InputContainer}>
          <View style={styles.ContainerInputForm}>
            <Text style={styles.measurement}>kg</Text>
            <InputForm
              error={weightError}
              value={weight}
              label="Peso"
              keyboardType="number-pad"
              onChangeText={handleWeight}
            />
          </View>
          <View style={styles.ContainerInputForm}>
            <Text style={styles.measurement}>cm</Text>
            <InputForm
              error={heightError}
              value={height}
              label="Altura"
              keyboardType="number-pad"
              onChangeText={handleHeight}
            />
          </View>
          <View style={styles.ContainerInputForm}>
            <Text style={styles.measurement}>años</Text>
            <InputForm
              error={ageError}
              value={age}
              label="Edad"
              keyboardType="number-pad"
              onChangeText={handleAge}
            />
          </View>
        </View>
        <View style={styles.ContainerGender}>
          <View style={styles.ContainerTextGender}>
            <TextForm style={styles.TextGender}>Género</TextForm>
          </View>
          <View style={styles.containerMan}>
            <GenderButton
              onChecked={maleRadioHandler}
              checked={maleCheck}
              CheckButtonType="RadioButton"
              Text={'Soy hombre'}
              style={styles.TextStyle}
            />
          </View>
          <GenderButton
            Text={'Soy mujer'}
            onChecked={femaleRadioHandler}
            checked={femaleCheck}
            CheckButtonType="RadioButton"
            style={styles.TextStyle}
          />
        </View>
        <View style={styles.containerButtonAccept}>
          <ButtonForm
            title="actualizar"
            onPress={Update}
            style={{
              text: styles.buttonText,
              container: styles.buttonContainer
            }}
          />
        </View>
      </View>
    </TouchableWithoutFeedback>
  )
}
const styles = StyleSheet.create({
  Title: {
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 20
  },
  InputContainer: {
    flex: 2,
    marginHorizontal: 30,
    paddingTop: 20
  },
  ContainerGender: {
    flex: 2,
    marginHorizontal: 30
  },
  BodyContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  ContainerTextGender: {
    marginBottom: 9
  },
  TextGender: {
    fontSize: 16,
    fontWeight: '400'
  },
  TextStyle: {
    fontWeight: '700',
    fontSize: 14
  },
  containerButtonAccept: {
    flex: 1,
    paddingTop: '5%',
    marginHorizontal: 30,
    justifyContent: 'flex-end',
    paddingBottom: 41
  },
  measurement: {
    position: 'absolute',
    right: 0,
    bottom: 25,
    color: '#8C8C8C'
  },
  containerMan: {
    marginBottom: 17
  },
  buttonContainer: {
    height: 50
  },
  buttonText: {
    fontSize: 18,
    fontWeight: '700'
  }
})

export default GeneralScreen
