import React, { useEffect, useState } from 'react'
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native'
import { Text as TextForm, ItemMenu } from 'components'
import { Separator } from 'modules/auth/static-components'
import { useNavigation } from '@react-navigation/native'
import { useSelector } from 'react-redux'
import { LISTDAY } from 'modules/app/mockedData'
//TODO: refactorizar utilizando useRequest

const back = require('../../../media/images/back.png')
const arrow = require('../../../media/images/arrow-rigth.png')

const CustomizeTrainingMenu = (props) => {
  const [listDay, setListDay] = useState(LISTDAY)
  const [weight, setWeight] = useState('')
  const [height, setHeight] = useState('')
  const [age, setAge] = useState('')

  const [checkMale, setCheckMale] = useState(false)
  const [checkFemale, setCheckFemale] = useState(false)
  const [activity, setLevelActivity] = useState(0)
  const [listObjectivesSelected, setListObjectivesSelected] = useState([])
  const [listDaysSelected, setListDaysSelected] = useState([])
  const appOnboardingData = useSelector(
    ({ auth: { onboardingData } }) => onboardingData
  )

  useEffect(() => {
    async function fetch() {
      try {
        // let resp = await dispatch(getDataProfile())
        setWeight(appOnboardingData.weight)
        setHeight(appOnboardingData.height)
        setAge(appOnboardingData.age)
        setLevelActivity(appOnboardingData.activity)
        setListObjectivesSelected(appOnboardingData.goal)
        setListDaysSelected(appOnboardingData.schedule)
        if (appOnboardingData.gender === 'male') {
          setCheckMale(true)
          setCheckFemale(false)
        } else {
          setCheckFemale(true)
          setCheckMale(false)
        }

        listDay.map((item, index) => {
          item.checked = listDaysSelected[index]
        })
      } catch (error) {
        console.log('false', error)
      }
    }
    fetch()
  })

  const navigation = useNavigation()
  return (
    <View style={styles.PrincipalContainer}>
      <View style={styles.containerTitle}>
        <TextForm style={styles.title} type="title">
          PERSONALIZAR
        </TextForm>
        <TextForm style={styles.title} type="title">
          ENTRENAMIENTO
        </TextForm>
        <TouchableOpacity style={styles.back} onPress={props.navigation.goBack}>
          <Image source={back} />
        </TouchableOpacity>
      </View>
      <View style={styles.BodyTextContainer}>
        <TextForm style={styles.BodyText} type="body">
          Esta información nos ayudará a determinar una rutina acorde a tus
          necesidades y gustos
        </TextForm>
      </View>
      <View style={styles.containerMenu}>
        <TouchableOpacity
          style={styles.buttonMenu}
          onPress={() =>
            navigation.navigate('general-screen', {
              age: age,
              weight: weight,
              height: height,
              checkFemale: checkFemale,
              checkMale: checkMale
            })
          }>
          <ItemMenu style={styles.TextItem} Title="generales" />
          <Image source={arrow} />
        </TouchableOpacity>
        <Separator />
        <TouchableOpacity
          style={styles.buttonMenu}
          onPress={() =>
            navigation.navigate('activity-level', {
              activity: activity
            })
          }>
          <ItemMenu style={styles.TextItem} Title="nivel de actividad" />
          <Image source={arrow} />
        </TouchableOpacity>
        <Separator />
        <TouchableOpacity
          style={styles.buttonMenu}
          onPress={() =>
            navigation.navigate('objectives', {
              list: listObjectivesSelected
            })
          }>
          <ItemMenu style={styles.TextItem} Title="objetivos" />
          <Image source={arrow} />
        </TouchableOpacity>
        <Separator />
        <TouchableOpacity
          style={styles.buttonMenu}
          onPress={() =>
            navigation.navigate('week-excercises', {
              listDaySelect: listDay
            })
          }>
          <ItemMenu style={styles.TextItem} Title="ejercicio semanal" />
          <Image source={arrow} />
        </TouchableOpacity>
        <Separator />
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  containerTitle: {
    marginTop: 58,
    marginBottom: 25
  },
  title: {
    fontSize: 20,
    color: '#000000',
    fontWeight: '800'
  },
  back: {
    position: 'absolute',
    left: 15
  },
  buttonMenu: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  BodyText: {
    textAlign: 'justify',
    fontWeight: '400',
    fontSize: 16,
    color: '#8c8c8c'
  },
  BodyTextContainer: {
    alignItems: 'center',
    marginTop: 13,
    marginRight: 37,
    marginLeft: 29
  },
  containerMenu: {
    flex: 1,
    width: '100%',
    paddingHorizontal: 30,
    marginTop: 43
  },
  TextItem: {
    fontWeight: '700',
    fontSize: 16,
    fontFamily: 'Raleway'
  }
})

export default CustomizeTrainingMenu
