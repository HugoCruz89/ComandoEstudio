export { default } from './CustomizeTrainingMenu'
