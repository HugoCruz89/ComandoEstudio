import React, { useState } from 'react'
import { View, StyleSheet, Image, Dimensions, Alert } from 'react-native'
import TextForm from './../../../components/Text'
import DayButton from './../../../components/DayButton'
import ButtonForm from './../../../components/Button'
import { windowHeight } from 'src/utils'
import { useDispatch, useSelector } from 'react-redux'
import { updateWeekDays } from 'ducks/app'
import { updateDataGeneral } from 'ducks/auth'
import { useNavigation } from '@react-navigation/native'
const Width = Dimensions.get('window').width
const totalHeight = windowHeight / 2.5
import { LISTDAY } from 'modules/app/mockedData'

const WeekExercises = ({ route }) => {
  const navigation = useNavigation()
  const appOnboardingData = useSelector(
    ({ auth: { onboardingData } }) => onboardingData
  )
  const dispatch = useDispatch()
  const [listDay, setListDay] = useState(LISTDAY)

  const gotoBack = () => {
    navigation.goBack(null)
  }
  const onCheckListDay = (idChecked) => {
    const objIndex = listDay.findIndex((obj) => obj.id === idChecked)

    const checkedValue = listDay[objIndex].checked ? false : true

    listDay[objIndex].checked = checkedValue

    setListDay(
      listDay.map((item) =>
        item.id === idChecked ? { ...item, checked: checkedValue } : item
      )
    )
  }
  const builArrayWeekdays = () => {
    let newArryay = []
    listDay.forEach((element) => {
      newArryay.push(element.checked)
    })
    return newArryay
  }
  const Update = async () => {
    const arrayWeekDays = builArrayWeekdays()
    let schedule = {
      schedule: arrayWeekDays
    }
    let respWeek = await dispatch(updateWeekDays(schedule))

    const {
      payload: { saved }
    } = respWeek
    if (saved) {
      let data = {
        weight: appOnboardingData.weight,
        height: appOnboardingData.height,
        age: appOnboardingData.age,
        gender: appOnboardingData.gender,
        activity: appOnboardingData.activity,
        goal: appOnboardingData.goal,
        schedule: arrayWeekDays
      }
      await dispatch(updateDataGeneral(data))
      Alert.alert(
        'Actualización Correcta',
        'Se han actuzalizado correctamente los datos',
        [{ text: 'Ok', onPress: gotoBack }]
      )
    } else {
      Alert.alert('Ocurrio un error, intentalo nuevamente')
    }
  }

  const listDays = listDay.map((day, index) => (
    <DayButton
      onChecked={onCheckListDay.bind(this, day.id)}
      checked={day.checked}
      Text={day.descripcion}
      key={index}
      style={styles.ContainerStyleListDay}
    />
  ))

  return (
    <View style={styles.PrincipalImageContainer}>
      <View style={styles.imageContainer}>
        <Image
          style={styles.logo}
          source={require('../../../media/images/WomanWeek.png')}
        />
      </View>
      <View style={styles.BodyTextContainer}>
        <TextForm style={styles.BodyText} type="body">
          Selecciona los días que desees hacer ejercicio.
        </TextForm>
      </View>
      <View style={styles.containerWeek}>{listDays}</View>
      <View style={styles.containerFooter}>
        <TextForm style={styles.BodyText} type="body">
          Recomendamos hacer ejercicio diario, según tu nivel tu intensidad.
        </TextForm>
      </View>
      <View style={styles.containerButtonAccept}>
        <ButtonForm onPress={Update} title="actualizar" style={styles.Button} />
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  PrincipalImageContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  imageContainer: {
    height: totalHeight,
    alignSelf: 'center',
    flex: 6
  },
  BodyTextContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  containerWeek: {
    flexDirection: 'row',
    marginHorizontal: 30,
    flex: 1,
    alignItems: 'center'
  },
  containerFooter: {
    marginHorizontal: 30,
    flex: 1,
    alignItems: 'center'
  },
  containerButtonAccept: {
    flex: 1,
    paddingTop: '5%',
    marginHorizontal: 30,
    justifyContent: 'flex-end',
    paddingBottom: 41
  },
  BodyText: {
    textAlign: 'center'
  },

  Button: {
    fontWeight: '700',
    fontSize: 16
  },
  logo: {
    height: totalHeight + 80,
    width: Width * 1.2,
    resizeMode: 'contain',
    position: 'relative',
    left: 10,
    top: 0
  }
})
export default WeekExercises
