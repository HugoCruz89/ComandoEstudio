import React from 'react'
import { View, StyleSheet, Dimensions, Alert } from 'react-native'
import TextForm from './../../../components/Text'
import ButtonForm from './../../../components/Button'
import Slider from './../../../components/Slider/Slider'
import { useDispatch, useSelector } from 'react-redux'
import { updateProfile } from 'ducks/app'
import { updateDataGeneral } from 'ducks/auth'
import { useValue, concat } from 'react-native-reanimated'
import { ReText } from 'react-native-redash/lib/module/v1'
import { Header } from '../../../components'
import { useNavigation } from '@react-navigation/native'
const windowHeight = Dimensions.get('window').height
const ActivityLevel = ({ route }) => {
  const navigation = useNavigation()
  const appOnboardingData = useSelector(
    ({ auth: { onboardingData } }) => onboardingData
  )
  const dispach = useDispatch()
  const totalHeight = windowHeight * 0.45
  const steps = 4
  let levelActivity = route.params.activity
  const label = useValue('Necesito recuperar el alienteo despues de subir')
  const complement = useValue('escaleras')
  const status = useValue('Principiante')
  function activeCallback(value) {}
  function endCallback(value) {
    if (levelActivity !== value) {
      levelActivity = value
      setValuCallback(value)
    }
  }
  const gotoBack = () => {
    navigation.goBack(null)
  }
  function setValuCallback(value) {
    switch (value) {
      case 0:
        label.setValue('Necesito recuperar el alienteo despues de subir')
        complement.setValue('escaleras')
        status.setValue('Principiante')
        break
      case 1:
        label.setValue('Hago ejercicio todos los días porque estar en forma')
        complement.setValue('es esencial para mi')
        status.setValue('Intermedio')
        break
      case 2:
        label.setValue('Estoy en buena forma')
        complement.setValue('')
        status.setValue('Avanzado')
        break
      case 3:
        label.setValue('Estoy en buena forma')
        complement.setValue('')
        status.setValue('Profesional')
        break
      default:
        label.setValue('')
        complement.setValue('')
        status.setValue('')
        break
    }
  }
  const Updating = async () => {
    try {
      let data = {
        activity: levelActivity
      }
      let resp = await dispach(updateProfile(data))
      const {
        payload: { saved }
      } = resp
      if (saved) {
        let data = {
          weight: appOnboardingData.weight,
          height: appOnboardingData.height,
          age: appOnboardingData.age,
          gender: appOnboardingData.gender,
          activity: levelActivity,
          goal: appOnboardingData.goal,
          schedule: appOnboardingData.schedule
        }

        await dispach(updateDataGeneral(data))
        Alert.alert(
          'Actualización Correcta',
          'Se han actuzalizado correctamente los datos',
          [{ text: 'Ok', onPress: gotoBack }]
        )
      } else {
        Alert.alert('Ocurrio un error, intentalo nuevamente')
      }
    } catch (error) {
      console.log('false', error)
    }
  }
  const Update = () => {
    Updating()
  }
  return (
    <View style={styles.BodyContainer}>
      <Header title="Nivel de actividad" />
      <View style={styles.levelContainer}>
        <ReText text={concat(status)} style={styles.BodyTextSlider} />
        <ReText text={concat(label)} style={styles.levelText} />
        <ReText text={concat(complement)} style={styles.levelText} />
      </View>
      <View style={styles.containerSlide}>
        <TextForm style={styles.BodyTextSlider} type="body">
          Profesional
        </TextForm>
        <Slider
          {...{
            totalHeight,
            steps,
            levelActivity,
            activeCallback,
            endCallback
          }}
        />
      </View>
      <View style={styles.containerButtonAccept}>
        <ButtonForm
          title="actualizar"
          onPress={Update}
          style={{
            text: styles.buttonText,
            container: styles.buttonContainer
          }}
        />
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  BodyContainer: {
    flex: 1,
    backgroundColor: 'white'
  },
  BodyText: {
    textAlign: 'justify',
    fontWeight: '400',
    fontSize: 14,
    color: '#8c8c8c'
  },
  BodyTextContainer: {
    flex: 0.5,
    alignItems: 'center',
    paddingTop: 90,
    marginHorizontal: 30
  },
  containerSlide: {
    flex: 3,
    marginHorizontal: 30,
    alignItems: 'center'
  },
  containerButtonAccept: {
    marginHorizontal: 30,
    marginBottom: 30
  },
  BodyTextSlider: {
    fontWeight: '700',
    fontSize: 14,
    marginBottom: 14
  },
  levelContainer: {
    alignItems: 'center',
    marginTop: windowHeight * 0.1,
    marginBottom: windowHeight * 0.05
  },
  buttonContainer: {
    height: 46
  },
  buttonText: {
    fontSize: 18,
    fontWeight: '700'
  }
})
export default ActivityLevel
