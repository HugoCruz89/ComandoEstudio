import React, { useState, useEffect } from 'react'
import { View, StyleSheet, FlatList, Alert } from 'react-native'
import TextForm from './../../../components/Text'
import ButtonForm from './../../../components/Button'
import ObjectiveButton from './../../../components/ObjectivesButton'
import { useDispatch, useSelector } from 'react-redux'
import { updateProfile } from 'ducks/app'
import { updateDataGeneral } from 'ducks/auth'
import Toast from 'react-native-simple-toast'
import { useNavigation } from '@react-navigation/native'
import { OBJECTIVES } from 'modules/app/mockedData'
const Objectives = ({ route }) => {
  const navigation = useNavigation()
  const appOnboardingData = useSelector(
    ({ auth: { onboardingData } }) => onboardingData
  )
  const [disbledButton, setDisabledButton] = useState(false)
  const dispach = useDispatch()
  const countCheckedNumber = parseInt(2, 10) - 1
  const [listObjectives, setListObjectives] = useState(OBJECTIVES)
  const [listObjectivesSelected] = useState(route.params.list)
  const gotoBack = () => {
    navigation.goBack(null)
  }
  useEffect(() => {
    setListObjectives(listObjectives.map((item) => (item.checked = false)))
    listObjectivesSelected.forEach((element) => {
      let itemSelect = listObjectives.filter(
        (item) => item.descriptionToDataBase === element
      )
      let checkedValue = listObjectives[itemSelect[0].id].checked ? true : true
      listObjectives[itemSelect[0].id].checked = checkedValue
      setListObjectives(
        listObjectives.map((item) =>
          item.id === itemSelect[0].id
            ? { ...item, checked: checkedValue }
            : item
        )
      )
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const EnableButtonGoals = () => {
    const countChecked = listObjectives.find((item) => item.checked == true)
    if (countChecked !== undefined) setDisabledButton(false)
    else setDisabledButton(true)
  }
  const DisableTex = () => {
    setListObjectives(
      listObjectives.map((item) =>
        item.checked === false ? { ...item, enable: false } : item
      )
    )
  }
  const EnableTex = () => {
    const NewArray = listObjectives
    NewArray.forEach((item) => (item.enable = true))
    console.log(NewArray)
    setListObjectives(NewArray)
  }

  const CountChecked = (idCheck) => {
    let countChecked = listObjectives.filter((item) => item.checked === true)
      .length

    if (countChecked <= countCheckedNumber) {
      return true
    }
    let objIndex = listObjectives.findIndex((obj) => obj.id === idCheck)
    let checkedValueCurrent = listObjectives[objIndex].checked

    if (checkedValueCurrent) {
      return true
    } else {
      return false
    }
  }

  const onCheckListObjective = (idCheck) => {
    let flag = CountChecked(idCheck)

    if (flag) {
      EnableTex()
      let objIndex = listObjectives.findIndex((obj) => obj.id === idCheck)
      let checkedValue = listObjectives[objIndex].checked ? false : true
      listObjectives[objIndex].checked = checkedValue
      setListObjectives(
        listObjectives.map((item) =>
          item.id === idCheck ? { ...item, checked: checkedValue } : item
        )
      )
      const count = listObjectives.filter((item) => item.checked === true)

      if (count.length === 2) {
        DisableTex()
      }
      EnableButtonGoals()
    } else {
      Toast.showWithGravity(
        'No puedes seleccionar mas de 2 objetivos',
        Toast.SHORT,
        Toast.TOP
      )
    }
  }

  const builArrayObjectives = () => {
    let newArryay = []
    const SelectedItems = listObjectives.filter((item) => item.checked === true)
    SelectedItems.forEach((element) => {
      newArryay.push(String(element.descriptionToDataBase))
    })
    return newArryay
  }
  const Updating = async () => {
    try {
      const arrayObjectives = builArrayObjectives()
      let data = {
        goal: arrayObjectives
      }
      let resp = await dispach(updateProfile(data))
      const {
        payload: { saved }
      } = resp
      if (saved) {
        let data = {
          weight: appOnboardingData.weight,
          height: appOnboardingData.height,
          age: appOnboardingData.age,
          gender: appOnboardingData.gender,
          activity: appOnboardingData.activity,
          goal: arrayObjectives,
          schedule: appOnboardingData.schedule
        }

        await dispach(updateDataGeneral(data))
        Alert.alert(
          'Actualización Correcta',
          'Se han actuzalizado correctamente los datos',
          [{ text: 'Ok', onPress: gotoBack }]
        )
      } else {
        Alert.alert('Ocurrio un error, intentalo nuevamente')
      }
    } catch (error) {
      console.log('false', error)
    }
  }

  const update = () => {
    console.log('here')
    Updating()
  }
  return (
    <View style={styles.BodyContainer}>
      <View style={styles.BodyTextContainer}>
        <TextForm style={styles.BodyText} type="body">
          Elige máximo 2 objetivos para lograr un enfoque en tu entrenamiento
        </TextForm>
      </View>
      <View style={styles.ContainerListObective}>
        <FlatList
          keyExtractor={(item, index) => item.id}
          data={listObjectives}
          renderItem={(itemData) => (
            <ObjectiveButton
              id={itemData.item.id}
              checked={itemData.item.checked}
              onCheckListObjective={onCheckListObjective}
              description={itemData.item.description}
              Icon={itemData.item.icon}
              image={itemData.item.image}
              enable={itemData.item.enable}
            />
          )}
        />
      </View>
      <View style={styles.containerButtonAccept}>
        <ButtonForm
          disabled={disbledButton}
          title="actualizar"
          onPress={update}
        />
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  BodyContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  BodyText: {
    textAlign: 'center',
    fontWeight: '400',
    fontSize: 14,
    color: '#8c8c8c'
  },
  BodyTextContainer: {
    flex: 0.5,
    alignItems: 'center',
    paddingTop: 42,
    marginHorizontal: 30
  },
  containerButtonAccept: {
    flex: 1,
    paddingTop: '5%',
    marginHorizontal: 30,
    justifyContent: 'flex-end',
    paddingBottom: 41
  },
  ContainerListObective: {
    marginHorizontal: 30,
    flex: 3
  }
})
export default Objectives
