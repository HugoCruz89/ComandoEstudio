import React, { useState, useEffect } from 'react'
import {
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Linking,
  Dimensions,
  ScrollView,
  Platform
} from 'react-native'
const windowHeight = Dimensions.get('window').height
import { connect, useSelector, useDispatch } from 'react-redux'
import ImagePicker from 'react-native-image-picker'
import { useNavigation } from '@react-navigation/native'
import { Text as TextForm, ItemMenu } from 'components'
import { Separator } from 'modules/auth/static-components'
import { logOut } from 'ducks/auth'
import { getDataProfile } from 'ducks/app'
import axios from 'axios'
import ProfileImage from './ProfileImage'

const pencil = <Image source={require('../../../media/images/pen.png')} />
const image = (
  <Image source={require('../../../media/images/arrow-rigth.png')} />
)

const ProfileScreen = (props) => {
  const dispatch = useDispatch()

  const urlBase = 'https://commando.crossoverdeveloper.com/api'
  const { token, firstName, lastName } = useSelector((state) => state.auth)
  const [imagePath, setImagePath] = useState(null)
  const [fullName, setFullName] = useState('')
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetch() {
      try {
        let resp = await dispatch(getDataProfile())
        if (resp.payload.profile.firstName === '') {
          setFullName(`${firstName} ${lastName}`)
        } else {
          setFullName(
            `${resp.payload.profile.firstName} ${resp.payload.profile.lastName}`
          )
        }
        if (resp.payload.profile.avatar === undefined) {
        } else {
          setImagePath(resp.payload.profile.avatar)
        }
        setIsLoading(false)
      } catch (error) {
        setIsLoading(false)
      }
    }
    fetch()
  }, [dispatch, lastName, firstName])

  const navigation = useNavigation()

  const openImagePicker = () => {
    const options = {
      title: 'Selecciona tu imagen o escogela de tu biblioteca',
      storageOptions: {
        skipBackup: true,
        path: 'images'
      }
    }
    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
      } else if (response.error) {
      } else if (response.customButton) {
      } else {
        SaveImage(
          Platform.OS === 'android'
            ? response.uri
            : response.uri.replace('file://', '')
        )
      }
    })
  }
  const SaveImage = async (data) => {
    if (data != null) {
      setIsLoading(true)
      try {
        const formAvatar = new FormData()
        formAvatar.append('avatar', {
          uri: data,
          type: 'image/jpeg',
          name: 'avatar.jpg'
        })

        const response = await axios.post(
          `${urlBase}/user/profile/upload`,
          formAvatar,
          {
            headers: {
              Accept: 'application/json',
              'Content-Type': 'multipart/form-data',
              authorization: `Bearer ${token}`
            }
          }
        )
        if (response && response.data && response.data.saved) {
          setImagePath(data)
        }
        setIsLoading(false)
        // dispatch(setUserImage(data))
      } catch (error) {
        setIsLoading(false)
        console.warn('error', error)
      }
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.principalTitleContainer}>
        <TextForm style={styles.Title} type="title">
          MI PERFIL
        </TextForm>
      </View>
      <View style={styles.containerImage}>
        <ProfileImage {...{ imagePath, isLoading }} />
        <View style={styles.Icon}>
          <TouchableOpacity onPress={openImagePicker.bind(this)}>
            {pencil}
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.containerTitle}>
        <TouchableOpacity
          onPress={() =>
            navigation.navigate('change-name', {
              firstName: firstName,
              lastName: lastName
            })
          }>
          <TextForm style={styles.TagName} type="title">
            {fullName}
          </TextForm>
        </TouchableOpacity>
      </View>
      <View style={styles.containerMenu}>
        <ScrollView>
          <TouchableOpacity
            style={styles.buttonMenu}
            onPress={() =>
              navigation.navigate('customize-training', {
                title: 'PERZONALIZAR ENTRENAMIENTO'
              })
            }>
            <ItemMenu Title="perzonalizar entrenamiento" />
            {image}
          </TouchableOpacity>
          <Separator />
          <TouchableOpacity
            style={styles.buttonMenu}
            onPress={() =>
              navigation.navigate('changePassword', {
                title: ''
              })
            }>
            <ItemMenu Title="CAMBIO DE CONTRASEÑA" />
            {image}
          </TouchableOpacity>
          <Separator />
          <TouchableOpacity
            style={styles.buttonMenu}
            onPress={() =>
              navigation.navigate('notifications', {
                title: 'NOTIFICACIONES'
              })
            }>
            <ItemMenu Title="NOTIFICACIONES" />
            {image}
          </TouchableOpacity>
          <Separator />
          <TouchableOpacity
            onPress={() =>
              Linking.openURL('https://www.commando-ondemand.com/privacy')
            }>
            <ItemMenu Title="POLITICAS DE PRIVACIDAD" />
          </TouchableOpacity>
          <Separator />
          <TouchableOpacity
            onPress={() =>
              Linking.openURL('http://help.commando-ondemand.com/es/')
            }>
            <ItemMenu Title="FAQ" />
          </TouchableOpacity>
          <Separator />
          <TouchableOpacity onPress={props.logOut}>
            <ItemMenu Title="LOGOUT" style={styles.TextLogOut} />
          </TouchableOpacity>
        </ScrollView>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'white'
  },
  principalTitleContainer: {
    marginTop: windowHeight * 0.025,
    flex: 0.2
  },
  containerImage: {
    alignItems: 'center',
    flex: 1.4
  },
  containerTitle: {
    marginHorizontal: windowHeight * 0.1,
    paddingTop: 10,
    flex: 0.15
  },
  containerMenu: {
    width: '100%',
    marginBottom: 20,
    paddingHorizontal: 30,
    flex: 2.8,
    marginTop: windowHeight * 0.02
  },

  Title: {
    fontSize: 20,
    color: '#000000',
    fontWeight: '700'
  },
  TagName: {
    fontSize: 18,
    textAlign: 'center',
    fontWeight: '500'
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    justifyContent: 'center',
    alignItems: 'center'
  },
  image: {
    width: 130,
    height: 130,
    top: windowHeight * 0.04,
    borderRadius: 50
  },
  buttonMenu: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  TextLogOut: {
    color: '#DADADA'
  },
  Icon: { marginTop: windowHeight * 0.025 }
})

const mapDispatchToProps = {
  logOut
}

export default connect(null, mapDispatchToProps)(ProfileScreen)
