import React from 'react'
import { Bubbles } from 'react-native-loader'
import { View, Image, StyleSheet, Dimensions } from 'react-native'
import { string, bool } from 'prop-types'

const windowHeight = Dimensions.get('window').height

const ProfileImage = ({ imagePath, isLoading }) => {
  return (
    <>
      {imagePath ? (
        <>
          {isLoading ? (
            <View style={styles.bubblesContainer}>
              <Bubbles size={10} color="#FFFFFF" />
            </View>
          ) : (
            <Image style={styles.logo} source={{ uri: imagePath }} />
          )}
        </>
      ) : (
        <View style={styles.bubblesContainer} />
      )}
    </>
  )
}

ProfileImage.propTypes = {
  imagePath: string,
  isLoading: bool
}

export default ProfileImage

const styles = StyleSheet.create({
  logo: {
    alignSelf: 'stretch',
    width: 130,
    height: 130,
    top: windowHeight * 0.04,
    borderRadius: 70,
    position: 'relative'
  },
  bubblesContainer: {
    width: 130,
    height: 130,
    borderRadius: 70,
    backgroundColor: '#8C8C8C',
    top: windowHeight * 0.04,
    justifyContent: 'center',
    alignItems: 'center'
  }
})
