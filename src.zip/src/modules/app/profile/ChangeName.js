import React, { useState } from 'react'
import {
  View,
  StyleSheet,
  Keyboard,
  TouchableWithoutFeedback,
  Alert
} from 'react-native'
import ButtonForm from './../../../components/Button'
import InputForm from './../../../components/TextInput'
import { useDispatch } from 'react-redux'
import { updateProfile } from 'ducks/app'
import { updateProfileStore } from 'ducks/auth'
import { useNavigation } from '@react-navigation/native'
const ChangeName = ({ route }) => {
  const { firstName, lastName } = route.params
  const dispatch = useDispatch()
  const navigation = useNavigation()
  const [name, setName] = useState(firstName)
  const [nameError, setNameError] = useState('')
  const [secondName, setSecondName] = useState(lastName)
  const [secondNameError, setSecondNameError] = useState('')
  const gotoBack = () => {
    navigation.goBack(null)
  }
  const handleName = (value) => {
    setNameError('')
    setName(value)
  }

  const handleSecondName = (value) => {
    setSecondNameError('')
    setSecondName(value)
  }

  const Updating = async () => {
    try {
      await dispatch(updateProfile({ firstName: name, lastName: secondName }))
      await dispatch(
        updateProfileStore({
          firstName: name,
          lastName: secondName
        })
      )

      Alert.alert(
        'Actualización Correcta',
        'Se han actuzalizado correctamente los datos',
        [{ text: 'Ok', onPress: gotoBack }]
      )
    } catch (error) {}
  }
  const ValidateInputs = () => {
    let MistakesCount = 0
    if (name.length === 0) {
      MistakesCount++
      setNameError('Es obligaotrio este campo')
    }
    if (secondName.length === 0) {
      MistakesCount++
      setSecondNameError('Es obligaotrio este campo')
    }

    return MistakesCount > 0 ? false : true
  }
  const Update = () => {
    if (ValidateInputs()) {
      Updating()
    }
  }
  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss()
      }}>
      <View style={styles.Container}>
        <View style={styles.ContainerInput}>
          <View style={styles.ContainerInputForm}>
            <InputForm
              error={nameError}
              value={name}
              label="Nombre"
              onChangeText={handleName}
            />
          </View>
          <View style={styles.ContainerInputForm}>
            <InputForm
              error={secondNameError}
              value={secondName}
              label="Apellidos"
              onChangeText={handleSecondName}
            />
          </View>
        </View>
        <View style={styles.containerButtonAccept}>
          <ButtonForm
            title="actualizar nombre"
            onPress={Update}
            style={{
              text: styles.buttonText,
              container: styles.buttonContainer
            }}
          />
        </View>
      </View>
    </TouchableWithoutFeedback>
  )
}
const styles = StyleSheet.create({
  Container: {
    flex: 1,
    backgroundColor: 'white'
  },
  containerButtonAccept: {
    flex: 1,
    paddingTop: '5%',
    marginHorizontal: 30,
    justifyContent: 'flex-end',
    paddingBottom: 41
  },
  ContainerInput: {
    flex: 2,
    marginHorizontal: 30,
    marginTop: 128
  }
})

export default ChangeName
