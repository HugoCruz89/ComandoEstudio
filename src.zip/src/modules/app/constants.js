export const CATEGORIES = {
  NONSTOP: {
    label: 'nonstop',
    logo: require('media/images/categories/nonstop.png')
  },
  FAT_BURNING: {
    label: 'quema de grasa',
    logo: require('media/images/categories/fat-burning.png')
  },
  STRENGTH: {
    label: 'fuerza',
    logo: require('media/images/categories/strength.png')
  },
  MINDFULNESS: {
    label: 'mindfulness',
    logo: require('media/images/categories/mindfulness.png')
  },
  STRETCHING: {
    label: 'estiramiento',
    logo: require('media/images/categories/stretching.png')
  },
  YOGA: { label: 'yoga', logo: require('media/images/categories/yoga.png') },
  NUTRITION: {
    label: 'nutrición',
    logo: require('media/images/categories/nutrition.png')
  },
  FLOW: { label: 'flow', logo: require('media/images/categories/flow.png') },
  RUNNING: {
    label: 'running',
    logo: require('media/images/categories/running.png')
  }
}

export const CATEGORIES_ARRAY = Object.keys(CATEGORIES).map((key) => ({
  ...CATEGORIES[key],
  key
}))

export const LEVELS = {
  medium: 'Intermedio'
}

export const COLLECTIONS = {
  '10min': 189663,
  '20min': 167110,
  '30min': 157854,
  '360 lean & toned': 167109,
  '40min': 157852,
  '50min': 157853,
  Abs: 188156,
  Ada: 167579,
  Adela: 197298,
  'Añadidas recientemente': 157162,
  Andie: 157882,
  Avanzado: 157886,
  Bíceps: 188431,
  'Bodyweight 20 días': 188146,
  'Calorie burner: 7 días': 179756,
  Ceci: 157892,
  'Clases En Vivo': 220090,
  'Condición física': 163038,
  Daniela: 167660,
  'Día 1': 163039,
  'Día 2': 163041,
  'Día 3': 163050,
  'Día 4': 163043,
  'Día 5': 163053,
  'Día 6': 163034,
  'Día 7': 163046,
  'Empieza por aquí': 160763,
  'Equipo necesario': 158269,
  Espalda: 188150,
  'Featured Category': 225558,
  'Fer Ruelas': 186974,
  Flows: 185588,
  'Fuerza y Masa Muscular': 160381,
  'Full Body': 188157,
  Gaby: 167662,
  Glúteos: 188153,
  'Grupos Musculares': 188149,
  Hombros: 188154,
  'In Da House': 215521,
  Intermedio: 157885,
  Isa: 167659,
  Jero: 164697,
  JonJon: 157893,
  Jorge: 186972,
  Ligas: 158581,
  Mancuernas: 158580,
  'Mancuernas y Ligas': 158584,
  Mariano: 159194,
  'Más fuerte en 7': 179755,
  Mindfulness: 160387,
  Natalia: 163446,
  'Nonstop 20': 177357,
  Nutrición: 160389,
  'Para empezar...': 160764,
  Pau: 159196,
  Pecho: 188151,
  Pedro: 167569,
  Pico: 157891,
  Piernas: 188155,
  'Por Dificultad': 157879,
  'Por Duración': 157855,
  'Por Instructor': 157878,
  Principiante: 157884,
  'Programas de Entrenamiento': 160916,
  'Quema calórica': 163027,
  'Quema de Grasa': 160377,
  Renata: 159195,
  ReStart: 225632,
  Ricardo: 186971,
  Running: 160382,
  'Sculpt & Shred': 197368,
  'Sin Equipo': 158586,
  Stretch: 160384,
  'Tipos de Clases': 160715,
  'Todas las Clases': 157055,
  'Tonifica en 7 días': 179753,
  Tonificar: 163047,
  Tríceps: 188152,
  'Últimas agregadas': 158579,
  Yadira: 157894,
  Yoga: 160390
}
