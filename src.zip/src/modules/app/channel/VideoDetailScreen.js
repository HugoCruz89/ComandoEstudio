import React, { useLayoutEffect, useRef } from 'react'
import { string, number, oneOfType } from 'prop-types'
import {
  SafeAreaView,
  StyleSheet,
  Image,
  View,
  TouchableOpacity,
  Share
} from 'react-native'
import { Text, Button } from 'components'
import Icon from 'react-native-vector-icons/AntDesign'
import { SvgShareIcon } from '../../../media/images/svg/ObjetiveIcons'
function VideoDetailScreen(props) {
  const {
    route: { params },
    navigation
  } = props

  useLayoutEffect(() => {
    const onShare = async () => {
      try {
        const result = await Share.share({
          url: params._links.video_page.href
        })
        if (result.action === Share.sharedAction) {
          if (result.activityType) {
            // shared with activity type of result.activityType
          } else {
            // shared
          }
        } else if (result.action === Share.dismissedAction) {
          // dismissed
        }
      } catch (error) {
        alert(error.message)
      }
    }
    navigation.setOptions({
      title: params.headerTitle,
      headerRight: () => (
        <TouchableOpacity style={{ marginRight: 28 }} onPress={onShare}>
          <SvgShareIcon />
        </TouchableOpacity>
      )
    })
  }, [navigation, params])

  function getDescriptionDetails() {
    const listRegex = /-\s((?:[A-zÀ-ú]+\s?)+):\s+((?:[A-zÀ-ú]+\s?)+)/gm

    let res
    let matches = []
    while ((res = listRegex.exec(params.description)) !== null) {
      if (res.index === listRegex.lastIndex) {
        listRegex.lastIndex++
      }
      const [full, label, value] = res
      full && matches.push({ label, value })
    }
    return matches
  }

  const imageSource = useRef(
    typeof params.image === 'number' ? params.image : { uri: params.image }
  )

  const details = useRef(getDescriptionDetails())

  const goToVideoScreen = () => {
    navigation.push('video-player', { id: params.id, track: params.track })
  }
  return (
    <SafeAreaView style={styles.container}>
      <Image style={styles['cover-image']} source={imageSource.current} />
      <Text style={[styles.separator, styles.title]} type="title">
        {params.title}
      </Text>
      <Text style={[styles.separator, styles.titleBody]} type="body">
        {params.duration?.formatted ? `${params.duration.formatted} MIN` : ''}
        {params.short_description && (
          <>
            <Text style={styles.dotStyle}>{'\u2022'}</Text>
            {' !' + params.short_description + '¡'}
          </>
        )}
      </Text>
      <View style={[styles.separator, styles['content-container']]}>
        {Array.isArray(details.current) ? (
          details.current.map((item, index) => (
            <Text key={index} style={styles.detail}>
              <Text>- {item.label}: </Text>
              {item.value}
            </Text>
          ))
        ) : (
          <Text style={styles.text} fontSize={14} color="#43485C">
            {params.description}
          </Text>
        )}
      </View>
      <View style={[styles.separator, styles['button-container']]}>
        <Button theme="danger" onPress={goToVideoScreen}>
          <>
            <Icon style={styles.icon} name="caretright" size={20} />
            <Text style={styles.buttonText} type="body">
              Comenzar clase
            </Text>
          </>
        </Button>
      </View>
    </SafeAreaView>
  )
}

VideoDetailScreen.propTypes = {
  title: string,
  image: oneOfType([number, string]),
  equipment: string,
  level: string,
  type: string,
  muscularFocus: string,
  description: string,
  short_description: string,
  video: string
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  'content-container': { flex: 1, width: '100%' },
  separator: {
    paddingHorizontal: 30
  },
  'cover-image': {
    height: 175,
    width: '100%'
  },
  dotStyle: {
    fontSize: 10
  },
  title: {
    fontWeight: '700',
    textAlign: 'left',
    paddingVertical: 15,
    letterSpacing: 0.2,
    textTransform: 'uppercase',
    color: '#000000',
    fontSize: 16
  },
  titleBody: {
    fontWeight: '400',
    textAlign: 'left',
    paddingVertical: 15,
    letterSpacing: 0.2,
    textTransform: 'uppercase',
    color: '#000000',
    fontSize: 12,
    lineHeight: 7
  },
  detail: {},
  'button-container': {
    width: '100%',
    paddingBottom: 10
  },
  buttonText: {
    color: 'white',
    textTransform: 'uppercase'
  },
  icon: {
    color: 'white',
    marginRight: 10
  },
  text: {
    marginTop: 30
  }
})
export default VideoDetailScreen
