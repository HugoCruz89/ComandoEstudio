import React, { useLayoutEffect } from 'react'
import {
  SafeAreaView,
  StyleSheet,
  Image,
  FlatList,
  View,
  Share,
  TouchableOpacity
} from 'react-native'
import { SvgShareIcon } from 'media/images/svg/ObjetiveIcons'
import useRequest from 'use-request'

import ChannelDescription from 'modules/app/channel/ChannelDescription'
import { LandscapeElement } from 'modules/app/explore/ChannelElements'

import { badgeResolver } from 'modules/app/explore/utils'
import useEvent from '../../../screens/useEvent'

function ChannelScreen(props) {
  const {
    route: { params },
    navigation
  } = props

  useLayoutEffect(() => {
    const onShare = async () => {
      try {
        const result = await Share.share({
          url: 'url'
        })
        if (result.action === Share.sharedAction) {
          if (result.activityType) {
            // shared with activity type of result.activityType
          } else {
            // shared
          }
        } else if (result.action === Share.dismissedAction) {
          // dismissed
        }
      } catch (error) {
        alert(error.message)
      }
    }
    navigation.setOptions({
      title: params.headerTitle,
      headerRight: () => (
        <TouchableOpacity style={{ marginRight: 28 }} onPress={onShare}>
          <SvgShareIcon />
        </TouchableOpacity>
      )
    })
  }, [navigation, params])

  const { data } = useRequest({
    url: `/vimeo/explore/${props.route.params.id}`,
    params: { page: 1, items: 100 }
  })
  const { scheduleNotf, removeScheduledNotf } = useEvent()

  function renderVideoElement({ item }) {
    const badgeType = badgeResolver(item)
    if (!item) null
    const image = item.thumbnail.large
    return (
      <View style={[styles.separator, styles['element-separator']]}>
        <LandscapeElement
          style={styles['video-element']}
          background={image}
          title={item.title}
          key={item.id}
          duration={item.duration.seconds}
          description={item.description}
          onPress={() =>
            props.navigation.push('video-detail', {
              ...item,
              image,
              headerTitle: props.route.params.name
            })
          }
          data={item}
          scheduleNotf={scheduleNotf}
          removeScheduledNotf={removeScheduledNotf}
          badgeType={badgeType}
          loading={!data}
        />
      </View>
    )
  }

  const { description, name, thumbnail } = props.route.params
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        ListHeaderComponent={
          <>
            <Image
              style={styles['photo-cover']}
              source={{ uri: thumbnail.medium }}
            />
            <ChannelDescription
              style={[styles.separator, styles['channel-description']]}
              title={name}
              description={description}
              count={data ? data.total : ''}
              data={data}
            />
          </>
        }
        style={styles['list-container']}
        renderItem={renderVideoElement}
        data={data ? data.videos : SKELETON}
        keyExtractor={(item) => item.id}
      />
    </SafeAreaView>
  )
}

ChannelScreen.propTypes = {}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', backgroundColor: '#FFFFFF' },
  'list-container': { width: '100%' },
  'photo-cover': {
    height: 175,
    width: '100%'
  },
  'video-element': {
    width: '100%'
  },
  'element-separator': {
    marginBottom: 10
  },
  separator: {
    paddingLeft: 30,
    paddingRight: 30
  }
})

const SKELETON = [
  { thumbnail: {}, duration: {} },
  { thumbnail: {}, duration: {} },
  { thumbnail: {}, duration: {} }
]

export default ChannelScreen
