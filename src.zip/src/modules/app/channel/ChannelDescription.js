import React, { useState } from 'react'
import { object, string, oneOfType, array } from 'prop-types'
import { View, StyleSheet, TouchableHighlight } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import { Text, Collapsible } from 'components'

function ChannelDescription(props) {
  const [isOpen, setIsOpen] = useState(false)

  function handleShowMore() {
    setIsOpen(!isOpen)
  }

  function onTextLayout(e) {
    //
    console.log({ e: e.nativeEvent })
  }

  const collapseValue = isOpen ? 330 : 100

  const colapseLabel = isOpen ? 'Mostrar Menos' : 'Mostrar Más'

  return (
    <View style={props.style}>
      <Text type="title" textAlign="left" style={styles.title}>
        {props.title}
      </Text>
      <Text type="subtitle" textAlign="left" style={styles.subtitle}>
        {props.count} VIDEOS
      </Text>
      {props.description ? (
        <>
          <Collapsible
            style={styles['content-container']}
            value={collapseValue}>
            <Text
              style={styles.descriptionText}
              color="#8c8c8c"
              onTextLayout={onTextLayout}
              numberOfLines={isOpen ? undefined : 5}>
              {props.description}
            </Text>
          </Collapsible>
          <LinearGradient
            colors={['rgba(255,255,255,0)', '#FFFFFF']}
            start={{ x: 0, y: 0.03 }}
            end={{ x: 0, y: 1 }}
            style={styles['show-button-container']}>
            <TouchableHighlight style={styles.button} onPress={handleShowMore}>
              <Text style={styles.buttonText}>{colapseLabel}</Text>
            </TouchableHighlight>
          </LinearGradient>
        </>
      ) : null}
    </View>
  )
}

ChannelDescription.propTypes = {
  style: oneOfType([array, object]),
  title: string,
  description: string
}

const styles = StyleSheet.create({
  'content-container': {
    width: '100%',
    flexDirection: 'row'
  },
  title: {
    marginTop: 21,
    overflow: 'hidden',
    fontWeight: '700',
    color: '#000000',
    fontSize: 16
  },
  subtitle: {
    marginTop: 6,
    marginBottom: 31,
    fontWeight: 'normal',
    color: '#000000'
  },
  'show-button-container': {
    //    paddingVertical: 20
  },
  button: {
    paddingVertical: 5
  },
  buttonText: {
    color: '#FC3838'
  },
  descriptionText: {
    flexWrap: 'wrap'
  }
})

export default ChannelDescription
