import React, { useLayoutEffect } from 'react'
import { SafeAreaView, StyleSheet, FlatList, View } from 'react-native'

import useRequest from 'use-request'
import { getCollectionContent } from 'ducks/app'
import { LandscapeElement } from 'modules/app/explore/ChannelElements'

function CollectionListScreen(props) {
  const {
    route: { params },
    navigation
  } = props

  useLayoutEffect(() => {
    navigation.setOptions({
      title: params.headerTitle
    })
  }, [navigation, params])

  const { data } = useRequest(
    null,
    getCollectionContent(props.route.params.id, {
      pages: 1,
      items: 100
    })
  )

  function renderCollectionElement({ item }) {
    if (!item) null
    const image = item.thumbnail.large
    const onPress = () =>
      props.navigation.push('video-detail', {
        ...item,
        image,
        headerTitle: props.route.params.headerTitle
      })

    return (
      <View style={[styles.separator, styles['element-wrapper']]}>
        <LandscapeElement
          style={styles['video-element']}
          background={image}
          onPress={onPress}
          loading={!data}
        />
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        style={styles.list}
        renderItem={renderCollectionElement}
        data={data ? data.videos : SKELETON}
        keyExtractor={(item) => item.id}
      />
    </SafeAreaView>
  )
}

CollectionListScreen.propTypes = {}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    backgroundColor: '#FFFFFF'
  },
  list: { width: '100%' },
  'photo-cover': {
    height: 175,
    width: '100%'
  },
  'video-element': {
    width: '100%',
    height: 150
  },
  'element-wrapper': {
    marginBottom: 10,
    width: '100%'
  },
  separator: {
    paddingLeft: 30,
    paddingRight: 30
  }
})

const SKELETON = [
  { id: 1, thumbnail: {}, duration: {} },
  { id: 2, thumbnail: {}, duration: {} },
  { id: 3, thumbnail: {}, duration: {} }
]

export default CollectionListScreen
