import React from 'react'
import { StyleSheet, SafeAreaView, ScrollView } from 'react-native'
import { Text } from 'components'

import { LiveContent, FeaturedContent, GeneralContent } from './ChannelContents'

function ExploreScreen(props) {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.container}>
        <Text style={styles.header} type="header" textAlign="center">
          EXPLORAR
        </Text>
        <FeaturedContent />
        <LiveContent />
        <GeneralContent />
      </ScrollView>
    </SafeAreaView>
  )
}

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  header: {
    marginTop: 20,
    fontWeight: '800',
    fontSize: 20,
    marginBottom: 19
  },
  'content-separator': {
    marginTop: 50
  },
  'horizontal-separator': {
    marginLeft: 30
  },
  'carousel-element': {
    marginRight: 10
  },
  'categories-container': {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    paddingHorizontal: 30
  },
  'category-element': {
    margin: 5
  },
  'trainers-container': {
    flexDirection: 'row'
  }
})

ExploreScreen.propTypes = {}

export default ExploreScreen
