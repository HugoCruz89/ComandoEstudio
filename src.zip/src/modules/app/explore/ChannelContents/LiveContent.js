import React from 'react'
import Carousel from 'react-native-snap-carousel'
import useRequest from 'use-request'
import { windowWidth } from 'src/utils'
import { getCollectionContent } from 'ducks/app'
import { COLLECTIONS } from 'modules/app/constants'
import ContentSection from 'modules/app/explore/ContentSection'
import {
  LandscapeElement,
  LANDSCAPE_ELEMENT_WIDTH
} from 'modules/app/explore/ChannelElements'
import { styles } from 'modules/app/explore/ExploreScreen'
import { badgeResolver } from 'modules/app/explore/utils'

function LiveContent(props) {
  const { data } = useRequest(
    null,
    getCollectionContent(COLLECTIONS['Clases En Vivo'], { page: 1, items: 5 })
  )

  if (!data || !data.videos.length) return null

  function renderElement({ item, index }) {
    const badgeType = badgeResolver(item)

    return (
      <LandscapeElement
        index={index}
        loading={!data}
        title={item.name}
        type={badgeType}
        background={item.thumbnail.medium}
      />
    )
  }

  return (
    <ContentSection
      title="Próximas clases en vivo"
      style={styles['content-separator']}>
      <Carousel
        data={data.videos}
        containerCustomStyle={styles['horizontal-separator']}
        renderItem={renderElement}
        sliderWidth={windowWidth}
        itemWidth={LANDSCAPE_ELEMENT_WIDTH}
        activeSlideAlignment="start"
        useScrollView
      />
    </ContentSection>
  )
}

export default LiveContent
