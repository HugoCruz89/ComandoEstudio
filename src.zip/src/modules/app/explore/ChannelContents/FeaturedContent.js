import React, { useRef, useState } from 'react'
import { View, StyleSheet } from 'react-native'
import Carousel, { Pagination } from 'react-native-snap-carousel'
import useRequest from 'use-request'
import { windowWidth } from 'src/utils'
import { getCollectionContent } from 'ducks/app'
import { COLLECTIONS } from 'modules/app/constants'
import FeaturedElement, {
  ELEMENT_WIDTH
} from 'modules/app/explore/ChannelElements/FeaturedElement'
import { badgeResolver } from 'modules/app/explore/utils'
import { useNavigation } from '@react-navigation/native'

function FeaturedContent(props) {
  const navigation = useNavigation()
  const { data } = useRequest(
    null,
    getCollectionContent(COLLECTIONS['Últimas agregadas'], {
      page: 1,
      items: 5
    })
  )

  const [activeSlide, setActiveSlide] = useState(0)

  const _carouselRef = useRef(null)

  if (data && !data.videos.length) return null

  function renderElement({ item, index }) {
    const badgeType = badgeResolver(item)
    const image = item.thumbnail.large

    return (
      <FeaturedElement
        index={index}
        loading={!data}
        background={image}
        duration={item.duration.seconds}
        shortDescription={item.short_description}
        title={item.title}
        badgeType={badgeType}
        onPress={() =>
          navigation.push('video-detail', {
            ...item,
            image,
            headerTitle: item.name
          })
        }
        data={item}
      />
    )
  }

  return (
    <View style={styles.container}>
      <Carousel
        ref={_carouselRef}
        data={data ? data.videos : SKELETON}
        renderItem={renderElement}
        sliderWidth={windowWidth}
        itemWidth={ELEMENT_WIDTH}
        activeSlideAlignment="start"
        useScrollView
        onSnapToItem={setActiveSlide}
      />
      {data && (
        <Pagination
          activeDotIndex={activeSlide}
          containerStyle={styles['paginator-container']}
          dotContainerStyle={styles['dot-container']}
          dotColor="#FFFFFF"
          inactiveDotColor="#FFFFFF"
          inactiveDotScale={1}
          carouselRef={_carouselRef}
          dotsLength={data.videos.length}
          tappableDots
        />
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center'
  },

  'dot-container': {
    bottom: -10,
    width: 1
  },
  'paginator-container': {
    position: 'absolute',
    bottom: 0
  }
})

const SKELETON = [
  {
    thumbnail: { medium: '' },
    duration: { seconds: 0 }
  }
]

export default FeaturedContent
