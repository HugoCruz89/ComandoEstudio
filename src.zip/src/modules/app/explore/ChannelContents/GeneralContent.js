import React from 'react'
import Carousel from 'react-native-snap-carousel'
import { useNavigation } from '@react-navigation/native'
import { windowWidth } from 'src/utils'
import { COLLECTIONS } from 'modules/app/constants'
import useRequest from 'use-request'
import { getExploreContent } from 'ducks/app'

import {
  LandscapeElement,
  LANDSCAPE_ELEMENT_WIDTH,
  PortraitElement,
  PORTRAIT_ELEMENT_WIDTH
} from '../ChannelElements'
import ContentSection from '../ContentSection'
import { styles } from '../ExploreScreen'

const ELEMENT_TYPES = {
  LANDSCAPE: 'LANDSCAPE',
  PORTRAIT: 'PORTRAIT'
}

const ELEMENTS_WIDTH = {
  [ELEMENT_TYPES.LANDSCAPE]: LANDSCAPE_ELEMENT_WIDTH,
  [ELEMENT_TYPES.PORTRAIT]: PORTRAIT_ELEMENT_WIDTH
}

function GeneralContent(props) {
  const { data } = useRequest(null, getExploreContent())
  const navigation = useNavigation()

  const renderElement = (view, headerTitle) => ({ item, index }) => {
    const goToChannel = () =>
      navigation.push('channel', { ...item, headerTitle })

    switch (view) {
      case ELEMENT_TYPES.LANDSCAPE:
        return (
          <LandscapeElement
            index={index}
            loading={!data}
            onPress={goToChannel}
            background={item.thumbnail.medium}
          />
        )

      case ELEMENT_TYPES.PORTRAIT:
        return (
          <PortraitElement
            index={index}
            loading={!data}
            onPress={goToChannel}
            background={item.additional_images.aspect_ratio_1_1.medium}
          />
        )
    }
  }

  const viewResolver = (item) =>
    COLLECTIONS[item.name] === COLLECTIONS['Tipos de Clases']
      ? ELEMENT_TYPES.PORTRAIT
      : ELEMENT_TYPES.LANDSCAPE

  const renderContent = (item) => {
    if (item.sub === null) return null

    const view = viewResolver(item)

    const goToSeeMore = (headerTitle) => () => {
      navigation.push('collection-list', { id: item.id, view, headerTitle })
    }

    return (
      <ContentSection
        key={item.id}
        title={item.name}
        loading={!data}
        style={styles['content-separator']}
        goToSeeMore={item.sub.length > 5 ? goToSeeMore(item.name) : undefined}>
        <Carousel
          data={item.sub}
          containerCustomStyle={styles['horizontal-separator']}
          renderItem={renderElement(view, item.name)}
          sliderWidth={windowWidth}
          itemWidth={ELEMENTS_WIDTH[view]}
          activeSlideAlignment="start"
          useScrollView
          key={item.id}
        />
      </ContentSection>
    )
  }

  return data ? data.map(renderContent) : SKELETON.map(renderContent)
}

const SKELETON = [
  {
    name: 'Programas de Entrenamiento',
    id: COLLECTIONS['Programas de Entrenamiento'],
    sub: [{ thumbnail: { medium: '' } }, { thumbnail: { medium: '' } }]
  },
  {
    name: 'Tipos de Clases',
    id: COLLECTIONS['Tipos de Clases'],
    sub: [
      { additional_images: { aspect_ratio_1_1: { medium: '' } } },
      { additional_images: { aspect_ratio_1_1: { medium: '' } } }
    ]
  },
  {
    name: 'Grupos Musculares',
    id: COLLECTIONS['Grupos Musculares'],
    sub: [{ thumbnail: { medium: '' } }, { thumbnail: { medium: '' } }]
  }
]

export default GeneralContent
