import React from 'react'
import { useSelector } from 'react-redux'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import Icon from 'react-native-vector-icons/AntDesign'
import Svg, { Path } from 'react-native-svg'
import { Text } from 'components'
import { useNavigation } from '@react-navigation/native'
import { scheduleLiveEvent } from './utils'

export function LiveLabel(props) {
  return (
    <View style={[styles['live-label__container'], props.style]}>
      <View style={styles['live-label__icon']} />
      <Text
        type="title"
        textAlign="left"
        color="#FC3838"
        fontSize={14}
        lineHeight={18}
        fontWeight="700">
        En vivo
      </Text>
    </View>
  )
}

export function ScheduleButton(props) {
  return (
    <View
      style={[
        styles['button-base'],
        styles['schedule-button__container'](props.scheduled),
        props.style
      ]}>
      <Svg
        style={styles['button-base-icon']}
        width={10}
        height={10}
        viewBox="0 0 10 10"
        fill="none">
        <Path
          d="M10.4211 5.78947H0.578947C0.260526 5.78947 0 6.05 0 6.36842V9.8421C0 10.1605 0.260526 10.4211 0.578947 10.4211H10.4211C10.7395 10.4211 11 10.1605 11 9.8421V6.36842C11 6.05 10.7395 5.78947 10.4211 5.78947ZM10.4211 0H0.578947C0.260526 0 0 0.260526 0 0.578947V4.05263C0 4.37105 0.260526 4.63158 0.578947 4.63158H10.4211C10.7395 4.63158 11 4.37105 11 4.05263V0.578947C11 0.260526 10.7395 0 10.4211 0Z"
          fill="white"
        />
      </Svg>
      <Text
        type="title"
        fontSize={14}
        lineHeight={16}
        color="#FFFFFF"
        fontWeight="700">
        {props.scheduled ? 'Agendado' : 'Agendar'}
      </Text>
    </View>
  )
}

export function WatchButton(props) {
  return (
    <View
      style={[
        styles['button-base'],
        styles['watch-button__container'],
        props.style
      ]}>
      <Icon
        style={styles['button-base-icon']}
        color="#FFFFFF"
        name="caretright"
        size={14}
      />
      <Text
        type="title"
        color="#FFFFFF"
        fontSize={14}
        lineHeight={18}
        fontWeight="700">
        Ver ahora
      </Text>
    </View>
  )
}

function BadgeResolver(props) {
  const navigation = useNavigation()
  const events = useSelector(({ auth: { events: _ev } }) => _ev)

  let badge, badgeAction, isScheduled
  switch (props.type) {
    case 'live-label':
      badge = <LiveLabel style={props.style} />
      badgeAction = () => {
        props.data &&
          navigation.push('video-player', {
            id: props.data.id
          })
      }
      break
    case 'schedule-button':
      isScheduled = !!events[props.data.id]
      badge = <ScheduleButton scheduled={isScheduled} style={props.style} />
      badgeAction = isScheduled
        ? () => props.removeScheduledNotf(props.data.id)
        : scheduleLiveEvent(props.data, props.scheduleNotf)
      break
    case 'watch-button':
      badge = <WatchButton style={props.style} />
      badgeAction = () => {
        props.data &&
          navigation.push('video-player', {
            id: props.data.id
          })
      }
      break
    default:
      badge = null
      break
  }

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={props.onPress || badgeAction}>
      {badge}
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  container: {
    zIndex: 2
  },

  ['live-label__container']: {
    width: 93,
    marginTop: 3,
    flexDirection: 'row',
    alignItems: 'center'
  },
  ['live-label__icon']: {
    width: 6,
    height: 6,
    marginRight: 6,
    borderRadius: 3,
    backgroundColor: '#FC3838'
  },
  ['button-base']: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: 146,
    height: 27
  },
  ['button-base-icon']: {
    marginRight: 5
  },
  ['schedule-button__container'](scheduled) {
    return {
      borderColor: '#FFFFFF',
      borderWidth: 1,
      backgroundColor: scheduled ? 'gray' : 'black'
    }
  },
  ['watch-button__container']: {
    backgroundColor: '#FC3838'
  }
})

export default BadgeResolver
