import React from 'react'
import { func, string, any, number, bool } from 'prop-types'
import {
  StyleSheet,
  ImageBackground,
  TouchableOpacity,
  View
} from 'react-native'
import SkeletonContent from 'react-native-skeleton-content-nonexpo'
import { Text } from 'components'
import BadgeResolver from '../BadgeResolver'
import { parseTitle } from '../utils'
import LinearGradient from 'react-native-linear-gradient'
const skeletonLayout = [{ key: 'title', width: '100%', height: '100%' }]

function LandscapeElement(props) {
  const source = !props.loading
    ? typeof props.background === 'string'
      ? { uri: props.background }
      : props.background
    : undefined
  const parsedTitle = parseTitle(props.title)

  return (
    <TouchableOpacity
      style={[styles.container, props.style]}
      disabled={props.loading}
      onPress={props.onPress}>
      <ImageBackground
        style={styles['image-container']}
        imageStyle={styles.image}
        source={source}>
        <SkeletonContent
          isLoading={props.loading || false}
          containerStyle={styles['skeleton-container']}
          layout={skeletonLayout}
        />
        <LinearGradient
          colors={['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 9)']}
          style={styles.linearGradient}>
          <View style={{ position: 'absolute', marginTop: '10%', zIndex: 3 }}>
            {props.loading ? null : (
              <>
                {parsedTitle.activity ? (
                  <Text
                    textAlign="left"
                    fontWeight="400"
                    fontSize={10}
                    numberOfLines={1}
                    textTransform="uppercase"
                    style={styles['horizontal-padding']}
                    color="#FFFFFF">
                    {parsedTitle.activity}
                  </Text>
                ) : null}
                <Text
                  textAlign="left"
                  fontWeight="700"
                  fontSize={16}
                  numberOfLines={1}
                  color="#FFFFFF"
                  style={[
                    styles.title,
                    styles['horizontal-padding'],
                    props.badgeType ? null : styles['bottom-margin']
                  ]}
                  type="title">
                  {parsedTitle.description || props.title}
                </Text>
                {/*  */}
                {props.badgeType ? (
                  <BadgeResolver
                    style={[
                      styles['horizontal-padding'],
                      styles['bottom-margin']
                    ]}
                    type={props.badgeType}
                    data={props.data}
                    scheduleNotf={props.scheduleNotf}
                    removeScheduledNotf={props.removeScheduledNotf}
                  />
                ) : null}
              </>
            )}
          </View>
        </LinearGradient>
      </ImageBackground>
    </TouchableOpacity>
  )
}

LandscapeElement.propTypes = {
  title: string,
  loading: bool,
  background: any,
  duration: number,
  level: string,
  onPress: func,
  badgeType: string,
  data: any
}

const ELEMENT_WIDTH = 232

const styles = StyleSheet.create({
  container: {
    borderRadius: 15,
    height: 129,
    width: ELEMENT_WIDTH,
    backgroundColor: 'gray'
  },
  linearGradient: {
    flex: 1,
    borderRadius: 5,
    position: 'absolute',
    width: '100%',
    height: '80%',
    zIndex: 0
  },
  'image-container': {
    flex: 1,
    justifyContent: 'flex-end'
  },
  'skeleton-container': {
    justifyContent: 'flex-end'
  },
  image: {
    borderRadius: 5
  },
  title: {
    marginBottom: 2
  },
  'horizontal-padding': {
    marginTop: 16,
    marginLeft: 13
  },
  'bottom-margin': {
    marginBottom: 11
  }
})

export default LandscapeElement

export { ELEMENT_WIDTH }
