import React from 'react'
import { func, string, any, bool, number } from 'prop-types'
import { StyleSheet, ImageBackground, TouchableOpacity } from 'react-native'
import SkeletonContent from 'react-native-skeleton-content-nonexpo'
import { windowWidth } from 'src/utils'
import { Text } from 'components'
import BadgeResolver from '../BadgeResolver'
import { parseTitle, parseDuration } from '../utils'

const skeletonLayout = [{ key: 'title', width: '100%', height: '100%' }]

function FeaturedElement(props) {
  const source = !props.loading ? { uri: props.background } : undefined
  const parsed = !props.loading ? parseTitle(props.title) : ''
  const duration = !props.loading ? parseDuration(props.duration) : ''

  return (
    <TouchableOpacity
      style={[styles.container, props.style]}
      disabled={props.loading}
      onPress={props.onPress}>
      <ImageBackground
        style={styles['image-container']}
        resizeMode="contain"
        source={source}>
        <SkeletonContent
          isLoading={props.loading || false}
          containerStyle={styles['skeleton-container']}
          layout={skeletonLayout}
        />
        {parsed.activity ? (
          <Text
            textAlign="left"
            fontWeight="400"
            fontSize={10}
            numberOfLines={1}
            textTransform="uppercase"
            style={styles['horizontal-padding']}
            color="#FFFFFF">
            {parsed.activity}
          </Text>
        ) : null}
        <Text
          textAlign="left"
          fontWeight="700"
          fontSize={16}
          numberOfLines={1}
          color="#FFFFFF"
          style={[styles.title, styles['horizontal-padding']]}
          type="title">
          {parsed.description || props.title}
        </Text>
        <Text
          textAlign="left"
          fontWeight="400"
          fontSize={10}
          numberOfLines={1}
          textTransform="uppercase"
          style={[
            styles['horizontal-padding'],
            props.badgeType ? null : styles['bottom-margin']
          ]}
          color="#FFFFFF">
          {duration ? `${duration} MIN  •  ` : ''}
          {props.shortDescription}
        </Text>
        {!props.loading && props.badgeType && props.data ? (
          <BadgeResolver
            style={[styles['horizontal-padding'], styles.badge]}
            type={props.badgeType}
            data={props.data}
          />
        ) : null}
      </ImageBackground>
    </TouchableOpacity>
  )
}

FeaturedElement.propTypes = {
  title: string,
  data: any,
  loading: bool,
  duration: number,
  background: any,
  onPress: func,
  shortDescription: string,
  badgeType: string
}

const ELEMENT_WIDTH = windowWidth

const styles = StyleSheet.create({
  container: {
    width: ELEMENT_WIDTH,
    height: 233
  },
  'image-container': {
    flex: 1,
    justifyContent: 'flex-end'
  },
  'skeleton-container': {
    justifyContent: 'flex-end'
  },
  title: {
    marginBottom: 18,
    maxWidth: '90%'
  },
  'horizontal-padding': {
    marginLeft: 30
  },
  badge: {
    marginTop: 5,
    marginBottom: 35
  },
  'bottom-margin': {
    marginBottom: 11
  }
})

export default FeaturedElement

export { ELEMENT_WIDTH }
