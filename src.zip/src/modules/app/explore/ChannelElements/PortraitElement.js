import React from 'react'
import { func, string, any, bool } from 'prop-types'
import { StyleSheet, ImageBackground, TouchableOpacity } from 'react-native'
import SkeletonContent from 'react-native-skeleton-content-nonexpo'

const skeletonLayout = [{ key: 'title', width: '100%', height: '100%' }]

function PortraitElement(props) {
  const source = !props.loading ? { uri: props.background } : undefined
  return (
    <TouchableOpacity
      style={[styles.container, props.style]}
      disabled={props.loading}
      onPress={props.onPress}>
      <ImageBackground
        style={styles['image-container']}
        imageStyle={styles.image}
        source={source}>
        <SkeletonContent
          isLoading={props.loading || false}
          containerStyle={styles['skeleton-container']}
          layout={skeletonLayout}
        />
      </ImageBackground>
    </TouchableOpacity>
  )
}

PortraitElement.propTypes = {
  title: string,
  loading: bool,
  background: any,
  onPress: func
}

const ELEMENT_WIDTH = 196

const styles = StyleSheet.create({
  container: {
    borderRadius: 30,
    width: ELEMENT_WIDTH,
    backgroundColor: 'gray',
    height: 295
  },
  'image-container': {
    flex: 1
  },
  'gradient-container': {
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
    // paddingHorizontal: 10,
    paddingBottom: 10
  },
  'skeleton-container': {
    flex: 1,
    justifyContent: 'center'
  },
  image: {
    borderRadius: 5
  }
})

export default PortraitElement

export { ELEMENT_WIDTH }
