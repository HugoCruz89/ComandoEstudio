import React from 'react'
import { any, string, func, object, bool } from 'prop-types'
import { StyleSheet, TouchableOpacity, ImageBackground } from 'react-native'
import SkeletonContent from 'react-native-skeleton-content-nonexpo'
import { Text } from 'components'

const skeletonLayout = [
  { key: 'title', width: '100%', height: '100%', borderRadius: 45 }
]

function AvatarElement(props) {
  return (
    <TouchableOpacity
      style={[styles.container, props.style]}
      onPress={props.onPress}>
      <ImageBackground
        source={!props.loading ? props.avatar : undefined}
        style={styles.avatar}>
        <SkeletonContent
          isLoading={props.loading || false}
          layout={skeletonLayout}
        />
      </ImageBackground>
      <Text type="title" fontSize={11} textAlign="center">
        {props.name}
      </Text>
    </TouchableOpacity>
  )
}

const ELEMENT_WIDTH = 90

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    width: ELEMENT_WIDTH
  },
  avatar: {
    backgroundColor: '#7C7E9A',
    height: ELEMENT_WIDTH,
    width: ELEMENT_WIDTH,
    marginBottom: 10,
    borderRadius: 45
  }
})

AvatarElement.propTypes = {
  avatar: any,
  name: string,
  loading: bool,
  onPress: func,
  style: object
}

export default AvatarElement

export { ELEMENT_WIDTH }
