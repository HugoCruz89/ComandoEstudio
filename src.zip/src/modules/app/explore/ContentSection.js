import React from 'react'
import { object, any, string, func, bool } from 'prop-types'
import { View, StyleSheet } from 'react-native'
import SkeletonContent from 'react-native-skeleton-content-nonexpo'
import { Text, Button } from 'components'

const skeletonLayout = [
  {
    key: 'title',
    height: '100%',
    width: '100%',
    alignSelf: 'flex-start'
  }
]

function ContentSection(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles['header-container']}>
        <View>
          <SkeletonContent
            containerStyle={styles['skeleton-container']}
            isLoading={props.loading || false}
            layout={skeletonLayout}
          />
          <Text
            style={styles.header}
            textAlign="left"
            lineHeight={19}
            color="#2A2B37"
            numberOfLines={1}
            type="title">
            {props.title}
          </Text>
        </View>
        {props.goToSeeMore && (
          <Button
            theme="tertiary"
            style={{
              container: styles['action-button'],
              text: { textAlign: 'right', paddingRight: 30, color: '#FC3838' }
            }}
            title="Ver Todo"
            onPress={props.goToSeeMore}
          />
        )}
      </View>
      {props.children}
    </View>
  )
}

ContentSection.propTypes = {
  style: object,
  title: string,
  goToSeeMore: func,
  loading: bool,
  children: any
}

const styles = StyleSheet.create({
  container: {
    width: '100%'
  },
  'header-container': {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 18,
    marginBottom: 9
  },
  header: {
    marginLeft: 30,
    fontWeight: '700',
    maxWidth: 280
  },
  'skeleton-container': {
    position: 'absolute',
    left: 0,
    width: '100%',
    height: 16,
    paddingLeft: 30,
    zIndex: 2
  },
  'action-button': {
    flex: 1,
    minWidth: 70
  }
})

export default ContentSection
