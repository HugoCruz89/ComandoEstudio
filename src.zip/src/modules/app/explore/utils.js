import { format } from 'date-fns'

export function parseTitle(title) {
  const listRegex = /^([A-zÀ-ú\s0-9]+)\s?\/\s?([A-zÀ-ú\s0-9]+:\s)(.+)/m
  const dateRegex = /^([A-zÀ-ú\s0-9:/]+)\s?.\|\s([A-zÀ-ú\s0-9:/]+)/m
  let res
  if ((res = listRegex.exec(title)) !== null) {
    const [full, program, activity, description] = res
    return { full, program, activity, description }
  }

  if ((res = dateRegex.exec(title)) !== null) {
    const [full, date, activity] = res
    return { full, date, activity }
  }

  return {}
}

export function parseDuration(duration) {
  return Math.floor(duration / 60)
}

export function badgeResolver(data) {
  //  Video Normal
  //             "status": "complete",
  //             "type": "video",
  //             "updated_at": "2020-08-04T05:12:26Z",
  //             "scheduled_at": null
  //             "live_video": false,
  //             "live_status": "pending"
  //             "item_id": 9822740,
  //             "release_dates": null
  // ....
  if (data.live_video) return 'live-label'

  if (data.scheduled_at === null && data.live_video === false)
    return 'watch-button'

  if (data.scheduled_at !== null) return 'schedule-button'
}

export function scheduleLiveEvent(data, scheduleNotf) {
  return () => {
    const parsedTitle = parseTitle(data)

    let title = data.short_description || '',
      liveClass = parsedTitle.activity || '',
      trainer = '',
      messageDate = data.scheduled_at || ''

    let message = ` No olvides, tu clase live programada ${liveClass}${
      trainer ? ` con ${trainer}` : ''
    }este ${format(new Date(messageDate), 'eeee h:m b')}`

    // TODO: use real schedule date
    return scheduleNotf({
      date: new Date(Date.now() + 5 * 1000),
      expireDate: new Date(Date.now() + 40 * 1000),
      route: 'video-detail',
      id: data.id,
      routeParams: {
        description: data.description,
        id: data.id,
        image: data.thumbnail.large,
        headerTitle: data.name
      },
      title,
      message
    })
  }
}
