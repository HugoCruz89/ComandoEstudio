import { getDay, addDays, getDate, format } from 'date-fns'
export const TRAINERS = [
  {
    name: 'Peter Thomas',
    avatar: require('media/mock/trainers/trainer-3.png')
  },
  {
    name: 'Mckenzie Miller',
    avatar: require('media/mock/trainers/trainer-2.png')
  },
  { name: 'Anne Yak', avatar: require('media/mock/trainers/trainer-1.png') },
  {
    name: 'Keisha Stewart',
    avatar: require('media/mock/trainers/trainer-4.png')
  }
]
export const LIVEClASS = [
  {
    title: 'Full body 20',
    background: require('media/mock/channel/channel-element.png')
  },
  {
    title: 'Fat burn program',
    background: require('media/mock/channel/channel-element.png'),
    isNew: true
  },
  {
    title: 'core strength ',
    background: require('media/mock/channel/channel-element.png')
  },
  {
    title: 'zen meditation',
    background: require('media/mock/channel/channel-element.png')
  }
]

export const PROGRAMS = [
  {
    title: 'Full body 20',
    background: require('media/mock/channel/channel-element.png')
  },
  {
    title: 'Fat burn program',
    background: require('media/mock/channel/channel-element.png'),
    isNew: true
  },
  {
    title: 'core strength ',
    background: require('media/mock/channel/channel-element.png')
  },
  {
    title: 'zen meditation',
    background: require('media/mock/channel/channel-element.png')
  }
]

export const RELEASES = [
  {
    title: 'Full body 20',
    background: require('media/mock/channel/video-element-1.png'),
    duration: 25,
    level: 'medium',
    id: 188157
  },
  {
    title: 'Fat burn program',
    background: require('media/mock/channel/video-element-2.png'),
    duration: 25,
    level: 'medium',
    isNew: true,
    id: 160381
  },
  {
    title: 'core strength ',
    background: require('media/mock/channel/video-element-3.png'),
    duration: 25,
    level: 'medium',
    id: 179755
  },
  {
    title: 'zen meditation',
    background: require('media/mock/channel/video-element-4.png'),
    duration: 25,
    level: 'medium',
    id: 160390
  }
]

export const SCULPT_SHRED = {
  IMAGE: require('media/mock/channel/channel-banner.png'),
  TITLE: 'Sculpt & Shred',
  DESCRIPTION:
    'Para lucir tonificado es importante construir masa muscular y muchas veces no sabemos cómo hacerlo fuera de un gimnasio. Este programa esta fundamentado en las metodologías del entrenamiento de hipertrofia y está periodizado (programado) de tal forma que puedas entrenar 31 días continuos para poder darle a tus músculos la adaptación inicial y el volumen de entrenamiento necesario para poder construir fibras musculares. Los primeros días vas a entrenar cada músculo por separado para poder hacer conexiones neuromusuclares. Después empezamos a combinar dos grupos musculares basados en el split push/ pull (un músculo que empuja y otro que jala) y la recta final del programa es la combinación de 3 grupos musculares y sesiones fullbody enfocados a la conexión muscular de todo tu cuerpo.',
  CHANNELS: [
    {
      id: '0',
      image: require('media/mock/channel/video-element-1.png'),
      title: 'Entrenamiento 18: Piernas, glúteos y abs con Andie',
      duration: 25,
      trainer: 'Peter Thomas',
      equipment: 'Mancuernas medianas y/o pesadas',
      type: 'Fuera y Masa Muscular',
      muscularFocus: 'Pecho y Espalda',
      description:
        'Sin duda una sesión exigente, ya que combina dos grupos musculares grandes que a su vez se oponen. Y como dice tu coach Pete, "Si ya estás aquí, que valga la pena" ¡A entrenar!'
    },
    {
      id: '1',
      image: require('media/mock/channel/video-element-2.png'),
      title: 'Entrenamiento 17: Bíceps, tríceps y hombros con Dani',
      duration: 25,
      trainer: 'Peter Thomas',
      equipment: 'Mancuernas medianas y/o pesadas',
      type: 'Fuera y Masa Muscular',
      muscularFocus: 'Pecho y Espalda',
      description:
        'Sin duda una sesión exigente, ya que combina dos grupos musculares grandes que a su vez se oponen. Y como dice tu coach Pete, "Si ya estás aquí, que valga la pena" ¡A entrenar!'
    },
    {
      id: '2',
      image: require('media/mock/channel/video-element-3.png'),
      title: 'Entrenamiento 16: Espalda y tríceps con Pete',
      duration: 25,
      trainer: 'Peter Thomas',
      equipment: 'Mancuernas medianas y/o pesadas',
      type: 'Fuera y Masa Muscular',
      muscularFocus: 'Pecho y Espalda',
      description:
        'Sin duda una sesión exigente, ya que combina dos grupos musculares grandes que a su vez se oponen. Y como dice tu coach Pete, "Si ya estás aquí, que valga la pena" ¡A entrenar!'
    },
    {
      id: '3',
      image: require('media/mock/channel/video-element-4.png'),
      title: 'Entrenamiento 19: Pecho y espalda con Peter',
      duration: 25,
      trainer: 'Peter Thomas',
      equipment: 'Mancuernas medianas y/o pesadas',
      type: 'Fuera y Masa Muscular',
      muscularFocus: 'Pecho y Espalda',
      description:
        'Sin duda una sesión exigente, ya que combina dos grupos musculares grandes que a su vez se oponen. Y como dice tu coach Pete, "Si ya estás aquí, que valga la pena" ¡A entrenar!'
    }
  ]
}

export const EXTRA_CLASS = {
  name: 'Fuerza y Stretch',
  image: require('media/mock/channel/video-element-1.png'),
  progress: 50,
  duration: 25,
  program: 'Fuerza y Stretch',
  tags: ['flow', 'yoga'],
  trainer: 'Mckenzie Miller'
}

export const TODAY_CLASS = {
  name: 'Cuerpo completo',
  image: require('media/mock/channel/video-element-2.png'),
  progress: 0,
  duration: 25,
  program: 'Cardio FULL BODY Trainning',
  tags: ['Nonstop 5'],
  trainer: 'Peter Thomas'
}

export const M3U8_PLAYLIST = {
  uri:
    'https://player.vimeo.com/skyfire/redirect/446672074.m3u8?allow_fastly_packager=0&expires=1601654267&f=ts&hevc=0&sig=4aa3ef944078eb5e2cc352b9c0f63e0835ed6afb&text_tracks=1',
  type: 'm3u8'
}

export const SCHEDULE = [
  [
    { status: 'DAY_OFF', time: 'PAST' },
    { status: 'COMPLETE', time: 'PAST' },
    { status: 'INCOMPLETE', time: 'PAST' },
    { status: 'PENDING', time: 'PAST' },
    { status: 'PENDING', time: 'PRESENT' },
    { status: 'DAY_OFF', time: 'FUTURE' },
    { status: 'DAY_OFF', time: 'FUTURE' }
  ],
  [
    { status: 'DAY_OFF', time: 'FUTURE' },
    { status: 'PENDING', time: 'FUTURE' },
    { status: 'PENDING', time: 'FUTURE' },
    { status: 'PENDING', time: 'FUTURE' },
    { status: 'PENDING', time: 'FUTURE' },
    { status: 'DAY_OFF', time: 'FUTURE' },
    { status: 'DAY_OFF', time: 'FUTURE' }
  ]
]

export const SCHEDULE_NEW = [
  { status: 'DAY_OFF', time: 'PAST', day: 'L', numberDay: 1 },
  { status: 'COMPLETE', time: 'PAST', day: 'M', numberDay: 2 },
  { status: 'INCOMPLETE', time: 'PAST', day: 'M', numberDay: 3 },
  { status: 'PENDING', time: 'PRESENT', day: 'J', numberDay: 4 },
  { status: 'PENDING', time: 'PAST', day: 'V', numberDay: 5 },
  { status: 'DAY_OFF', time: 'FUTURE', day: 'S', numberDay: 6 },
  { status: 'DAY_OFF', time: 'FUTURE', day: 'D', numberDay: 0 }
]

export const OBJECTIVES = [
  {
    id: 0,
    checked: false,
    description: 'Quema de grasa',
    icon: 'fire',
    image: 'flame',
    enable: true,
    descriptionToDataBase: 'fat burning'
  },
  {
    id: 1,
    checked: false,
    description: 'Tonificar / desarrollo masa muscular',
    icon: 'stumbleupon',
    image: 'arm',
    enable: true,
    descriptionToDataBase: 'Tone / build muscle mass'
  },
  {
    id: 2,
    checked: false,
    description: 'Acondicionamiento Fisico',
    icon: 'pied-piper-pp',
    image: 'run',
    enable: true,
    descriptionToDataBase: 'Physical conditioning'
  },
  {
    id: 3,
    checked: false,
    description: 'Comenzar a hacer ejercicio',
    icon: 'binoculars',
    image: 'weight',
    enable: true,
    descriptionToDataBase: 'Start exercising'
  },
  {
    id: 4,
    checked: false,
    description: 'Movilidad y Flexibilidad',
    icon: 'plus-square-o',
    image: 'lightning',
    enable: true,
    descriptionToDataBase: 'Mobility and Flexibility'
  }
]

export const LIST_DAY = [
  { id: 1, descripcion: 'L', checked: false },
  { id: 2, descripcion: 'M', checked: false },
  { id: 3, descripcion: 'M', checked: false },
  { id: 4, descripcion: 'J', checked: false },
  { id: 5, descripcion: 'V', checked: false },
  { id: 6, descripcion: 'S', checked: false },
  { id: 0, descripcion: 'D', checked: false }
]

export const LIVE_CLASS = [
  {
    title: 'Commando in da hours',
    date: new Date(),
    background: require('media/mock/channel/video-element-1.png'),
    duration: 25,
    level: 'medium',
    trainer: 'Mckenzie Miller'
  },
  {
    title: 'Interval sweat con',
    date: new Date(),
    background: require('media/mock/channel/video-element-2.png'),
    duration: 25,
    level: 'medium',
    trainer: 'Peter Thomas'
  },
  {
    title: 'Pecho, espalda y partes',
    date: new Date(),
    background: require('media/mock/channel/video-element-3.png'),
    duration: 25,
    level: 'medium',
    trainer: 'Susana López'
  },
  {
    title: 'Commando in da hours',
    date: new Date(),
    background: require('media/mock/channel/video-element-4.png'),
    duration: 25,
    level: 'medium',
    trainer: 'Peter Thomas'
  }
]

const GetDayWord = (day) => {
  switch (day) {
    case 0:
      return 'D'
    case 1:
      return 'L'
    case 2:
      return 'M'
    case 3:
      return 'M'
    case 4:
      return 'J'
    case 5:
      return 'V'
    case 6:
      return 'S'
    default:
      return null
  }
}
export function GetArrayOfWeek() {
  let ArrayWeek = []
  const currentDay = new Date()

  for (let i = 0; i <= 15; i++) {
    const afterDay = addDays(currentDay, i)
    const numberDay = getDate(afterDay)
    const day = GetDayWord(getDay(afterDay))
    const check = i === 0 ? true : false
    let object = {
      Day: day,
      NumberDay: numberDay,
      DateWord: format(afterDay, 'MM/dd/yyyy'),
      id: i,
      check: check
    }
    ArrayWeek.push(object)
  }
  return ArrayWeek
}
export const LISTDAY = [
  { id: 1, descripcion: 'D', checked: false },
  { id: 2, descripcion: 'L', checked: false },
  { id: 3, descripcion: 'M', checked: false },
  { id: 4, descripcion: 'M', checked: false },
  { id: 5, descripcion: 'J', checked: false },
  { id: 6, descripcion: 'V', checked: false },
  { id: 7, descripcion: 'S', checked: false }
]
export const OBJECTIVESLIST = [
  {
    id: 0,
    checked: false,
    description: 'Quema de grasa',
    icon: 'fire',
    image: 'flame'
  },
  {
    id: 1,
    checked: false,
    description: 'Tonificar / desarrollo masa muscular',
    icon: 'stumbleupon',
    image: 'arm'
  },
  {
    id: 2,
    checked: false,
    description: 'Acondicionamiento Fisico',
    icon: 'pied-piper-pp',
    image: 'run'
  },
  {
    id: 3,
    checked: false,
    description: 'Comenzar a hacer ejercicio',
    icon: 'binoculars',
    image: 'weight'
  },
  {
    id: 4,
    checked: false,
    description: 'Movilidad y Flexibilidad',
    icon: 'plus-square-o',
    image: 'lightning'
  }
]
