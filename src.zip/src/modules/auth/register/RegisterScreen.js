import React, { Component } from 'react'
import { func } from 'prop-types'
import { SafeAreaView, StyleSheet, View, Text } from 'react-native'
import { connect } from 'react-redux'
import Debounce from 'lodash.debounce'
import { TextInput, Button } from 'components'
import { isEmail } from 'src/utils'
import { registerUser, loginUser } from 'ducks/auth'

class RegisterScreen extends Component {
  state = {
    modalVisible: false,
    email: '',
    email_error: '',
    confirm_email: '',
    confirm_email_error: '',
    firstName: '',
    firstName_error: '',
    lastName: '',
    lastName_error: '',
    password: '',
    password_error: '',
    loading: false
  }

  validateField = (field) =>
    Debounce(() => {
      switch (field) {
        case 'email':
        case 'confirm_email':
          this.setState((prevState) => ({
            email_error: isEmail(prevState.email)
              ? ''
              : 'Ingresa una dirección de correo válida.',
            confirm_email_error:
              prevState.confirm_email === prevState.email
                ? ''
                : 'El correo no coincide.'
          }))
          break
        case 'password':
          this.setState((prevState) => ({
            password_error:
              prevState.password.length >= 6
                ? ''
                : 'Necesita tener mínimo 6 caracteres.'
          }))
          break
        case 'firstName':
        case 'lastName':
          this.setState((prevState) => ({
            [`${field}_error`]: prevState[field] ? '' : 'Campo requerido.'
          }))
          break
      }
    }, 100)

  handleFieldChange = (value, name) => {
    if (name !== 'email' && name !== 'confirm_email') {
      this.setState({ [name]: value }, this.validateField(name))
    } else {
      this.setState({ [name]: value.toLowerCase() }, this.validateField(name))
    }
  }

  handleRegisterSubmit = () => {
    const { email, firstName, lastName, password } = this.state
    this.setState({ loading: true }, async () => {
      try {
        await this.props.registerUser(email, firstName, lastName, password)
        this.props.navigation.reset({
          index: 0,
          routes: [{ name: 'subscription' }]
        })
      } catch (err) {
        const {
          error: {
            response: { data }
          }
        } = err
        if (data.error === 'UserAlreadyExists') {
          this.setState({
            loading: false,
            confirm_email_error: 'Este correo ya está registrado.'
          })
        }
        return
      }

      try {
        await this.props.loginUser(email, password)
        console.log('Inicio de sesión exitoso')
      } catch (err) {
        console.log(err)
      }
      this.setState({ loading: false })
    })
  }

  render() {
    const {
      email,
      email_error,
      confirm_email,
      confirm_email_error,
      password,
      password_error,
      firstName,
      firstName_error,
      lastName,
      lastName_error,
      loading
    } = this.state
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.title}>REGISTRO</Text>
        <Text style={styles.description}>
          Entrena con los instructores más reconocidos y experimentados. Ellos
          te guiarán en cada clase para ofrecerte un entrenamiento único
        </Text>
        <View style={styles['form-container']}>
          <TextInput
            label="Correo"
            name="email"
            value={email}
            error={email_error}
            onChangeText={this.handleFieldChange}
          />
          <TextInput
            label="Confirmar Correo"
            name="confirm_email"
            value={confirm_email}
            error={confirm_email_error}
            onChangeText={this.handleFieldChange}
          />
          <TextInput
            label="Contraseña"
            secureTextEntry
            name="password"
            value={password}
            error={password_error}
            onChangeText={this.handleFieldChange}
          />
          <TextInput
            label="Nombre"
            name="firstName"
            value={firstName}
            error={firstName_error}
            onChangeText={this.handleFieldChange}
          />
          <TextInput
            label="Apellido"
            name="lastName"
            value={lastName}
            error={lastName_error}
            onChangeText={this.handleFieldChange}
          />
          <Button
            theme="tertiary"
            title="Regresar"
            disabled={loading}
            onPress={this.props.navigation.goBack}
            style={{ container: styles['back-button'] }}
          />
        </View>
        <Button
          theme="primary"
          title="Comenzar prueba"
          loading={loading}
          onPress={this.handleRegisterSubmit}
          style={{ container: styles['submit-button'] }}
        />
      </SafeAreaView>
    )
  }
}

RegisterScreen.propTypes = {
  registerUser: func,
  loginUser: func
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    flex: 1,
    marginLeft: 30,
    marginRight: 30
  },
  title: {
    color: '#43485C',
    fontWeight: '500',
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 10,
    textTransform: 'uppercase',
    marginTop: 30
  },
  description: {
    color: '#43485C',
    fontSize: 14,
    textAlign: 'center'
  },
  'form-container': {
    flex: 1,
    width: '100%'
  },
  'back-button': {
    marginTop: 30
  },
  'submit-button': {
    width: '100%'
  }
})

const mapDispatchToProps = {
  registerUser,
  loginUser
}

export default connect(null, mapDispatchToProps)(RegisterScreen)
