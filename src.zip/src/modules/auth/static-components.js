import React, { useRef } from 'react'
import { oneOf } from 'prop-types'
import { Image, View, Dimensions } from 'react-native'
import { Button, Text } from 'components'
const windowHeight = Dimensions.get('window').height
const logoStyle = { width: 180 }

const logoSource = {
  white: require(`media/images/commando-now-white.png`),
  black: require(`media/images/commando-now-black.png`)
}

function Logo(props) {
  const color = props.color

  return (
    <Image style={logoStyle} resizeMode="contain" source={logoSource[color]} />
  )
}

Logo.propTypes = {
  color: oneOf(['white', 'black'])
}

Logo.defaultProps = {
  color: 'black'
}

function Slogan(props) {
  return (
    <Text
      style={[sloganStyle, props.style]}
      textAlign="center"
      color={props.color}>
      Clases ilimitadas, cuando quieras como quieras.
    </Text>
  )
}

const sloganStyle = {
  maxWidth: 160
}

Slogan.propTypes = {
  color: oneOf(['white', 'black'])
}

Slogan.defaultProps = {
  color: 'black'
}

function TermsAndConditions() {
  const year = useRef(new Date().getFullYear())
  return (
    <>
      <View style={termsContainerStyle}>
        <Text style={[termsStyle, linkSeparator]}>Conoce nuestros</Text>
        <Button theme="tertiary" title="términos y condiciones" />
      </View>
      <Text style={termsStyle}>Commando On Demand © {year.current}</Text>
    </>
  )
}

function Separator(props) {
  return <View style={separatorStyle} />
}

const AllRights = () => {
  const year = useRef(new Date().getFullYear())
  return (
    <Text style={allRights}>
      Commando Studio {year.current} © Todos los Derechos Reservados
    </Text>
  )
}

const separatorStyle = {
  borderBottomColor: '#dadada',
  borderBottomWidth: 1,
  marginTop: windowHeight * 0.03,
  marginBottom: 22
}

const termsContainerStyle = {
  flexDirection: 'row',
  alignItems: 'center'
}

const termsStyle = {
  textAlign: 'center',
  color: '#828282'
}

const allRights = {
  textAlign: 'center',
  fontSize: 12,
  fontWeight: 'normal',
  color: '#FFFFFF'
}

const linkSeparator = {
  marginRight: 4
}

export { Logo, Slogan, TermsAndConditions, Separator, AllRights }
