import React, { Component } from 'react'
import { func } from 'prop-types'
import { connect } from 'react-redux'
import { SafeAreaView, StyleSheet, Alert, View } from 'react-native'
import Debounce from 'lodash.debounce'
import { TextInput, Button, Text } from 'components'
import { completeReset } from 'ducks/auth'
import { Logo } from 'modules/auth/static-components'

class SetPasswordScreen extends Component {
  state = {
    loading: false,
    password: '',
    password_error: ''
  }

  validatePassword = Debounce(() => {
    this.setState((prevState) => ({
      password_error:
        prevState.password.length < 6
          ? 'Necesita tener mínimo 6 caracteres.'
          : ''
    }))
  }, 100)

  _requestResetPassword = () => {
    if (this.state.password.length >= 6) {
      this.setState({ loading: true }, () => {
        setTimeout(() => {
          Alert.alert(
            'Tu contraseña se ha reestablecido',
            'Por favor, inicia sesión con tu contraseña nueva.',
            [
              {
                text: 'Cerrar',
                style: 'cancel'
              }
            ]
          )
          this.props.navigation.reset({
            index: 1,
            routes: [{ name: 'welcome' }, { name: 'login' }]
          })
        }, 500)
      })
    } else {
      this.setState({ password_error: 'Necesita tener mínimo 6 caracteres.' })
    }
  }

  requestResetPassword = () => {
    const {
      params: { token }
    } = this.props.route

    if (this.state.password.length >= 6 && token) {
      this.setState({ loading: true }, async () => {
        try {
          await this.props.completeReset(this.state.password, token)
          Alert.alert(
            'Tu contraseña se ha reestablecido',
            'Por favor, inicia sesión con tu contraseña nueva.',
            [
              {
                text: 'Cerrar',
                style: 'cancel'
              }
            ]
          )
          this.props.navigation.reset({
            index: 1,
            routes: [{ name: 'welcome' }, { name: 'login' }]
          })
        } catch (error) {
          this.setState(
            {
              loading: false,
              password_error: 'Error en el flujo. Contacta a soporte'
            },
            () => {}
          )
        }
      })
    } else {
      this.setState({ password_error: 'Necesita tener mínimo 6 caracteres.' })
    }
  }

  handlePasswordInput = (password) => {
    this.setState({ password }, this.validatePassword)
  }

  render() {
    const { loading, password_error } = this.state
    return (
      <SafeAreaView style={styles.container}>
        <Logo />
        <View style={styles['content-container']}>
          <Text type="title">Crear contraseña</Text>
          <Text textAlign="center">
            Crea tu nueva contraseña para commando móvil, mínimo 6 caracteres.
          </Text>
          <TextInput
            label="Agregar nueva contraseña"
            name="password"
            key="set_password"
            error={password_error}
            onChangeText={this.handlePasswordInput}
            secureTextEntry
          />
          <Button
            style={{ container: { width: '100%' } }}
            title="Crear contraseña"
            loading={loading}
            onPress={this.requestResetPassword}
          />
        </View>
      </SafeAreaView>
    )
  }
}

SetPasswordScreen.propTypes = {
  completeReset: func
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    alignItems: 'center'
  },
  'content-container': {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    paddingLeft: 30,
    paddingRight: 30
  }
})

const mapDispatchToProps = {
  completeReset: (password, token) => (dispatch, getState) => {
    const {
      auth: { userId }
    } = getState()
    console.log(userId, password, token)
    return dispatch(completeReset(userId, password, token))
  }
}

export default connect(null, mapDispatchToProps)(SetPasswordScreen)
