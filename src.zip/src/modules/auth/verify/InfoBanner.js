import React from 'react'
import { bool, string } from 'prop-types'
import { Text } from '../../../components'
import Icon from 'react-native-vector-icons/FontAwesome'
import { StyleSheet, View } from 'react-native'

function InfoBanner(props) {
  const { error } = props
  return (
    <View
      style={[
        styles['info-container'],
        error ? styles['info-container--error'] : styles['info-container--info']
      ]}>
      <Icon
        name="exclamation-circle"
        size={30}
        backgroundColor="white"
        color={error ? '#FF9900' : '#2D84F5'}
      />
      <Text style={styles['info-label']}>{props.infoMessage}</Text>
    </View>
  )
}

InfoBanner.propTypes = {
  error: bool,
  infoMessage: string
}

const styles = StyleSheet.create({
  'info-container': {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    paddingTop: 15,
    paddingBottom: 15,
    paddingLeft: 10,
    paddingRight: 10
  },
  'info-container--info': {
    backgroundColor: 'rgba(146, 213, 242, 0.19)'
  },
  'info-container--error': {
    backgroundColor: 'rgba(255, 153, 0, 0.19)'
  },
  'info-label': {
    color: '#43485C',
    fontWeight: '600',
    marginLeft: 15
  }
})

export default InfoBanner
