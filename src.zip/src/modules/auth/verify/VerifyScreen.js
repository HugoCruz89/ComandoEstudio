import React, { Component } from 'react'
import { string, func, object } from 'prop-types'
import { connect } from 'react-redux'
import { SafeAreaView, StyleSheet, View, ActivityIndicator } from 'react-native'
import { Text, Button } from 'components'
import { verifyToken, resetPassword } from 'ducks/auth'
import { Logo } from '../static-components'
import VerifyInput from './VerifyInput'
import InfoBanner from './InfoBanner'

class VerifyScreen extends Component {
  state = {
    loading: false,
    error: null,
    infoMessage: ''
  }

  checkCode = (code) => {
    this.setState({ loading: true }, async () => {
      try {
        await this.props.verifyToken(code)
        this.props.navigation.navigate('setPassword', { token: code })
      } catch (err) {
        console.log({ ...err })
        this.setState({
          error: true,
          loading: false,
          infoMessage: 'Código inválido, inténtalo nuevamente.'
        })
      }
    })
  }

  _checkCode = (code) => {
    this.setState({ loading: true }, () => {
      setTimeout(() => {
        if (code === '1234') {
          this.props.navigation.navigate('setPassword', { token: code })
        } else {
          this.setState({
            error: true,
            loading: false,
            infoMessage: 'Código inválido, inténtalo nuevamente.'
          })
        }
      }, 500)
    })
  }

  resendCode = async () => {
    try {
      await this.props.resetPassword()
      this.setState({
        error: false,
        infoMessage: 'Código enviado nuevamente al correo.'
      })
    } catch (err) {
      console.log({ err })
    }
  }

  resetError = () => {
    this.setState({ error: null, infoMessage: '' })
  }

  render() {
    const { email } = this.props
    const { infoMessage, error, loading } = this.state

    return (
      <SafeAreaView style={styles.container}>
        <Logo />
        <Text type="title">Codigo de verificación</Text>
        <Text type="body" textAlign="center" style={styles.instructions}>
          Ingresa el codigo de verificación, que se envió a tu correo.
        </Text>
        <Text type="body" textAlign="center" style={styles.email}>
          {email}
        </Text>
        <View style={styles['input-container']}>
          <VerifyInput
            onLengthComplete={this.checkCode}
            onNewStart={this.resetError}
            error={error && infoMessage}
          />
          <View style={styles['resend-container']}>
            <Text color="#828282">¿No llego el correo? </Text>
            <Button
              theme="tertiary"
              title="Reenviar"
              onPress={this.resendCode}
            />
          </View>
          {loading && <ActivityIndicator size="large" />}
          {infoMessage ? (
            <InfoBanner error={error} infoMessage={infoMessage} />
          ) : null}
        </View>
      </SafeAreaView>
    )
  }
}

VerifyScreen.propTypes = {
  email: string,
  route: object,
  verifyToken: func,
  resetPassword: func
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    width: '100%'
  },
  instructions: { width: 270, marginTop: 10 },
  email: { width: '100%' },
  'input-container': {
    width: '100%',
    paddingLeft: 30,
    paddingRight: 30
  },
  'resend-container': {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%'
  }
})

const mapDispatchToProps = {
  verifyToken: (token) => (dispatch, getState) => {
    const {
      auth: { userId }
    } = getState()
    return dispatch(verifyToken(userId, token))
  },
  resetPassword: (dispatch, getState) => {
    const {
      auth: { userId }
    } = getState()
    return dispatch(resetPassword(userId))
  }
}

export default connect(null, mapDispatchToProps)(VerifyScreen)
