import React, { Component, createRef } from 'react'
import { string, number, func } from 'prop-types'
import { View, StyleSheet, TextInput, Text } from 'react-native'

class VerifyInput extends Component {
  state = { value: '' }

  codeLength = Array(this.props.codeLength).fill(1)

  textInputRef = createRef()

  handleChangeText = (val) => {
    this.setState({ value: val.replace(/\D/g, '') }, () => {
      const { value } = this.state
      if (value.length === this.props.codeLength && this.textInputRef.current) {
        this.textInputRef.current.blur()
        this.props.onLengthComplete(value)
      } else if (value.length === 1 && this.props.error) {
        this.props.onNewStart()
      }
    })
  }

  renderCodeFields = (item, i) => {
    const { value } = this.state
    const code = i < value.length ? value[i] : ''
    return (
      <View key={i} style={[styles['code-field-container']]}>
        <View
          style={[
            styles['code-field'],
            this.props.error ? styles['code-field--error'] : null
          ]}>
          <Text style={styles.code}>{code}</Text>
        </View>
      </View>
    )
  }

  render() {
    const { value } = this.state
    return (
      <View style={styles.container}>
        <TextInput
          ref={this.textInputRef}
          disabled
          style={styles['text-input']}
          textContentType="oneTimeCode"
          keyboardType="number-pad"
          textAlign="center"
          maxLength={this.props.codeLength}
          value={value}
          onChangeText={this.handleChangeText}
          clearTextOnFocus
          caretHidden
        />
        <View style={styles['code-container']}>
          {this.codeLength.map(this.renderCodeFields)}
        </View>
      </View>
    )
  }
}
VerifyInput.propTypes = {
  name: string,
  codeLength: number,
  onLengthComplete: func.isRequired,
  onNewStart: func
}

VerifyInput.defaultProps = {
  codeLength: 4
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'flex-end',
    position: 'relative'
  },
  'text-input': {
    position: 'absolute',
    backgroundColor: 'transparent',
    color: 'transparent',
    width: '100%',
    zIndex: 10,
    fontSize: 80
  },
  'code-container': {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center'
  },
  'code-field-container': {
    width: '25%',
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  'code-field': {
    maxWidth: '80%',
    width: '100%',
    height: 100,
    borderBottomWidth: 1.5,
    justifyContent: 'flex-end',
    borderBottomColor: '#000000'
  },
  'code-field--error': {
    borderBottomColor: '#E30000',
    borderBottomWidth: 2
  },
  code: {
    fontSize: 80,
    textAlign: 'center'
  }
})

export default VerifyInput
