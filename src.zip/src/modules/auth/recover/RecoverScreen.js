import React, { useState, useEffect } from 'react'
import { object, func } from 'prop-types'
import {
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard
} from 'react-native'
import { connect } from 'react-redux'
import { Button, Text, TextInput } from 'components'
import { resetPassword, validateEmail } from 'ducks/auth'
import { isEmail } from 'src/utils'
import { Logo } from '../static-components'
import Dialog from '../../../components/Dialog'
import ModalLoad from '../../../components/Dialog'
import styles from '../login/styles'
import { Bubbles } from 'react-native-loader'

const back = require('../../../media/images/back.png')

function RecoverScreen(props) {
  const { params } = props.route
  const type = 'alarm'
  const title = 'Recuperar contraseña'
  const image = require('../../../media/images/lock.png')
  const [loading, setLoading] = useState(false)
  const [visible, setVisible] = useState(false)
  const [visibleLoad, setVisibleLoad] = useState(false)
  const [email, setEmail] = useState(params.email)
  const [disableButton, setDisableButton] = useState(true)
  const [emailError, setMailError] = useState('')
  const [visibleButton] = useState(false)
  const requestPasswordReset = async () => {
    try {
      setVisibleLoad(true)
      let ObjectSended = {
        email: email
      }
      await props.resetPassword(ObjectSended)
      setVisibleLoad(false)
      setVisible(true)
      //props.navigation.reset({ index: 0, routes: [{ name: 'verify' }] })
    } catch (err) {
      console.log('error', { err })
    }
    setLoading(false)
  }

  const handleInputChange = (value) => {
    setEmail(value.toLowerCase())
  }

  const hideHandle = () => {
    setVisible(false)
  }

  const aceptHandler = () => {
    props.navigation.navigate('login', {})
    setVisible(false)
  }

  useEffect(() => {
    if (isEmail(email)) {
      setDisableButton(false)
      setMailError('')
    } else {
      setDisableButton(true)

      setMailError('Ingresa una direccion de correo valido')
    }
  }, [email, params])

  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss()
      }}>
      <SafeAreaView style={style.container}>
        <TouchableOpacity
          onPress={props.navigation.goBack}
          style={style.goback}>
          <Image source={back} />
        </TouchableOpacity>
        <View style={styles.header}>
          <Logo />
        </View>

        <View style={style['content-container']}>
          <Text type="title" style={style.title} textAlign="center">
            Recuperar contraseña
          </Text>
          <Text type="body" style={style.description}>
            Introduce tu dirección de correo electrónico que usaste para
            registrarte. Te enviaremos un correo electrónico con tu nombre de
            usuario y un enlace para restablecer tu contraseña.
          </Text>
          <TextInput
            label="Correo"
            error={emailError}
            autoCapitalize="none"
            clearTextOnFocus
            returnKeyType="send"
            defaultValue={email}
            onChangeText={handleInputChange}
            keyboardType="email-address"
          />
          <Button
            disabled={disableButton}
            title="Recuperar contraseña"
            loading={loading}
            onPress={requestPasswordReset}
            style={{ container: style['action-button'] }}
          />
          <Dialog
            {...{
              visible,
              type,
              title,
              image,
              hideHandle,
              aceptHandler
            }}>
            <Text type="body">
              Enviamos un correo a {email} con un enlace para restablecer tu
              contraseña.
            </Text>
            <Text type="body">
              Revisa tu bandeja de correo no deseado si no ves el correo
              electrónico.
            </Text>
          </Dialog>
          <ModalLoad
            {...{
              visibleLoad,
              type,
              visibleButton
            }}>
            <Bubbles size={10} color="#000000" />
          </ModalLoad>
        </View>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  )
}

RecoverScreen.propTypes = {
  navigation: object,
  route: object,
  resetPassword: func
}

const style = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#FFFFFF'
  },
  title: {
    fontWeight: '800',
    color: '#000000',
    fontFamily: 'Raleway',
    fontSize: 20
  },
  description: {
    marginTop: 20,
    marginBottom: 50,
    fontSize: 14,
    fontFamily: 'Lato',
    fontWeight: 'normal',
    color: '#2A2B37',
    textAlign: 'justify'
  },
  'content-container': {
    width: '100%',
    paddingLeft: 30,
    paddingRight: 30,
    paddingTop: 18
  },
  'action-button': {
    width: '100%',
    marginTop: 30,
    height: 46,
    marginBottom: 10
  },
  'paragraph-jump': {
    marginTop: 10
  },
  goback: {
    position: 'absolute',
    left: 15,
    top: 80
  }
})

const mapDispatchToProps = {
  resetPassword,
  validateEmail
}

export default connect(null, mapDispatchToProps)(RecoverScreen)
