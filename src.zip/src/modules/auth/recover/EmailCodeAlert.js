import { Alert } from 'react-native'

export default (onPress) =>
  Alert.alert(
    `Enviaremos un correo con un código para restablecer tu contraseña.`,
    'Revisa tu bandeja de correo no deseado si no ves el correo electrónico',
    [
      {
        text: 'Cerrar',
        onPress,
        style: 'cancel'
      }
    ]
  )
