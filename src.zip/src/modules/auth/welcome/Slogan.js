import React from 'react'
import { oneOf } from 'prop-types'
import { View, StyleSheet } from 'react-native'
import { Text } from 'components'

const Slogan = ({ color }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title} color={color}>
        Clases ilimitadas
      </Text>
      <Text style={styles.subtitle} color={color}>
        Cuando quieras, como quieras.
      </Text>
    </View>
  )
}

Slogan.propTypes = {
  color: oneOf(['white', 'black'])
}

Slogan.defaultProps = {
  color: 'black'
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center'
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
    fontFamily: 'Raleway',
    textTransform: 'uppercase'
  },
  subtitle: {
    fontFamily: 'Raleway',
    fontSize: 18
  }
})

export default Slogan
