import React from 'react'
import { object } from 'prop-types'
import { View, SafeAreaView, StyleSheet } from 'react-native'
import { useIsFocused } from '@react-navigation/native'
import { Logo, AllRights } from 'modules/auth/static-components'
import { Button } from 'components'
import Slogan from './Slogan'
import { windowHeight } from 'src/utils'
import Video from 'react-native-video'
import LinearGradient from 'react-native-linear-gradient'

const height = windowHeight

function WelcomeScreen(props) {
  const isFocused = useIsFocused()

  return (
    <SafeAreaView style={style.container}>
      <Video
        style={style['video-background']}
        repeat
        paused={!isFocused}
        resizeMode="cover"
        source={require('media/videos/welcome-background.m4v')}
      />
      <View style={style.mask} />
      <LinearGradient
        style={style.gradient}
        colors={['rgba(0, 0, 0, 0)', '#000000']}
        start={{ x: 0, y: 0.03 }}
        end={{ x: 0, y: 1 }}
      />
      <Logo color="white" />
      <View style={style.footer}>
        <View>
          <Slogan color="white" />
          <View style={style['button-container']}>
            {/* 
          Adios buen amigo, te veré pronto
            <Button
              theme="primary"
              title="Iniciar prueba gratis"
              style={{ container: style.buttons }}
              onPress={() => props.navigation.navigate('register')}
            /> 
          o nunca
        */}
            <Button
              theme="danger"
              title="Ingresar"
              style={{ container: style.buttons, text: style.text }}
              onPress={() => props.navigation.navigate('login')}
            />
          </View>
        </View>
        <AllRights />
      </View>
    </SafeAreaView>
  )
}

WelcomeScreen.propTypes = {
  navigation: object
}

const style = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#E3E3EA'
  },
  'video-background': {
    height: height,
    position: 'absolute',
    top: 0,
    left: 0,
    alignItems: 'stretch',
    bottom: 0,
    right: 0
  },
  mask: {
    height: height,
    position: 'absolute',
    top: 0,
    left: 0,
    alignItems: 'stretch',
    bottom: 0,
    right: 0,
    opacity: 0.2,
    backgroundColor: '#1A1B23'
  },
  gradient: {
    height: height / 2,
    position: 'absolute',
    top: height / 2,
    left: 0,
    alignItems: 'stretch',
    bottom: 0,
    right: 0,
    opacity: 0.4
  },
  footer: {
    alignItems: 'center',
    width: '100%',
    justifyContent: 'space-between',
    height: height / 4,
    paddingVertical: 15
  },
  'branding-header': {
    alignItems: 'center',
    width: '100%',
    top: 0,
    position: 'absolute'
  },
  'button-container': {
    width: '100%',
    paddingTop: 0,
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 10
  },
  buttons: {
    width: '100%',
    marginTop: 15,
    height: 46
  },
  text: {
    fontSize: 16
  }
})

export default WelcomeScreen
