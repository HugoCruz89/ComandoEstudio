import React, { Component } from 'react'
import { object } from 'prop-types'
import { SafeAreaView } from 'react-native'
import { Login } from './body-views'
import styles from './styles'

class LoginScreen extends Component {
  renderView = () => {
    return (
      <Login
        goToWelcome={this.props.navigation.goBack}
        goToRecoverScreen={(email) => {
          this.props.navigation.navigate('recover', { email })
        }}
      />
    )
  }

  render() {
    return (
      <SafeAreaView style={styles.container}>{this.renderView()}</SafeAreaView>
    )
  }
}

LoginScreen.propTypes = {
  navigation: object
}

export default LoginScreen
