import React, { useState } from 'react'
import { func, object, string } from 'prop-types'
import { connect } from 'react-redux'
import { View } from 'react-native'

import { TextInput, Button } from 'components'
import { Logo } from 'modules/auth/static-components'

import { loginUser } from 'ducks/auth'

import styles from '../styles'
import { TranslateX } from 'components/Animations'

function PasswordView(props) {
  const [checking, setChecking] = useState(false)
  const [password, setPassword] = useState('')
  const [passwordError, setPasswordError] = useState('')
  const [xval, setxval] = useState(0)

  const requestLogin = async () => {
    try {
      setChecking(true)
      await props.loginUser(password)
    } catch (err) {
      console.log({ err })
      setPasswordError('Contraseña incorrecta')
      setChecking(false)
    }
  }

  const handlePasswordInput = (value) => {
    setPassword(value)
    passwordError && setPasswordError('')
  }

  const handleFlow = () => {
    if (xval === 1000) {
      props.goToEmailView()
    }
  }

  const handleGoBack = () => {
    setxval(1000)
  }

  return (
    <>
      <View style={styles.header}>
        <Logo />
      </View>
      <TranslateX
        initialValue={1000}
        value={xval}
        animateOnMount
        style={styles.body}
        onMoveDidFinish={handleFlow}>
        <TextInput
          label="Contraseña"
          name="password"
          key="password"
          clearTextOnFocus
          returnKeyType="send"
          error={passwordError}
          onChangeText={handlePasswordInput}
          onSubmitEditing={requestLogin}
          secureTextEntry
        />
        <Button
          style={{ container: styles.buttons }}
          title="Iniciar sesión"
          loading={checking}
          onPress={requestLogin}
        />
        <Button
          style={{
            container: styles.buttons,
            text: { fontSize: 16 }
          }}
          theme="tertiary"
          title="Olvidé mi contraseña"
          onPress={() => props.moveToRecoverScreen(props.goToRecoverScreen)}
        />
        <Button
          style={{
            container: styles.buttons,
            text: { fontSize: 16 }
          }}
          theme="tertiary"
          title="Regresar"
          onPress={handleGoBack}
        />
      </TranslateX>
    </>
  )
}

PasswordView.propTypes = {
  email: string,
  handlePasswordInput: func,
  buttonStyle: object,
  handleFlow: func,
  moveToRecoverScreen: func,
  goToRecoverScreen: func,
  goToEmailView: func
}

const mapDispatchToProps = {
  loginUser: (pass) => (dispatch, getState) => {
    const {
      auth: { email }
    } = getState()
    return dispatch(loginUser(email, pass))
  },
  moveToRecoverScreen: (goToRecoverScreen) => (dispatch, getState) => {
    const {
      auth: { email, userId }
    } = getState()
    goToRecoverScreen(email, userId)
  }
}

export default connect(null, mapDispatchToProps)(PasswordView)
