import React, { useState } from 'react'
import { func, string } from 'prop-types'
import { connect } from 'react-redux'
import { View, TouchableOpacity, Image } from 'react-native'
import { TextInput, Button } from 'components'
import { Logo } from 'modules/auth/static-components'
import { loginUser } from 'ducks/auth'
import styles from '../styles'
import { isEmail } from 'src/utils'
import Slogan from '../../welcome/Slogan'

const back = require('../../../../media/images/back.png')

function LoginView(props) {
  const [email, setLocalEmail] = useState(props.lastEmail)
  const [emailError, setEmailError] = useState('')
  const [checking, setChecking] = useState(false)
  const [password, setPassword] = useState('')
  const [passwordError, setPasswordError] = useState('')

  const handleEmailInput = (value) => {
    setLocalEmail(value.toLowerCase())
    if (isEmail(email)) {
      setEmailError('')
    } else {
      setEmailError('Ingresa una dirección de correo válida. ')
    }
  }

  const requestLogin = async () => {
    try {
      setChecking(true)
      await props.loginUser(email, password)
    } catch (err) {
      console.log({ err })
      setPasswordError('Contraseña incorrecta')
      setChecking(false)
    }
  }

  const handlePasswordInput = (value) => {
    setPassword(value)
    passwordError && setPasswordError('')
  }

  return (
    <View style={styles.body}>
      <TouchableOpacity onPress={props.goToWelcome} style={styles.goback}>
        <Image source={back} />
      </TouchableOpacity>
      <View style={styles.header}>
        <Logo />
      </View>
      <View style={styles.slogan}>
        <Slogan />
      </View>
      <TextInput
        label="Correo"
        name="email"
        key="email"
        keyboardType="email-address"
        autoCapitalize="none"
        clearTextOnFocus
        returnKeyType="next"
        defaultValue={email}
        error={emailError}
        onChangeText={handleEmailInput}
      />
      <TextInput
        label="Contraseña"
        name="password"
        key="password"
        clearTextOnFocus
        returnKeyType="send"
        error={passwordError}
        onChangeText={handlePasswordInput}
        onSubmitEditing={requestLogin}
        secureTextEntry
      />
      <Button
        style={{ container: styles.buttons }}
        title="continuar"
        loading={checking}
        onPress={requestLogin}
      />
      <Button
        style={{
          container: styles.buttons,
          text: styles.forgote
        }}
        theme="tertiary"
        title="Olvidé mi contraseña"
        onPress={() => props.goToRecoverScreen(email)}
      />
    </View>
  )
}

LoginView.propTypes = {
  email: string,
  moveToRecoverScreen: func,
  goToRecoverScreen: func,
  goToWelcome: func
}

const mapDispatchToProps = {
  loginUser: (email, pass) => (dispatch, getState) => {
    return dispatch(loginUser(email, pass))
  },
  moveToRecoverScreen: (goToRecoverScreen) => (dispatch, getState) => {
    const {
      auth: { email, userId }
    } = getState()
    goToRecoverScreen(email, userId)
  }
}

export default connect(null, mapDispatchToProps)(LoginView)
