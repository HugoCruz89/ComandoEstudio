import React, { useState, useEffect } from 'react'
import { func, bool, string } from 'prop-types'
import { View } from 'react-native'
import { connect } from 'react-redux'

import { TextInput, Button } from 'components'
import { Logo, Slogan } from 'modules/auth/static-components'

import { isEmail } from 'src/utils'
import { setEmail } from 'ducks/auth'

import styles from '../styles'
import { TranslateX } from 'components/Animations'

function EmailView(props) {
  const [checking, setChecking] = useState(false)
  const [email, setLocalEmail] = useState(props.lastEmail)
  const [emailError, setEmailError] = useState('')
  const [xval, setxval] = useState(0)

  useEffect(() => {
    if (checking) {
      setxval(-1000)
    }
  }, [checking])

  const requestCheckEmail = async () => {
    if (isEmail(email)) {
      props.setEmail(email)
      setChecking(true)
      // try {
      //   await props.validateEmail(email)
      // } catch (err) {
      //   console.log(err)
      //   setEmailError('Este correo no tiene registro.')
      //   setChecking(false)
      // }
    } else {
      setEmailError('Ingresa una dirección de correo válida. ')
    }
  }

  const handleEmailInput = (value) => {
    setLocalEmail(value.toLowerCase())
    emailError && setEmailError('')
  }

  const handleFlow = () => {
    if (checking) {
      props.goToPasswordView()
    }
  }

  return (
    <>
      <View style={styles.header}>
        <Logo />
        <TranslateX
          animateOnMount={props.viewDidGoBack}
          initialValue={props.viewDidGoBack ? -1000 : 0}
          value={xval}>
          <Slogan />
        </TranslateX>
      </View>
      <TranslateX
        initialValue={props.viewDidGoBack ? -1000 : 0}
        value={xval}
        style={styles.body}
        animateOnMount={props.viewDidGoBack}
        onMoveDidFinish={handleFlow}>
        <TextInput
          label="Correo"
          name="email"
          key="email"
          keyboardType="email-address"
          autoCapitalize="none"
          clearTextOnFocus
          returnKeyType="next"
          defaultValue={email}
          onSubmitEditing={requestCheckEmail}
          error={emailError}
          onChangeText={handleEmailInput}
        />
        <Button
          loading={checking}
          style={{ container: styles.buttons }}
          title="continuar"
          onPress={requestCheckEmail}
        />
        {/* 
            See you,
              <View style={styles['trial-container']}>
                <Text color="#828282">No tengo cuenta, </Text>
                <Button
                  theme="tertiary"
                  title="probar 7 días gratis"
                  onPress={props.goToRegisterScreen}
                />
              </View> 
            Space Cowboy
        */}
        <Button theme="tertiary" title="Regresar" onPress={props.goToWelcome} />
      </TranslateX>
    </>
  )
}

EmailView.propTypes = {
  goToRegisterScreen: func,
  goToPasswordView: func,
  goToWelcome: func,
  setEmail: func,
  viewDidGoBack: bool,
  lastEmail: string
}

const mapStateToProps = ({ auth: { email } }) => ({
  lastEmail: email
})

const mapDispatchToProps = {
  setEmail
}

export default connect(mapStateToProps, mapDispatchToProps)(EmailView)
