import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'white'
  },
  header: {
    marginBottom: 54,
    alignItems: 'center',
    paddingLeft: 50,
    paddingRight: 50,
    paddingTop: 25
  },
  slogan: {
    paddingVertical: 25
  },
  body: {
    width: '100%',
    alignItems: 'center',
    paddingLeft: 30,
    paddingRight: 30
  },
  buttons: { width: '100%', marginTop: 5 },
  'trial-container': {
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'center'
  },
  'pending-container': {
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '100%',
    width: '100%'
  },
  goback: {
    position: 'absolute',
    left: 20,
    top: 30
  },
  arrow: {
    marginLeft: 25,
    color: '#2A2B37'
  },
  forgote: {
    fontSize: 16,
    color: '#FC3838'
  }
})
